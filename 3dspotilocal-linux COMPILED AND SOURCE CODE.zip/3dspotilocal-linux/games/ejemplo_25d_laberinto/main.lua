-- Laberinto 2.5D: ejemplo con el raycaster integrado (raycast / ray_billboard).
-- Cruceta/stick: izq-der gira, arriba-abajo camina | L / R: pasos laterales | Objetivo: juntar las gemas y llegar a la salida (pared roja).

GAME = {
  title = "Laberinto 2.5D",
  description = "Junta las gemas y escapa. Ejemplo de juego 2.5D con raycaster.",
}

-- '#' pared | '.' vacio | 1..9 paredes de colores | la salida es la celda '1' (roja)
local MAP = {
  "################",
  "#..#...........#",
  "#..#.#######.#.#",
  "#....#.....#.#.#",
  "####.#.###.#.#.#",
  "#....#.#...#.#.#",
  "#.####.#.###.#.#",
  "#......#.....#.#",
  "#.######.#####.#",
  "#.#....#.......#",
  "#.#.##.#######.#",
  "#...##........1#",
  "################",
}
local px, py, ang, gems, got, t, won, bobbing

local function solid(x, y)
  local row = MAP[math.floor(y) + 1]
  if not row then return true end
  local c = row:sub(math.floor(x) + 1, math.floor(x) + 1)
  return c ~= "." and c ~= " "
end

function init()
  px, py, ang = 1.5, 1.5, 0.0
  gems = { {7.5, 3.5}, {13.5, 1.5}, {3.5, 9.5}, {9.5, 7.5}, {13.5, 9.5}, {5.5, 5.5} }
  got, t, won, bobbing = 0, 0, false, 0
end

local function try_move(dx, dy)
  local m = 0.22
  if not solid(px + dx + (dx > 0 and m or -m), py) then px = px + dx end
  if not solid(px, py + dy + (dy > 0 and m or -m)) then py = py + dy end
end

function update(dt)
  if won then
    if pressed("a") then init() end
    return
  end
  t = t + dt
  local sx, sy = stick()
  ang = ang + sx * 2.4 * dt
  local fwd = -sy * 3.0 * dt
  try_move(math.cos(ang) * fwd, math.sin(ang) * fwd)
  local strafe = ((btn("r") and 1 or 0) - (btn("l") and 1 or 0)) * 2.4 * dt
  try_move(-math.sin(ang) * strafe, math.cos(ang) * strafe)
  bobbing = bobbing + math.abs(fwd) * 9

  for i = #gems, 1, -1 do
    if dist(px, py, gems[i][1], gems[i][2]) < 0.5 then table.remove(gems, i); got = got + 1 end
  end
  local d, cell = ray_dist(MAP, px, py, ang)
  if cell == "1" and d < 0.55 and #gems == 0 then
    won = true
    submit_score(math.max(1, math.floor(600 - t * 5)))
  end
end

function draw_top()
  raycast(MAP, px, py + 0, ang, 0, 0, TOP_W, TOP_H, 66)
  -- gemas: objetos del mundo, tapados por las paredes
  for i, g in ipairs(gems) do
    local pulse = 0.26 + math.sin(t * 4 + i) * 0.03
    ray_billboard(px, py, ang, g[1], g[2], pulse, color.cyan)
  end
  text(8, 6, 0.42, color.white, string.format("Gemas %d/6", got))
  text_right(392, 6, 0.42, color.yellow, string.format("Tiempo %d", math.floor(t)))
  circle(200, 120, 2, rgb(255, 255, 255, 140))
  if #gems == 0 and not won then text_center(200, 200, 0.42, color.green, "Ve a la pared roja") end
  if won then
    rrect(90, 80, 220, 80, 12, rgb(0, 0, 0, 200))
    text_center(200, 92, 0.65, color.white, "Escapaste")
    text_center(200, 128, 0.4, color.gray, "A: jugar de nuevo   B: menu")
  end
end

function draw_bottom()
  gradient(0, 0, BOT_W, BOT_H, rgb(14, 16, 24), rgb(22, 20, 34))
  local cs = 16
  local ox, oy = (BOT_W - #MAP[1] * cs) / 2, 18
  for y, row in ipairs(MAP) do
    for x = 1, #row do
      local c = row:sub(x, x)
      if c ~= "." then
        rrect(ox + (x - 1) * cs + 1, oy + (y - 1) * cs + 1, cs - 2, cs - 2, 3, c == "1" and color.red or rgb(90, 98, 120))
      end
    end
  end
  for _, g in ipairs(gems) do circle(ox + g[1] * cs, oy + g[2] * cs, 4, color.cyan) end
  circle(ox + px * cs, oy + py * cs, 5, color.green)
  line(ox + px * cs, oy + py * cs, ox + (px + math.cos(ang) * 0.9) * cs, oy + (py + math.sin(ang) * 0.9) * cs, 2, color.green)
  text_center(160, 226, 0.32, color.gray, "START: pausa   B: salir")
end
