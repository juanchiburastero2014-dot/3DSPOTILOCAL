-- Lluvia de cubos: ejemplo de juego 2D.
-- Mover: cruceta / stick (WASD) o deslizar el lapiz (mouse) en la pantalla de abajo. A: reintentar.

GAME = {
  title = "Lluvia de cubos (2D)",
  description = "Esquiva los bloques que caen. Ejemplo de juego 2D.",
}

local player, blocks, sparks, stars, score, alive, spawn_t, speed, shake

function init()
  player = { x = 200, y = 206, w = 30, h = 14, vx = 0 }
  blocks, sparks, stars = {}, {}, {}
  for i = 1, 40 do stars[i] = { x = rnd(0, 400), y = rnd(0, 240), s = rnd() * 0.8 + 0.2 } end
  score, alive, spawn_t, speed, shake = 0, true, 0, 80, 0
end

local function burst(x, y, c)
  for i = 1, 26 do
    sparks[#sparks + 1] = { x = x, y = y, vx = rnd() * 220 - 110, vy = -rnd() * 200, life = 0.7, c = c }
  end
end

function update(dt)
  for _, s in ipairs(stars) do
    s.y = s.y + s.s * 30 * dt
    if s.y > 240 then s.y, s.x = 0, rnd(0, 400) end
  end
  for i = #sparks, 1, -1 do
    local p = sparks[i]
    p.life = p.life - dt
    p.vy = p.vy + 420 * dt
    p.x, p.y = p.x + p.vx * dt, p.y + p.vy * dt
    if p.life <= 0 then table.remove(sparks, i) end
  end
  shake = math.max(0, shake - dt * 3)

  if not alive then
    if pressed("a") then init() end
    return
  end

  local sx = stick()
  local tx = touch()
  if tx then player.vx = clamp((tx * 1.25 - player.x) * 8, -320, 320)    -- el lapiz arrastra la nave
  else player.vx = lerp(player.vx, sx * 240, 12 * dt) end
  player.x = clamp(player.x + player.vx * dt, player.w / 2, TOP_W - player.w / 2)

  speed = speed + dt * 4
  spawn_t = spawn_t - dt
  if spawn_t <= 0 then
    spawn_t = rnd() * 0.35 + 0.18
    local w = rnd(16, 38)
    blocks[#blocks + 1] = { x = rnd(0, TOP_W - w), y = -w, w = w, h = w, vy = speed + rnd(0, 50),
                            c = ({ color.red, color.orange, color.pink, color.purple })[rnd(1, 4)] }
  end
  for i = #blocks, 1, -1 do
    local b = blocks[i]
    b.y = b.y + b.vy * dt
    if collide_rect(player.x - player.w / 2, player.y, player.w, player.h, b.x, b.y, b.w, b.h) then
      burst(player.x, player.y, color.green)
      alive, shake = false, 1
      submit_score(math.floor(score))
    elseif b.y > TOP_H then
      table.remove(blocks, i)
      score = score + 5
    end
  end
  score = score + dt * 10
end

function draw_top()
  local ox = shake > 0 and (rnd() - 0.5) * shake * 8 or 0
  gradient(0, 0, TOP_W, TOP_H, rgb(10, 14, 32), rgb(26, 12, 44))
  for _, s in ipairs(stars) do circle(s.x, s.y, s.s * 1.3, rgb(255, 255, 255, 120 + 100 * s.s)) end
  for _, b in ipairs(blocks) do
    shadow(b.x + ox, b.y, b.w, b.h, 5, 6, 80)
    rrect(b.x + ox, b.y, b.w, b.h, 5, b.c)
    rrect(b.x + 3 + ox, b.y + 3, b.w - 6, 5, 2, rgb(255, 255, 255, 70))
  end
  if alive then
    additive(true)
    circle(player.x + ox, player.y + 8, 24, rgb(29, 185, 84, 40))
    additive(false)
    rrect(player.x - player.w / 2 + ox, player.y, player.w, player.h, 6, color.green)
    tri(player.x - 8 + ox, player.y, player.x + 8 + ox, player.y, player.x + ox, player.y - 12, color.green)
  end
  additive(true)
  for _, p in ipairs(sparks) do circle(p.x, p.y, 2.5 * p.life + 0.5, alpha(p.c, p.life)) end
  additive(false)
  text(10, 8, 0.5, color.white, string.format("Puntos %d", math.floor(score)))
  text_right(390, 8, 0.4, color.yellow, "Record " .. best())
  if not alive then
    rrect(100, 80, 200, 80, 12, rgb(0, 0, 0, 190))
    text_center(200, 92, 0.65, color.white, "Chocaste")
    text_center(200, 128, 0.4, color.gray, "A: reintentar   B: menu")
  end
end

function draw_bottom()
  text_center(160, 24, 0.55, color.green, "Lluvia de cubos")
  text_center(160, 70, 0.4, color.white, "Cruceta / stick: mover")
  text_center(160, 94, 0.4, color.white, "Desliza el lapiz: mover la nave")
  text_center(160, 140, 0.45, color.yellow, string.format("Puntos: %d", math.floor(score)))
  text_center(160, 200, 0.34, color.gray, "START: pausa   B: salir")
end
