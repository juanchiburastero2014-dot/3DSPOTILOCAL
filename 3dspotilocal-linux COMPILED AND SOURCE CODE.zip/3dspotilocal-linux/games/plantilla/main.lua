-- PLANTILLA: copia esta carpeta, cambia el nombre y editala. Guia completa: docs/CREAR_MINIJUEGOS.md
-- Se carga al abrir el juego. Esta parte solo debe DEFINIR cosas (no dibujes ni uses la entrada aca).

GAME = {
  title = "Mi primer juego",                  -- nombre en el menu
  description = "Mueve el circulo con la cruceta / stick.",
}

local x, y, score

function init()                    -- se llama una vez al abrir el juego
  x, y, score = 200, 120, 0
end

function update(dt)                -- se llama cada frame; dt = segundos desde el frame anterior
  local sx, sy = stick()           -- -1..1 (arriba = -1). Tambien responde a la cruceta
  x = clamp(x + sx * 160 * dt, 10, TOP_W - 10)
  y = clamp(y + sy * 160 * dt, 10, TOP_H - 10)
  if pressed("a") then score = score + 1 end    -- pressed = recien apretado, btn = mantenido
end

function draw_top()                -- pantalla de arriba (400x240)
  gradient(0, 0, TOP_W, TOP_H, rgb(20, 24, 40), rgb(10, 12, 20))
  circle(x, y, 12, color.green)
  text(10, 8, 0.5, color.white, "Puntos: " .. score)
end

function draw_bottom()             -- pantalla tactil (320x240)
  text_center(160, 100, 0.5, color.white, "A suma un punto")
  local tx, ty = touch()           -- posicion del lapiz/mouse, o nil si no toca
  if tx then circle(tx, ty, 10, color.pink) end
end
