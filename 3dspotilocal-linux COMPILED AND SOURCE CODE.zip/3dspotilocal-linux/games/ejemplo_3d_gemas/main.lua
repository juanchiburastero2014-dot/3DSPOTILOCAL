-- Gemas 3D: ejemplo con camara 3D (scene3d / cube / sphere3 / floor3).
-- Cruceta/stick: arriba-abajo camina, izq-der gira | L / R: pasos laterales | Junta las 8 gemas antes de que acabe el tiempo.

GAME = {
  title = "Gemas 3D",
  description = "Junta gemas en una arena 3D. Ejemplo de juego 3D facil.",
}

local px, pz, yaw, gems, got, t, state, pillars

function init()
  px, pz, yaw = 0, -6, 0
  got, t, state = 0, 40, "play"
  gems, pillars = {}, {}
  for i = 1, 8 do gems[i] = { x = rnd() * 16 - 8, z = rnd() * 16 - 8, y = 1.1 } end
  for i = 1, 14 do
    local x, z = rnd() * 22 - 11, rnd() * 22 - 11
    if math.abs(x) + math.abs(z) > 3 then
      pillars[#pillars + 1] = { x = x, z = z, h = rnd() * 2 + 1.2, c = ({ color.blue, color.purple, color.orange, color.pink })[rnd(1, 4)] }
    end
  end
end

function update(dt)
  if state ~= "play" then
    if pressed("a") then init() end
    return
  end
  t = t - dt
  local sx, sy = stick()
  yaw = yaw + sx * 1.9 * dt
  local f = -sy * 5 * dt
  local s = ((btn("r") and 1 or 0) - (btn("l") and 1 or 0)) * 5 * dt
  px = clamp(px + math.sin(yaw) * f + math.cos(yaw) * s, -11, 11)
  pz = clamp(pz + math.cos(yaw) * f - math.sin(yaw) * s, -11, 11)
  for i = #gems, 1, -1 do
    if dist(px, pz, gems[i].x, gems[i].z) < 1.0 then table.remove(gems, i); got = got + 1 end
  end
  if #gems == 0 then state = "win"; submit_score(math.floor(t * 10) + 100)
  elseif t <= 0 then state = "lose" end
end

function draw_top()
  scene3d(px, 1.5, pz, yaw, -0.08, 72, 0, 0, TOP_W, TOP_H, rgb(18, 28, 70), rgb(120, 170, 230))
  floor3(0, 0, 26, 13, 0, rgb(46, 66, 64), rgb(36, 52, 52))
  for _, p in ipairs(pillars) do cube(p.x, p.h / 2, p.z, 1.2, p.h, 1.2, p.c) end
  local clock = time()
  for _, g in ipairs(gems) do
    sphere3(g.x, g.y + math.sin(clock * 3 + g.x) * 0.15, g.z, 0.38, color.cyan)
    cube(g.x, g.y + 0.9, g.z, 0.12, 0.5 + math.sin(clock * 5 + g.z) * 0.1, 0.12, color.yellow)
  end
  scene3d_end()
  text(8, 6, 0.45, color.white, string.format("Gemas %d/8", got))
  text_right(392, 6, 0.45, t < 10 and color.red or color.yellow, string.format("%d s", math.max(0, math.ceil(t))))
  line(193, 120, 207, 120, 1.5, rgb(255, 255, 255, 180)); line(200, 113, 200, 127, 1.5, rgb(255, 255, 255, 180))
  if state ~= "play" then
    rrect(90, 80, 220, 80, 12, rgb(0, 0, 0, 200))
    text_center(200, 92, 0.65, color.white, state == "win" and "Ganaste" or "Se acabo el tiempo")
    text_center(200, 128, 0.4, color.gray, "A: reintentar   B: menu")
  end
end

function draw_bottom()
  gradient(0, 0, BOT_W, BOT_H, rgb(12, 16, 26), rgb(20, 24, 40))
  local cx, cy, sc = 160, 120, 8
  ring(cx, cy, 100, 1.5, rgb(255, 255, 255, 40))
  ring(cx, cy, 50, 1, rgb(255, 255, 255, 25))
  for _, g in ipairs(gems) do
    local dx, dz = g.x - px, g.z - pz
    local rx = dx * math.cos(yaw) - dz * math.sin(yaw)
    local rz = dx * math.sin(yaw) + dz * math.cos(yaw)
    if rx * rx + rz * rz < 12 * 12 then circle(cx + rx * sc, cy - rz * sc, 4, color.cyan) end
  end
  tri(cx - 6, cy + 8, cx + 6, cy + 8, cx, cy - 8, color.green)
  text_center(160, 8, 0.4, color.gray, "Radar")
  text_center(160, 226, 0.32, color.gray, "START: pausa   B: salir")
end
