# 3dSpotiLocal para Linux

Port a Linux de tu app de 3DS: reproductor de música y video local, letras, carátulas, 23 minijuegos y
un motor para **crear tus propios minijuegos en Lua** (2D, 2.5D y 3D).

## Qué trae respecto a la versión de 3DS

| | |
|---|---|
| Interfaz | **Una sola interfaz que llena toda la ventana** (ya no son dos pantallitas de 3DS): barra lateral, grilla de álbumes, reproductor con letras, lista de videos, juegos y ajustes. Se adapta a cualquier tamaño de ventana, con zoom (F3 / F4). Con `--clasico` volvés a las dos pantallas de la 3DS. |
| Gráficos | Todo se dibuja a mayor resolución y se escala con filtro: formas suaves, texto vectorial nítido (FreeType), sombras y degradés. |
| Animaciones | Transición entre pantallas, cursor y pestañas que se deslizan, barra de progreso suave, repetición de teclas al mantener una dirección. Todo independiente de los fps. |
| Video | **mp4, mkv, webm, avi, mov...** (lo que lea ffmpeg), con audio sincronizado, seek y pausa. **Ocupa toda la ventana** (modo cine); los controles aparecen al mover el mouse. |
| Audio | mp3, wav, ogg, flac (como antes) + m4a, aac, opus, wma (se convierten una vez con ffmpeg y quedan en caché). |
| Controles | Teclado, gamepad y mouse (ver abajo). |
| Minijuegos | Los 23 de siempre + los tuyos en `~/3dSpotiLocal/Games/`. |

## 1. Instalar dependencias

```sh
sh install_deps.sh
```
(detecta apt / dnf / pacman / zypper). A mano, necesitás: compilador C, `make`, `pkg-config`,
**SDL2**, **FreeType**, **Lua 5.4** (paquetes `-dev`/`-devel`) y **ffmpeg** (incluye `ffprobe`).

| Distro | Paquetes |
|---|---|
| Debian / Ubuntu / Mint | `build-essential pkg-config libsdl2-dev libfreetype-dev liblua5.4-dev ffmpeg` |
| Fedora | `gcc make pkgconf-pkg-config SDL2-devel freetype-devel lua-devel ffmpeg-free` |
| Arch / Manjaro | `base-devel pkgconf sdl2 freetype2 lua ffmpeg` |

## 2. Compilar y ejecutar

```sh
make            # genera ./3dspotilocal
./3dspotilocal
```
Opcional: `sudo make install` (a `/usr/local`; con `PREFIX=/usr` para otro destino).

## 3. Tus archivos

La primera vez se crea `~/3dSpotiLocal/` (o la carpeta de `--data DIR` / `$SPOTILOCAL_HOME`):

```
~/3dSpotiLocal/
  Music/    <Álbum>/*.mp3 ...        (igual que en la 3DS: una carpeta por álbum)
  Videos/   *.mp4 *.mkv ...
  Covers/   imágenes para elegir carátulas
  Lyrics/   letras
  Games/    tus minijuegos en Lua (la primera vez se copian 4 de ejemplo)
```
Si ya tenías la tarjeta SD de la 3DS, copiá el contenido de `SD:/3dSpotiLocal/` ahí. Los videos `.v3v` de la 3DS
ya no hacen falta: ffmpeg reproduce los originales.

## Controles

| 3DS | Teclado | Gamepad |
|---|---|---|
| Cruceta | Flechas | Cruceta |
| Circle pad | W A S D | Stick izquierdo |
| A / B | Enter o J / Backspace, Esc o K | botón derecho / inferior |
| X / Y | U / I | superior / izquierdo |
| L / R | Q / E | gatillos |
| START / SELECT | Espacio / Tab | Start / Back |
| Mouse | **Clic** en tarjetas, botones y barras (también arrastrar la barra de progreso) · **rueda** = desplazar · **clic derecho** = volver | |
| Pantalla táctil (en los juegos) | el mouse hace de lápiz sobre el panel táctil | |

Video: **clic** sobre la imagen = pausa/reanudar · **doble clic** = pantalla completa · **rueda** = ±5 s · flechas izq/der = ±5 s · mové el mouse para ver los controles.

En los menús: **Y / Tab** = siguiente sección · **Espacio** = pausa de la música · **B / Esc / Backspace** = volver · en el reproductor **Q / E** = ±5 s.

Ventana: **F11** pantalla completa · **F3 / F4** achicar / agrandar la interfaz · **F2** (en los juegos) cambia la disposición de las dos pantallas: lado a lado, apiladas o **grande** (la de arriba ocupa la ventana y la táctil flota en una esquina) · **F12** captura (se guarda en `~/3dSpotiLocal`).

Opciones: `./3dspotilocal --help` (`--data`, `--size 1600x900`, `--fullscreen`, `--clasico`, `--software` si tu GPU da problemas).

> **Juegos:** los 23 integrados y los de Lua fueron diseñados para dos pantallas (400×240 y 320×240), así que dentro de un juego se siguen viendo las dos; el layout **grande** (F2) es el que más llena la ventana.

## Crear tus minijuegos

Mirá **[docs/CREAR_MINIJUEGOS.md](docs/CREAR_MINIJUEGOS.md)**. En resumen: una carpeta con un `main.lua` y estas funciones:

```lua
GAME = { title = "Mi juego", description = "..." }
function init() end
function update(dt) end
function draw_top() end      -- pantalla de arriba 400x240
function draw_bottom() end   -- pantalla táctil 320x240
```
Hay helpers para 2D (formas, sprites, colisiones), **2.5D** (`raycast(...)`, un shooter/laberinto estilo Doom en una llamada)
y **3D** (`scene3d`, `cube`, `sphere3`, `floor3`...). Los ejemplos de `Games/` cubren los tres. Los scripts corren aislados:
sin acceso a archivos ni comandos, y con límite de tiempo por frame.

## Probar que todo anda

```sh
make selftest
```
Recorre pantallas, reproductor, video y todos los juegos (builtin y Lua) sin abrir ventana y deja capturas en `selftest_out/`.
Si algo falla, te dice qué. Sirve para reportar problemas.

## Problemas comunes

* **"No se pudo abrir el video"** → falta `ffmpeg`/`ffprobe` en el PATH.
* **Sin sonido** → mirá que `SDL_AUDIODRIVER` no esté forzado a `dummy`; en PipeWire/PulseAudio SDL2 anda directo.
* **Pantalla negra o lenta** → `./3dspotilocal --software`.
* **Texto cuadrado/sin fuente** → la fuente viene en `assets/fonts`; ejecutá el binario desde la carpeta del proyecto o instalá con `make install`.
* **Lua no se encuentra al compilar** → `make LUA_PKG=lua5.4` (o el nombre que te muestre `pkg-config --list-all | grep -i lua`).

## Estructura del código

* `source/` – lógica de la app y los juegos (la misma de la 3DS) + capa nueva: `gfx_ui.c` (SDL2/FreeType), `ui_desktop.c` (la interfaz de escritorio; `ui_screens.c` es la clásica de 3DS), `audio_out.c`,
  `video.c` (ffmpeg), `script.c` (Lua), `platform.[ch]` (tipos y rutas), `app_frame.c` (un frame de la app), `selftest.c`.
* `tools/` – `translations.py` + `gen_i18n.py` (regeneran `i18n_data.h`: `make i18n`).
* `games/` – juegos Lua de ejemplo. `assets/` – fuentes e ícono.

Licencias: fuentes Liberation Sans (SIL OFL), stb / dr_libs / minimp3 en `third_party/` (dominio público / MIT).
