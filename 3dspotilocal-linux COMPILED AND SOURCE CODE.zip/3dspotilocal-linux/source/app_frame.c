/* app_frame.c - un frame de la aplicacion (entrada + logica + dibujo + transiciones). */
#include "app.h"
#include "gfx_ui.h"
#include "ui_screens.h"
#include "script.h"
#include "ui_desktop.h"

static struct {
    bool   wasTouch, dragged;
    int    startX, startY, lastY, accum;
    Screen prevScreen;
    bool   init;
    double transStart;
} st;

#define TRANS_SECS 0.30

void app_frame(App *app, const UiInput *in) {
    if (!st.init) { st.init = true; st.prevScreen = app->screen; st.transStart = -10; }

    /* UI de escritorio: un lienzo unico del tamano de la ventana (los juegos usan las dos pantallas) */
    bool desktop = !g_classic_ui && app->screen != SCREEN_GAME;
    ui_set_desktop(desktop);
    if (desktop) {
        if (app->screen == SCREEN_VIDEO && app->video) video_update(app->video);
        else player_update(&app->player);
        if (app->screen == SCREEN_VIDEO && app->video) ui_cinema(video_image(app->video), video_is_paused(app->video));
        else { C2D_Image none = { NULL, 0, 0 }; ui_cinema(none, false); }
        desk_frame(app, in);
        app->frames++;
        return;
    }
    { C2D_Image none = { NULL, 0, 0 }; ui_cinema(none, false); }

    /* los menus aceptan repeticion al mantener una direccion; los juegos quieren la pulsacion pura */
    u32 down = app->screen == SCREEN_GAME ? in->down : in->downRepeat;
    screens_key(app, down);

    bool touching = in->touching;
    if (app->screen == SCREEN_GAME) {
        if (touching && !st.wasTouch) game_touch(in->touchX, in->touchY);
        st.dragged = false;
    } else if (touching && !st.wasTouch) {
        st.startX = in->touchX; st.startY = in->touchY; st.lastY = in->touchY;
        st.accum = 0; st.dragged = false;
    } else if (touching && st.wasTouch) {
        st.accum += in->touchY - st.lastY;
        st.lastY = in->touchY;
        if (st.accum > 40)       { screens_scroll(app, -1); st.accum = 0; st.dragged = true; }
        else if (st.accum < -40) { screens_scroll(app, +1); st.accum = 0; st.dragged = true; }
        if (abs(in->touchX - st.startX) > 20 || abs(in->touchY - st.startY) > 20) st.dragged = true;
    } else if (!touching && st.wasTouch) {
        if (!st.dragged) screens_touch(app, st.startX, st.startY);
    }
    st.wasTouch = touching;
    if (in->wheel != 0 && app->screen == SCREEN_VIDEO && app->video) {
        u64 p = video_position_ms(app->video);
        long long np = (long long)p + (long long)in->wheel * 5000;
        video_seek(app->video, np < 0 ? 0 : (u64)np);
    } else if (in->wheel != 0 && app->screen != SCREEN_GAME) {
        int n = in->wheel > 0 ? in->wheel : -in->wheel;
        for (int i = 0; i < n && i < 4; i++) screens_scroll(app, in->wheel > 0 ? -1 : +1);
    }

    if (app->screen == SCREEN_GAME) {
        GameInput gi = { in->down, in->held, in->circleX, in->circleY, ui_dt(), in->touchX, in->touchY };
        game_update(gi);
        player_update(&app->player);   /* la musica de fondo sigue en los juegos rapidos */
        if (script_exit_requested()) screens_back(app);
    } else {
        if (app->screen == SCREEN_VIDEO && app->video) video_update(app->video);
        else player_update(&app->player);
    }

    /* transicion al cambiar de pantalla: fundido + leve deslizamiento */
    if (app->screen != st.prevScreen) {
        st.prevScreen = app->screen;
        st.transStart = ui_time();
    }
    double tt = (ui_time() - st.transStart) / TRANS_SECS;
    if (tt >= 0 && tt < 1.0 && app->screen != SCREEN_VIDEO) {
        float e = ui_ease_out((float)tt);
        ui_set_fade((1.0f - e) * 0.60f);
        ui_set_offset(0, (1.0f - e) * 9.0f);
    }

    if (app->screen == SCREEN_VIDEO && app->video) ui_cinema(video_image(app->video), video_is_paused(app->video));
    else { C2D_Image none = { NULL, 0, 0 }; ui_cinema(none, false); }
    screens_draw_top(app);
    screens_draw_bottom(app);
    ui_set_offset(0, 0);
    app->frames++;
}
