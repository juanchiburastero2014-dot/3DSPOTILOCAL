#include "audio.h"
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define MINIMP3_NO_STDIO
#include "minimp3_ex.h"

#define DR_FLAC_IMPLEMENTATION
#include "dr_flac.h"

#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

/* stb_vorbis.c is a full implementation translation unit. */
#include "stb_vorbis.c"

typedef enum { FMT_MP3, FMT_WAV, FMT_OGG, FMT_FLAC } Format;

struct AudioStream {
    Format      fmt;
    int         rate;
    int         channels;
    u64         totalFrames;
    s16        *tmp;
    mp3dec_ex_t mp3;
    mp3dec_io_t mp3io;
    FILE       *mp3file;
    drflac     *flac;
    drwav       wav;
    bool        wavReady;
    stb_vorbis *ogg;
};

static bool ext_is(const char *path, const char *ext) {
    const char *dot = strrchr(path, '.');
    if (!dot) return false;
    dot++;
    for (size_t i = 0; dot[i] && ext[i]; i++)
        if (tolower((unsigned char)dot[i]) != tolower((unsigned char)ext[i])) return false;
    return strlen(dot) == strlen(ext);
}

static void to_stereo(s16 *out, const s16 *in, int srcCh, size_t frames) {
    if (srcCh == 2) {
        memcpy(out, in, frames * 2 * sizeof(s16));
    } else if (srcCh == 1) {
        for (size_t i = 0; i < frames; i++) {
            s16 v = in[i];
            out[2 * i] = v;
            out[2 * i + 1] = v;
        }
    } else {
        for (size_t i = 0; i < frames; i++) {
            out[2 * i]     = in[i * srcCh];
            out[2 * i + 1] = in[i * srcCh + 1];
        }
    }
}

static size_t mp3_read_file(void *buffer, size_t size, void *file) {
    return fread(buffer, 1, size, file);
}

static int mp3_seek_file(uint64_t offset, void *file) {
    if (offset > LONG_MAX) return -1;
    return fseek(file, (long)offset, SEEK_SET);
}


/* m4a / aac / opus / wma y otros: se convierten una vez a WAV con ffmpeg (queda en cache) y se reproducen desde ahi. */
static bool convert_with_ffmpeg(const char *path, char *outWav, size_t n) {
    char dir[PATH_MAX_LEN + 16];
    snprintf(dir, sizeof(dir), "%s/.cache", g_dir_base);
    mkdir(dir, 0777);
    u32 h = 2166136261u;
    for (const char *p = path; *p; p++) h = (h ^ (unsigned char)*p) * 16777619u;
    snprintf(outWav, n, "%s/%08x.wav", dir, h);
    if (file_exists(outWav)) return true;
    char part[MAX_PATH + 8];
    snprintf(part, sizeof(part), "%s.part.wav", outWav);
    pid_t pid = fork();
    if (pid < 0) return false;
    if (pid == 0) {
        if (!freopen("/dev/null", "w", stderr) || !freopen("/dev/null", "w", stdout) || !freopen("/dev/null", "r", stdin)) _exit(126);
        execlp("ffmpeg", "ffmpeg", "-v", "error", "-y", "-i", path, "-vn", "-ac", "2", "-f", "wav", part, (char *)NULL);
        _exit(127);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) { remove(part); return false; }
    return rename(part, outWav) == 0;
}

static const char *const FFMPEG_EXTS[] = { "m4a", "aac", "opus", "wma", "mp4", "mka", "ape", "wv", "aiff", "aif", NULL };

static bool needs_ffmpeg(const char *path) {
    for (int i = 0; FFMPEG_EXTS[i]; i++) if (ext_is(path, FFMPEG_EXTS[i])) return true;
    return false;
}

AudioStream *audio_open(const char *origPath) {
    char converted[MAX_PATH + 32];
    const char *path = origPath;
    if (needs_ffmpeg(origPath)) {
        if (!convert_with_ffmpeg(origPath, converted, sizeof(converted))) return NULL;
        path = converted;
    }
    AudioStream *s = (AudioStream *)calloc(1, sizeof(AudioStream));
    if (!s) return NULL;

    if (ext_is(path, "mp3")) {
        s->fmt = FMT_MP3;
        s->mp3file = fopen(path, "rb");
        if (!s->mp3file) goto fail;
        s->mp3io = (mp3dec_io_t){mp3_read_file, s->mp3file, mp3_seek_file, s->mp3file};
        if (mp3dec_ex_open_cb(&s->mp3, &s->mp3io, MP3D_SEEK_TO_SAMPLE) != 0) goto fail;
        s->rate = s->mp3.info.hz;
        s->channels = s->mp3.info.channels;
        s->totalFrames = s->channels ? s->mp3.samples / s->channels : 0;
    } else if (ext_is(path, "wav")) {
        s->fmt = FMT_WAV;
        if (!drwav_init_file(&s->wav, path, NULL)) goto fail;
        s->wavReady = true;
        s->rate = s->wav.sampleRate;
        s->channels = s->wav.channels;
        s->totalFrames = s->wav.totalPCMFrameCount;
    } else if (ext_is(path, "ogg") || ext_is(path, "oga")) {
        s->fmt = FMT_OGG;
        int err = 0;
        s->ogg = stb_vorbis_open_filename(path, &err, NULL);
        if (!s->ogg) goto fail;
        s->rate = s->ogg->sample_rate;
        s->channels = s->ogg->channels;
        s->totalFrames = stb_vorbis_stream_length_in_samples(s->ogg);
    } else if (ext_is(path, "flac")) {
        s->fmt = FMT_FLAC;
        s->flac = drflac_open_file(path, NULL);
        if (!s->flac) goto fail;
        s->rate = s->flac->sampleRate;
        s->channels = s->flac->channels;
        s->totalFrames = s->flac->totalPCMFrameCount;
    } else {
        goto fail;
    }

    if (s->rate <= 0 || s->channels <= 0) goto fail;
    if (s->fmt != FMT_OGG) {
        s->tmp = (s16 *)malloc(AUDIO_CHUNK_FRAMES * s->channels * sizeof(s16));
        if (!s->tmp) goto fail;
    }
    return s;

fail:
    audio_close(s);
    return NULL;
}

void audio_close(AudioStream *s) {
    if (!s) return;
    switch (s->fmt) {
        case FMT_MP3:  mp3dec_ex_close(&s->mp3); break;
        case FMT_WAV:  if (s->wavReady) drwav_uninit(&s->wav); break;
        case FMT_OGG:  if (s->ogg) stb_vorbis_close(s->ogg); break;
        case FMT_FLAC: if (s->flac) drflac_close(s->flac); break;
    }
    if (s->mp3file) fclose(s->mp3file);
    free(s->tmp);
    free(s);
}

int audio_sample_rate(const AudioStream *s) { return s->rate; }
u64 audio_total_frames(const AudioStream *s) { return s->totalFrames; }

u64 audio_tell(const AudioStream *s) {
    switch (s->fmt) {
        case FMT_MP3:  return s->channels ? s->mp3.cur_sample / s->channels : 0;
        case FMT_WAV:  return s->wav.readCursorInPCMFrames;
        case FMT_OGG: {
            int offset = stb_vorbis_get_sample_offset(s->ogg);
            return offset < 0 ? 0 : (u64)offset;
        }
        case FMT_FLAC: return s->flac->currentPCMFrame;
    }
    return 0;
}

bool audio_seek(AudioStream *s, u64 frame) {
    switch (s->fmt) {
        case FMT_MP3:  return mp3dec_ex_seek(&s->mp3, frame * s->channels) == 0;
        case FMT_WAV:  return drwav_seek_to_pcm_frame(&s->wav, frame) != 0;
        case FMT_OGG:  return stb_vorbis_seek(s->ogg, (unsigned int)frame) != 0;
        case FMT_FLAC: return drflac_seek_to_pcm_frame(s->flac, frame) != 0;
    }
    return false;
}

size_t audio_read(AudioStream *s, s16 *out, size_t maxFrames) {
    if (maxFrames > AUDIO_CHUNK_FRAMES) maxFrames = AUDIO_CHUNK_FRAMES;
    size_t frames = 0;
    switch (s->fmt) {
        case FMT_MP3: {
            size_t got = mp3dec_ex_read(&s->mp3, s->tmp, maxFrames * s->channels);
            frames = s->channels ? got / s->channels : 0;
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        }
        case FMT_WAV:
            frames = (size_t)drwav_read_pcm_frames_s16(&s->wav, maxFrames, s->tmp);
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        case FMT_FLAC:
            frames = (size_t)drflac_read_pcm_frames_s16(s->flac, maxFrames, s->tmp);
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        case FMT_OGG:
            frames = (size_t)stb_vorbis_get_samples_short_interleaved(s->ogg, 2, out, (int)(maxFrames * 2));
            break;
    }
    return frames;
}


/* ---- Volume booster: ganancia por software con limitador suave ---- */
static float gainValue = 1.0f;

void audio_set_gain(float gain) {
    if (gain < 1.0f) gain = 1.0f;
    if (gain > 4.0f) gain = 4.0f;
    gainValue = gain;
}

void audio_apply_gain(s16 *p, size_t frames) {
    if (gainValue <= 1.001f || !p) return;
    int g = (int)(gainValue * 256.0f);
    for (size_t i = 0; i < frames * 2; i++) {
        int v = ((int)p[i] * g) >> 8;
        int a = v < 0 ? -v : v;
        if (a > 24000) {                       /* rodilla suave en vez de recorte duro */
            a = 24000 + (a - 24000) / 4;
            if (a > 32767) a = 32767;
            v = v < 0 ? -a : a;
        }
        p[i] = (s16)v;
    }
}
