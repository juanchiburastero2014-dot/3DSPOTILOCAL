#ifndef VIBRA_SETTINGS_H
#define VIBRA_SETTINGS_H

#include "common.h"

#define SETTINGS_PATH g_path_settings
#define MAX_GAME_SCORES 32

typedef struct {
    int  lang;           /* Lang (see i18n.h) */
    int  boost;          /* index into the volume booster table */
    bool lyricsAuto;     /* open the lyrics view automatically when a song has a .txt */
    int  difficulty;     /* 0 easy, 1 normal, 2 hard */
    bool gameMusic;      /* keep music playing during the quick games */
    int  accent;         /* 0..3 */
    bool startShuffle;
    int  startRepeat;    /* RepeatMode */
    int  best[MAX_GAME_SCORES];
} Settings;

extern Settings g_settings;

typedef enum { ACT_NONE, ACT_RELOAD, ACT_RESET } SettingAction;

void settings_load(void);
void settings_save(void);
void settings_reset(void);                  /* factory defaults (records are kept) */
void settings_apply(void);                  /* push values to audio and the accent colour */

int  setting_count(void);
const char *setting_name(int i);
const char *setting_help(int i);
void setting_value(int i, char *out, size_t n);
SettingAction setting_action(int i);        /* ACT_NONE for ordinary rows */
void setting_change(int i, int dir);        /* dir: +1 / -1 */

/* High scores kept by the minigames; saved lazily. */
void settings_note_score(int kind, int score);
int  settings_best(int kind);
void settings_flush(void);

#endif
