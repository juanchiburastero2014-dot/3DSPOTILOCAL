#include "app.h"
#include "gfx_ui.h"
#include "image.h"
#include "library.h"
#include "settings.h"
#include "covers.h"
#include "i18n.h"
#include "ui_screens.h"
#include "script.h"
#include "ui_desktop.h"
#include <signal.h>
#include <unistd.h>
#include <limits.h>

void app_init(App *app, Library *lib) {
    memset(app, 0, sizeof(*app));
    app->lib = lib;
    player_init(&app->player, lib);
    app->screen = SCREEN_LIBRARY;
    app->videoIndex = -1;
    app->running = true;
    app->player.shuffle = g_settings.startShuffle;
    app->player.repeat = (RepeatMode)g_settings.startRepeat;
}

void app_exit(App *app) {
    game_stop();
    lyrics_free();
    settings_flush();
    app_close_video(app);
    player_exit(&app->player);
}

void app_open_video(App *app, int index) {
    app_close_video(app);
    player_stop(&app->player);
    app->video = video_open(app->lib->videos[index].path);
    if (app->video) {
        app->videoIndex = index;
        video_play(app->video);
        app->screen = SCREEN_VIDEO;
    } else {
        snprintf(app->error, sizeof(app->error), "%s", tr("No se pudo abrir el video (hace falta ffmpeg instalado)."));
    }
}

void app_close_video(App *app) {
    if (app->video) {
        video_close(app->video);
        app->video = NULL;
    }
    app->videoIndex = -1;
}

int selftest_run(const char *outDir);

static void usage(const char *argv0) {
    printf("3dSpotiLocal para Linux\n\n"
           "Uso: %s [opciones]\n"
           "  --data DIR        carpeta de datos (por defecto ~/3dSpotiLocal, o $SPOTILOCAL_HOME)\n"
           "  --size ANCHOxALTO tamano inicial de la ventana (por defecto 1280x720)\n"
           "  --fullscreen      arrancar en pantalla completa\n"
           "  --software        forzar el render por software (si tu GPU da problemas)\n"
           "  --clasico         usar la interfaz de dos pantallas de la 3DS en vez de la de escritorio\n"
           "  --selftest DIR    prueba rapida sin ventana visible: recorre pantallas y juegos y guarda capturas en DIR\n"
           "  --help            esta ayuda\n\n"
           "Teclas: flechas = cruceta | WASD = circle pad | Enter/J = A | Backspace/Esc/K = B | U = X | I = Y\n"
           "        Q/E = L/R | Espacio = START | Tab = SELECT | F11 = pantalla completa | F3/F4 = zoom de la interfaz\n"
           "        F2 = disposicion de las dos pantallas en los juegos\n"
           "        F12 = captura | mouse = lapiz de la pantalla tactil (rueda para desplazar)\n", argv0);
}

int main(int argc, char **argv) {
    const char *dataDir = NULL, *selftestDir = NULL;
    int winW = 1280, winH = 720;
    bool software = false, fullscreen = false;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { usage(argv[0]); return 0; }
        else if (!strcmp(argv[i], "--data") && i + 1 < argc) dataDir = argv[++i];
        else if (!strcmp(argv[i], "--size") && i + 1 < argc) { if (sscanf(argv[++i], "%dx%d", &winW, &winH) != 2) { winW = 1280; winH = 720; } }
        else if (!strcmp(argv[i], "--software")) software = true;
        else if (!strcmp(argv[i], "--clasico") || !strcmp(argv[i], "--classic")) g_classic_ui = true;
        else if (!strcmp(argv[i], "--fullscreen")) fullscreen = true;
        else if (!strcmp(argv[i], "--selftest") && i + 1 < argc) { selftestDir = argv[++i]; software = true; }
        else { fprintf(stderr, "Opcion desconocida: %s (probá --help)\n", argv[i]); return 2; }
    }
    signal(SIGPIPE, SIG_IGN);

    char exeDir[PATH_MAX_LEN] = "";
    ssize_t n = readlink("/proc/self/exe", exeDir, sizeof(exeDir) - 1);
    if (n > 0) { exeDir[n] = '\0'; char *slash = strrchr(exeDir, '/'); if (slash) *slash = '\0'; } else exeDir[0] = '\0';
    platform_init_paths(dataDir, exeDir);

    if (!audio_out_init()) fprintf(stderr, "Aviso: no se pudo iniciar el audio. Sigo sin sonido.\n");
    Library *lib = (Library *)calloc(1, sizeof(Library));
    if (!lib || !ui_init("3dSpotiLocal", winW, winH, software)) {
        fprintf(stderr, "No se pudo iniciar la ventana/grafica.\n");
        free(lib);
        audio_out_exit();
        return 1;
    }
    if (fullscreen) ui_toggle_fullscreen();
    srand((unsigned)osGetTime());
    library_ensure_dirs();
    settings_load();
    covers_init();
    library_scan(lib);
    script_init();

    int rc = 0;
    if (selftestDir) {
        rc = selftest_run(selftestDir);
    } else {
        App app;
        app_init(&app, lib);
        UiInput in;
        while (app.running && ui_poll_input(&in)) {
            ui_frame_begin();
            app_frame(&app, &in);
            ui_frame_end();
        }
        ui_frame_begin();
        app_exit(&app);
        image_clear_all();
        ui_frame_end();
    }
    script_exit();
    free(lib);
    audio_out_exit();
    ui_exit();
    return rc;
}
