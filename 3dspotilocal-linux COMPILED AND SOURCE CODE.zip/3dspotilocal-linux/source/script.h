#ifndef VIBRA_SCRIPT_H
#define VIBRA_SCRIPT_H

#include "common.h"
#include "games.h"

/* Motor de minijuegos en Lua (2D, 2.5D con raycaster y 3D con camara/cubos).
 * Cada juego es una carpeta en ~/3dSpotiLocal/Games/<nombre>/ con un main.lua. Ver docs/CREAR_MINIJUEGOS.md */

void script_init(void);                         /* escanea la carpeta Games (y copia los ejemplos la primera vez) */
void script_exit(void);
void script_rescan(void);
int  script_count(void);
const char *script_title(int i);
const char *script_description(int i);

bool script_start(int i);                       /* abre el juego i (0..script_count()-1) */
void script_stop(void);
bool script_active(void);
void script_update(GameInput in);
void script_touch(int x, int y);
void script_draw_top(void);
void script_draw_bottom(void);
bool script_errored(void);                      /* el script fallo (hay un mensaje) */
const char *script_error(void);
bool script_exit_requested(void);               /* el juego llamo a quit() */

#endif
