/* selftest.c - prueba rapida sin ventana visible (--selftest DIR).
 * Recorre las pantallas, el reproductor, el video y los minijuegos con entradas sinteticas,
 * guarda capturas .bmp en DIR y avisa si algo falla. Sirve tambien para diagnosticar tu instalacion. */
#include "app.h"
#include "gfx_ui.h"
#include "ui_screens.h"
#include "script.h"
#include "image.h"
#include "library.h"
#include <sys/stat.h>
#include <unistd.h>

static int failures = 0;
static char outDir[PATH_MAX_LEN];

static void check(bool ok, const char *what) {
    printf("  [%s] %s\n", ok ? " OK " : "FAIL", what);
    if (!ok) failures++;
}

static void frames(App *app, int n, u32 (*pattern)(int f, int *cx, int *cy, bool *touch, int *tx, int *ty), int sleepMs);

/* captura de la ventana completa (UI de escritorio o juegos) */
static App *gApp;
static u32 pat_idle(int f, int *cx, int *cy, bool *t, int *tx, int *ty);
static void shot(const char *name) {
    char a[PATH_MAX_LEN + 96];
    snprintf(a, sizeof(a), "%s/%s.bmp", outDir, name);
    ui_request_screenshot(a);
    if (gApp) frames(gApp, 1, pat_idle, 0);
}

static void frames(App *app, int n, u32 (*pattern)(int f, int *cx, int *cy, bool *touch, int *tx, int *ty), int sleepMs) {
    static u32 prev;
    static bool prevTouch;
    for (int f = 0; f < n; f++) {
        UiInput in;
        memset(&in, 0, sizeof(in));
        if (pattern) in.held = pattern(f, &in.circleX, &in.circleY, &in.touching, &in.touchX, &in.touchY);
        in.down = in.held & ~prev;
        in.downRepeat = in.down;
        prev = in.held;
        (void)prevTouch;
        ui_frame_begin();
        app_frame(app, &in);
        ui_frame_end();
        if (sleepMs > 0) usleep((useconds_t)sleepMs * 1000);
    }
}

static u32 pat_idle(int f, int *cx, int *cy, bool *t, int *tx, int *ty) { (void)f; (void)cx; (void)cy; (void)t; (void)tx; (void)ty; return 0; }

static u32 pat_game(int f, int *cx, int *cy, bool *t, int *tx, int *ty) {
    static const u32 seq[] = { KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN, KEY_A, KEY_X, KEY_Y, KEY_L, KEY_R };   /* sin B: B sale del juego */
    u32 held = seq[(f / 7) % 9];
    if ((f / 5) % 3 == 0) held |= KEY_A;
    *cx = ((f / 9) % 3 - 1) * 120;
    *cy = ((f / 11) % 3 - 1) * 120;
    if (f % 40 > 25) { *t = true; *tx = 20 + (f * 37) % 280; *ty = 20 + (f * 53) % 200; }
    return held;
}

int selftest_run(const char *dir) {
    snprintf(outDir, sizeof(outDir), "%s", dir);
    mkdir(dir, 0777);
    printf("== 3dSpotiLocal selftest ==\n");
    Library *lib = (Library *)calloc(1, sizeof(Library));
    library_scan(lib);
    printf("biblioteca: %d albumes, %d videos\n", lib->albumCount, lib->videoCount);
    App app;
    app_init(&app, lib);
    gApp = &app;
    if (getenv("SELFTEST_LAYOUT")) for (int i = atoi(getenv("SELFTEST_LAYOUT")); i > 0; i--) ui_cycle_layout();

    /* ---- pantallas de la UI ---- */
    frames(&app, 12, pat_idle, 0);
    shot("01_library");
    check(true, "pantalla Biblioteca dibujada");
    if (lib->albumCount > 0) {
        app.albumViewIdx = 0; app.screen = SCREEN_ALBUM;
        frames(&app, 12, pat_idle, 0);
        shot("02_album");
        check(player_play_track(&app.player, 0, 0), "abrir y reproducir la primera cancion");
        app.screen = SCREEN_PLAYING;
        frames(&app, 60, pat_idle, 16);
        u64 p1 = player_position_ms(&app.player);
        frames(&app, 60, pat_idle, 16);
        u64 p2 = player_position_ms(&app.player);
        printf("  posicion: %llu ms -> %llu ms\n", (unsigned long long)p1, (unsigned long long)p2);
        check(p2 > p1 + 500, "el audio avanza (reloj del reproductor)");
        shot("03_playing");
        player_toggle_pause(&app.player);
        frames(&app, 10, pat_idle, 16);
        u64 p3 = player_position_ms(&app.player);
        frames(&app, 20, pat_idle, 16);
        check(player_position_ms(&app.player) == p3, "la pausa detiene la posicion");
        player_toggle_pause(&app.player);
        check(player_seek_ms(&app.player, 3000), "seek a 3 s");
        frames(&app, 5, pat_idle, 16);
        check(player_position_ms(&app.player) >= 2900, "la posicion refleja el seek");
        player_stop(&app.player);
    } else {
        printf("  (sin musica en %s: se omite el reproductor)\n", g_dir_music);
    }
    app.screen = SCREEN_VIDEOS;
    frames(&app, 12, pat_idle, 0);
    shot("04_videos");
    if (lib->videoCount > 0) {
        app_open_video(&app, 0);
        check(app.video != NULL && app.screen == SCREEN_VIDEO, "abrir video (ffmpeg)");
        if (app.video) {
            frames(&app, 90, pat_idle, 16);
            u64 vp = video_position_ms(app.video);
            printf("  video: posicion %llu ms de %llu ms\n", (unsigned long long)vp, (unsigned long long)video_duration_ms(app.video));
            check(vp > 400, "el video avanza");
            {   /* fluidez: el video debe avanzar a su ritmo aunque este loop (render por software) sea lento */
                u64 f0 = video_frames_shown(app.video), w0 = osGetTime(), p0 = video_position_ms(app.video);
                frames(&app, 40, pat_idle, 16);
                u64 f1 = video_frames_shown(app.video), w1 = osGetTime(), p1 = video_position_ms(app.video);
                double wall = (double)(w1 - w0) / 1000.0, vid = (double)(p1 - p0) / 1000.0;
                printf("  video: %llu cuadros nuevos en %.2f s de reloj; el video avanzo %.2f s; terminado=%d\n",
                       (unsigned long long)(f1 - f0), wall, vid, (int)video_finished(app.video));
                check(video_finished(app.video) || (vid > wall * 0.85 && vid < wall * 1.15),
                      "velocidad correcta (sin camara lenta)");
            }
            shot("05_video");
            {   char wp[PATH_MAX_LEN + 64];
                snprintf(wp, sizeof(wp), "%s/05_video_window.bmp", outDir);
                ui_request_screenshot(wp);
                frames(&app, 1, pat_idle, 0);
            }
            video_seek(app.video, 1500);
            frames(&app, 30, pat_idle, 16);
            check(video_position_ms(app.video) >= 1400, "seek de video");
            video_pause(app.video, true);
            u64 pp = video_position_ms(app.video);
            frames(&app, 20, pat_idle, 16);
            check(video_position_ms(app.video) == pp, "pausa de video");
            {   char wp[PATH_MAX_LEN + 64];
                snprintf(wp, sizeof(wp), "%s/05_video_paused_window.bmp", outDir);
                ui_request_screenshot(wp);
                frames(&app, 2, pat_idle, 0);
            }
            app_close_video(&app);
            app.screen = SCREEN_VIDEOS;
        }
    }
    app.screen = SCREEN_GAMES;
    frames(&app, 12, pat_idle, 0);
    shot("06_games");
    app.screen = SCREEN_SETTINGS;
    frames(&app, 12, pat_idle, 0);
    shot("07_settings");
    app.screen = SCREEN_LIBRARY;

    /* ---- minijuegos ---- */
    const char *song = lib->albumCount > 0 ? lib->albums[0].tracks[0].path : NULL;
    for (int k = 0; k < GAME_COUNT; k++) {
        GameKind kind = (GameKind)k;
        if (getenv("SELFTEST_ONLY") && atoi(getenv("SELFTEST_ONLY")) != k) continue;
        bool needs = game_needs_song(kind);
        if (needs && !song) { printf("  (juego %s necesita cancion: omitido)\n", game_title(kind)); continue; }
        if (needs) player_stop(&app.player);
        bool ok = game_start(kind, needs ? song : NULL);
        char msg[160];
        snprintf(msg, sizeof(msg), "juego %d: %s", k, game_title(kind));
        if (!ok) { check(false, msg); continue; }
        app.gameKind = kind;
        app.screen = SCREEN_GAME;
        frames(&app, 150, pat_game, 0);
        bool stillIn = app.screen == SCREEN_GAME;
        char nm[64];
        snprintf(nm, sizeof(nm), "game_%02d", k);
        shot(nm);
        check(stillIn, msg);
        game_stop();
        app.screen = SCREEN_GAMES;
        frames(&app, 2, pat_idle, 0);
    }
    /* ---- minijuegos en Lua ---- */
    for (int i = 0; i < script_count(); i++) {
        char msg[200];
        snprintf(msg, sizeof(msg), "script %d: %s", i, script_title(i));
        if (!game_start((GameKind)(GAME_COUNT + i), NULL)) { check(false, msg); continue; }
        app.gameKind = (GameKind)(GAME_COUNT + i);
        app.screen = SCREEN_GAME;
        frames(&app, 160, getenv("SELFTEST_IDLE") ? pat_idle : pat_game, 0);
        bool ok = !script_errored() && app.screen == SCREEN_GAME;
        if (script_errored()) printf("    error: %s\n", script_error());
        char nm[64];
        snprintf(nm, sizeof(nm), "script_%02d", i);
        shot(nm);
        check(ok, msg);
        game_stop();
        app.screen = SCREEN_GAMES;
        frames(&app, 2, pat_idle, 0);
    }
    app_exit(&app);
    image_clear_all();
    free(lib);
    printf("== %s (%d fallos) ==\n", failures ? "CON FALLOS" : "TODO BIEN", failures);
    return failures ? 1 : 0;
}
