#ifndef VIBRA_VIDEO_H
#define VIBRA_VIDEO_H

#include "common.h"

/* Reproduce cualquier video que entienda ffmpeg (mp4, mkv, webm, avi, mov...).
 * Usa los binarios `ffmpeg` y `ffprobe` (paquete "ffmpeg"): uno decodifica el video a RGBA y otro el audio a PCM,
 * y el reloj de audio manda sobre el video. Sin librerias de desarrollo y con soporte para casi todos los codecs. */
typedef struct VideoPlayer VideoPlayer;

VideoPlayer *video_open(const char *path);
void         video_close(VideoPlayer *v);
void         video_play(VideoPlayer *v);
void         video_pause(VideoPlayer *v, bool pause);
bool         video_is_paused(VideoPlayer *v);
void         video_update(VideoPlayer *v);   /* una vez por frame */
bool         video_finished(VideoPlayer *v);
C2D_Image    video_image(VideoPlayer *v);    /* textura con el cuadro actual (w/h = tamano real, para mantener la proporcion) */
u64          video_position_ms(VideoPlayer *v);
u64          video_duration_ms(VideoPlayer *v);
u64          video_frames_shown(VideoPlayer *v);   /* diagnostico: cuadros realmente mostrados */
bool         video_seek(VideoPlayer *v, u64 ms);

#endif
