/* script.c - minijuegos en Lua. Los scripts corren en un entorno aislado (sin io/os/load) y con limite de instrucciones. */
#include "script.h"
#include "gfx_ui.h"
#include "stb_image.h"
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX_SCRIPTS   64
#define MAX_IMAGES    128
#define INSTR_LIMIT   20000000
#define MAX_FACES     6000
#define MAX_MAP       64

typedef struct { char dir[MAX_PATH]; char title[MAX_NAME]; char desc[MAX_NAME]; } ScriptInfo;
static ScriptInfo infos[MAX_SCRIPTS];
static int ninfo;

static lua_State *L;
static bool active, paused, errored, quitReq, started;
static char errmsg[320];
static int  cur = -1;
static GameInput gin;
static float elapsed;
static C2D_Image imgs[MAX_IMAGES + 1];
static int nimgs;
static int bestScore;

/* ------------------------------------------------------------------ utilidades */
static void hook_limit(lua_State *S, lua_Debug *ar) {
    (void)ar;
    luaL_error(S, "el script tardo demasiado en un frame (bucle infinito?)");
}

static const char *PRELUDE =
"function clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end\n"
"function lerp(a, b, t) return a + (b - a) * t end\n"
"function sign(v) if v > 0 then return 1 elseif v < 0 then return -1 end return 0 end\n"
"function dist(x1, y1, x2, y2) local dx, dy = x2 - x1, y2 - y1 return math.sqrt(dx * dx + dy * dy) end\n"
"function collide_rect(ax, ay, aw, ah, bx, by, bw, bh) return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah end\n"
"function collide_circle(ax, ay, ar, bx, by, br) local dx, dy = bx - ax, by - ay local r = ar + br return dx * dx + dy * dy <= r * r end\n"
"function rnd(a, b) if b then return math.random(a, b) elseif a then return math.random(a) end return math.random() end\n"
"function ease_out(t) t = clamp(t, 0, 1) return 1 - (1 - t) ^ 3 end\n"
"function ease_in_out(t) t = clamp(t, 0, 1) return t * t * (3 - 2 * t) end\n"
"TOP_W, TOP_H, BOT_W, BOT_H = 400, 240, 320, 240\n"
"color = {\n"
"  black = rgb(0, 0, 0), white = rgb(255, 255, 255), gray = rgb(128, 128, 128), dark = rgb(18, 18, 18),\n"
"  green = rgb(29, 185, 84), blue = rgb(46, 155, 240), pink = rgb(240, 90, 160), orange = rgb(242, 140, 40),\n"
"  red = rgb(230, 70, 70), yellow = rgb(245, 200, 60), purple = rgb(170, 100, 230), cyan = rgb(60, 210, 220),\n"
"  transparent = rgb(0, 0, 0, 0)\n"
"}\n";

static lua_State *new_state(void) {
    lua_State *S = luaL_newstate();
    if (!S) return NULL;
    luaL_requiref(S, "_G", luaopen_base, 1);      lua_pop(S, 1);
    luaL_requiref(S, "table", luaopen_table, 1);  lua_pop(S, 1);
    luaL_requiref(S, "string", luaopen_string, 1); lua_pop(S, 1);
    luaL_requiref(S, "math", luaopen_math, 1);    lua_pop(S, 1);
    luaL_requiref(S, "utf8", luaopen_utf8, 1);    lua_pop(S, 1);
    luaL_requiref(S, "coroutine", luaopen_coroutine, 1); lua_pop(S, 1);
    static const char *bad[] = { "dofile", "loadfile", "load", "collectgarbage", NULL };
    for (int i = 0; bad[i]; i++) { lua_pushnil(S); lua_setglobal(S, bad[i]); }
    return S;
}

static u32 col(lua_State *S, int i) { return (u32)luaL_checkinteger(S, i); }
static float num(lua_State *S, int i) { return (float)luaL_checknumber(S, i); }
static float onum(lua_State *S, int i, float d) { return (float)luaL_optnumber(S, i, d); }

static bool safe_name(const char *n) {
    if (!n || !n[0] || n[0] == '/' || n[0] == '\\') return false;
    return strstr(n, "..") == NULL;
}

/* ------------------------------------------------------------------ API de dibujo 2D */
static int c255(lua_State *S, int i, int d) {
    double v = lua_isnoneornil(S, i) ? (double)d : (double)luaL_checknumber(S, i);
    return v < 0 ? 0 : (v > 255 ? 255 : (int)v);
}
static int l_rgb(lua_State *S) {
    lua_pushinteger(S, (lua_Integer)C2D_Color32(c255(S, 1, 0), c255(S, 2, 0), c255(S, 3, 0), c255(S, 4, 255)));
    return 1;
}
static int l_hex(lua_State *S) {
    u32 h = (u32)luaL_checkinteger(S, 1);
    int a = c255(S, 2, 255);
    lua_pushinteger(S, (lua_Integer)C2D_Color32((h >> 16) & 255, (h >> 8) & 255, h & 255, a));
    return 1;
}
static int l_mix(lua_State *S) { lua_pushinteger(S, (lua_Integer)ui_color_mix(col(S, 1), col(S, 2), num(S, 3))); return 1; }
static int l_alpha(lua_State *S) { lua_pushinteger(S, (lua_Integer)ui_color_alpha(col(S, 1), num(S, 2))); return 1; }
static int l_rect(lua_State *S) { ui_rect(num(S, 1), num(S, 2), num(S, 3), num(S, 4), col(S, 5)); return 0; }
static int l_rrect(lua_State *S) { ui_rounded(num(S, 1), num(S, 2), num(S, 3), num(S, 4), num(S, 5), col(S, 6)); return 0; }
static int l_circle(lua_State *S) { ui_circle(num(S, 1), num(S, 2), num(S, 3), col(S, 4)); return 0; }
static int l_ring(lua_State *S) { ui_ring(num(S, 1), num(S, 2), num(S, 3), num(S, 4), col(S, 5)); return 0; }
static int l_line(lua_State *S) { ui_line(num(S, 1), num(S, 2), num(S, 3), num(S, 4), onum(S, 5, 1), col(S, 6)); return 0; }
static int l_tri(lua_State *S) { ui_triangle(num(S, 1), num(S, 2), num(S, 3), num(S, 4), num(S, 5), num(S, 6), col(S, 7)); return 0; }
static int l_gradient(lua_State *S) {
    if (lua_toboolean(S, 7)) ui_gradient_h(num(S, 1), num(S, 2), num(S, 3), num(S, 4), col(S, 5), col(S, 6));
    else ui_gradient(num(S, 1), num(S, 2), num(S, 3), num(S, 4), col(S, 5), col(S, 6));
    return 0;
}
static int l_shadow(lua_State *S) { ui_shadow(num(S, 1), num(S, 2), num(S, 3), num(S, 4), num(S, 5), onum(S, 6, 6), (int)luaL_optinteger(S, 7, 90)); return 0; }
static int l_text(lua_State *S) { ui_text(num(S, 1), num(S, 2), onum(S, 3, 0.45f), col(S, 4), "%s", luaL_checkstring(S, 5)); return 0; }
static int l_text_center(lua_State *S) { ui_text_center_raw(num(S, 1), num(S, 2), onum(S, 3, 0.45f), col(S, 4), luaL_checkstring(S, 5)); return 0; }
static int l_text_right(lua_State *S) { ui_text_right_raw(num(S, 1), num(S, 2), onum(S, 3, 0.45f), col(S, 4), luaL_checkstring(S, 5)); return 0; }
static int l_text_width(lua_State *S) { lua_pushnumber(S, ui_text_width(luaL_checkstring(S, 1), onum(S, 2, 0.45f))); return 1; }
static int l_clip(lua_State *S) { ui_clip(num(S, 1), num(S, 2), num(S, 3), num(S, 4)); return 0; }
static int l_clip_reset(lua_State *S) { (void)S; ui_clip_reset(); return 0; }
static int l_additive(lua_State *S) { ui_blend_add(lua_toboolean(S, 1)); return 0; }

static int l_load_image(lua_State *S) {
    const char *name = luaL_checkstring(S, 1);
    bool pixel = lua_toboolean(S, 2);
    if (!safe_name(name) || cur < 0) { lua_pushinteger(S, 0); return 1; }
    if (nimgs >= MAX_IMAGES) return luaL_error(S, "demasiadas imagenes (max %d)", MAX_IMAGES);
    char path[MAX_PATH * 2];
    snprintf(path, sizeof(path), "%s/%s", infos[cur].dir, name);
    int w, h, comp;
    unsigned char *px = stbi_load(path, &w, &h, &comp, 4);
    if (!px) { lua_pushinteger(S, 0); return 1; }
    C2D_Image img = ui_texture_from_rgba(px, w, h, !pixel);
    stbi_image_free(px);
    if (!img.tex) { lua_pushinteger(S, 0); return 1; }
    imgs[++nimgs] = img;
    lua_pushinteger(S, nimgs);
    return 1;
}
static C2D_Image get_img(lua_State *S, int i) {
    lua_Integer id = luaL_checkinteger(S, i);
    C2D_Image none = { NULL, 0, 0 };
    return (id >= 1 && id <= nimgs) ? imgs[id] : none;
}
static int l_sprite(lua_State *S) {
    C2D_Image im = get_img(S, 1);
    if (!im.tex) return 0;
    u32 tint = lua_isnoneornil(S, 9) ? C2D_Color32(255, 255, 255, 255) : col(S, 9);
    ui_image_ex(im, 0, 0, (float)im.w, (float)im.h, num(S, 2), num(S, 3), num(S, 4), num(S, 5),
                onum(S, 6, 0), lua_toboolean(S, 7), lua_toboolean(S, 8), tint);
    return 0;
}
static int l_sprite_src(lua_State *S) {
    C2D_Image im = get_img(S, 1);
    if (!im.tex) return 0;
    u32 tint = lua_isnoneornil(S, 13) ? C2D_Color32(255, 255, 255, 255) : col(S, 13);
    ui_image_ex(im, num(S, 2), num(S, 3), num(S, 4), num(S, 5), num(S, 6), num(S, 7), num(S, 8), num(S, 9),
                onum(S, 10, 0), lua_toboolean(S, 11), lua_toboolean(S, 12), tint);
    return 0;
}
static int l_image_size(lua_State *S) {
    C2D_Image im = get_img(S, 1);
    lua_pushinteger(S, im.w); lua_pushinteger(S, im.h);
    return 2;
}

/* ------------------------------------------------------------------ entrada / estado */
static u32 key_of(lua_State *S, const char *n) {
    static const struct { const char *name; u32 key; } t[] = {
        { "a", KEY_A }, { "b", KEY_B }, { "x", KEY_X }, { "y", KEY_Y }, { "l", KEY_L }, { "r", KEY_R },
        { "start", KEY_START }, { "select", KEY_SELECT }, { "up", KEY_UP }, { "down", KEY_DOWN },
        { "left", KEY_LEFT }, { "right", KEY_RIGHT }, { "touch", KEY_TOUCH }, { NULL, 0 } };
    for (int i = 0; t[i].name; i++) if (!strcmp(n, t[i].name)) return t[i].key;
    luaL_error(S, "boton desconocido '%s' (a b x y l r start select up down left right)", n);
    return 0;
}
static int l_btn(lua_State *S) { lua_pushboolean(S, (gin.held & key_of(S, luaL_checkstring(S, 1))) != 0); return 1; }
static int l_pressed(lua_State *S) { lua_pushboolean(S, (gin.down & key_of(S, luaL_checkstring(S, 1))) != 0); return 1; }
static int l_stick(lua_State *S) {
    float x = (float)gin.circleX / 156.0f, y = -(float)gin.circleY / 156.0f;     /* arriba = -1 (coordenadas de pantalla) */
    if (gin.held & KEY_DLEFT) x = -1;
    if (gin.held & KEY_DRIGHT) x = 1;
    if (gin.held & KEY_DUP) y = -1;
    if (gin.held & KEY_DDOWN) y = 1;
    lua_pushnumber(S, x); lua_pushnumber(S, y);
    return 2;
}
static int l_touch(lua_State *S) {
    if (!(gin.held & KEY_TOUCH)) { lua_pushnil(S); return 1; }
    lua_pushinteger(S, gin.touchX); lua_pushinteger(S, gin.touchY);
    return 2;
}
static int l_time(lua_State *S) { lua_pushnumber(S, elapsed); return 1; }
static int l_quit(lua_State *S) { (void)S; quitReq = true; return 0; }

static void best_path(char *out, size_t n) { snprintf(out, n, "%s/.best", cur >= 0 ? infos[cur].dir : "."); }
static void load_best(void) {
    bestScore = 0;
    char p[MAX_PATH * 2];
    best_path(p, sizeof(p));
    FILE *f = fopen(p, "rb");
    if (f) { if (fscanf(f, "%d", &bestScore) != 1) bestScore = 0; fclose(f); }
}
static int l_best(lua_State *S) { lua_pushinteger(S, bestScore); return 1; }
static int l_submit(lua_State *S) {
    int s = (int)luaL_checkinteger(S, 1);
    if (s > bestScore) {
        bestScore = s;
        char p[MAX_PATH * 2];
        best_path(p, sizeof(p));
        FILE *f = fopen(p, "wb");
        if (f) { fprintf(f, "%d\n", s); fclose(f); }
    }
    lua_pushinteger(S, bestScore);
    return 1;
}

/* ------------------------------------------------------------------ 2.5D: raycaster */
typedef struct { char c[MAX_MAP][MAX_MAP]; int w, h; } Grid;
static Grid grid;
static float zbuf[640];
static int   zcols;
static float rcX, rcY, rcW, rcH, rcFov = 1.15f;

static bool read_map(lua_State *S, int idx, Grid *g) {
    luaL_checktype(S, idx, LUA_TTABLE);
    int rows = (int)lua_rawlen(S, idx);
    if (rows < 1) return false;
    if (rows > MAX_MAP) rows = MAX_MAP;
    g->h = rows; g->w = 0;
    for (int y = 0; y < rows; y++) {
        lua_geti(S, idx, y + 1);
        size_t len = 0;
        const char *s = lua_isstring(S, -1) ? lua_tolstring(S, -1, &len) : "";
        if ((int)len > MAX_MAP) len = MAX_MAP;
        if ((int)len > g->w) g->w = (int)len;
        for (int x = 0; x < MAX_MAP; x++) g->c[y][x] = x < (int)len ? s[x] : '#';
        lua_pop(S, 1);
    }
    return g->w > 0;
}

static u32 wall_color(char c) {
    switch (c) {
        case '1': return C2D_Color32(225, 80, 80, 255);
        case '2': return C2D_Color32(70, 200, 110, 255);
        case '3': return C2D_Color32(80, 140, 235, 255);
        case '4': return C2D_Color32(240, 200, 70, 255);
        case '5': return C2D_Color32(220, 100, 200, 255);
        case '6': return C2D_Color32(70, 210, 220, 255);
        case '7': return C2D_Color32(240, 150, 60, 255);
        case '8': return C2D_Color32(235, 235, 235, 255);
        case '9': return C2D_Color32(160, 110, 230, 255);
        default:  return C2D_Color32(150, 155, 170, 255);
    }
}
static bool is_empty(char c) { return c == ' ' || c == '.'; }
static u32 shade(u32 c, float k) {
    if (k < 0) k = 0;
    if (k > 1) k = 1;
    return C2D_Color32((int)((float)COLOR_R(c) * k), (int)((float)COLOR_G(c) * k), (int)((float)COLOR_B(c) * k), COLOR_A(c));
}

/* lanza un rayo; devuelve distancia perpendicular y la celda; side=1 si golpeo cara horizontal */
static float cast_ray(const Grid *g, float px, float py, float dx, float dy, char *cell, int *side) {
    int mx = (int)floorf(px), my = (int)floorf(py);
    float ddx = dx == 0 ? 1e30f : fabsf(1.0f / dx), ddy = dy == 0 ? 1e30f : fabsf(1.0f / dy);
    int sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1;
    float sdx = dx < 0 ? (px - (float)mx) * ddx : ((float)mx + 1.0f - px) * ddx;
    float sdy = dy < 0 ? (py - (float)my) * ddy : ((float)my + 1.0f - py) * ddy;
    int s = 0;
    for (int i = 0; i < 128; i++) {
        if (sdx < sdy) { sdx += ddx; mx += sx; s = 0; } else { sdy += ddy; my += sy; s = 1; }
        if (mx < 0 || my < 0 || mx >= g->w || my >= g->h) { *cell = '#'; *side = s; return (s == 0 ? sdx - ddx : sdy - ddy); }
        char c = g->c[my][mx];
        if (!is_empty(c)) { *cell = c; *side = s; return (s == 0 ? sdx - ddx : sdy - ddy); }
    }
    *cell = '#'; *side = 0;
    return 64.0f;
}

static int l_raycast(lua_State *S) {
    if (!read_map(S, 1, &grid)) return luaL_error(S, "raycast: el mapa esta vacio");
    float px = num(S, 2), py = num(S, 3), ang = num(S, 4);
    float x = num(S, 5), y = num(S, 6), w = num(S, 7), h = num(S, 8);
    float fov = onum(S, 9, 66.0f) * (float)M_PI / 180.0f;
    u32 sky = lua_isnoneornil(S, 10) ? C2D_Color32(40, 70, 130, 255) : col(S, 10);
    u32 flr = lua_isnoneornil(S, 11) ? C2D_Color32(48, 44, 52, 255) : col(S, 11);
    rcX = x; rcY = y; rcW = w; rcH = h; rcFov = fov;
    ui_clip(x, y, w, h);
    ui_gradient(x, y, w, h / 2, shade(sky, 0.55f), sky);
    ui_gradient(x, y + h / 2, w, h / 2, shade(flr, 0.45f), flr);
    int cols = (int)(w / 2.0f);
    if (cols > 640) cols = 640;
    if (cols < 8) cols = 8;
    zcols = cols;
    float dirx = cosf(ang), diry = sinf(ang);
    float planeLen = tanf(fov / 2);
    float plx = -diry * planeLen, ply = dirx * planeLen;
    float cw = w / (float)cols;
    for (int c = 0; c < cols; c++) {
        float cx = 2.0f * ((float)c + 0.5f) / (float)cols - 1.0f;
        char cell; int side;
        float d = cast_ray(&grid, px, py, dirx + plx * cx, diry + ply * cx, &cell, &side);
        if (d < 0.05f) d = 0.05f;
        zbuf[c] = d;
        float lh = h / d;
        float top = y + h / 2 - lh / 2;
        float k = (side ? 0.68f : 1.0f) / (1.0f + d * 0.16f);
        ui_rect(x + (float)c * cw, top, cw + 0.6f, lh, shade(wall_color(cell), k));
    }
    ui_clip_reset();
    return 0;
}

static int l_ray_dist(lua_State *S) {
    Grid g;
    if (!read_map(S, 1, &g)) return luaL_error(S, "ray_dist: el mapa esta vacio");
    float px = num(S, 2), py = num(S, 3), a = num(S, 4);
    char cell; int side;
    float d = cast_ray(&g, px, py, cosf(a), sinf(a), &cell, &side);
    lua_pushnumber(S, d);
    char buf[2] = { cell, 0 };
    lua_pushstring(S, buf);
    return 2;
}

/* dibuja un objeto (circulo o sprite) en el mundo del raycaster, ocultado por las paredes */
static int l_ray_billboard(lua_State *S) {
    float px = num(S, 1), py = num(S, 2), ang = num(S, 3), tx = num(S, 4), ty = num(S, 5), size = num(S, 6);
    float dx = tx - px, dy = ty - py;
    float dirx = cosf(ang), diry = sinf(ang);
    float depth = dx * dirx + dy * diry;
    float lat = dx * (-diry) + dy * dirx;
    if (depth < 0.15f || zcols == 0) { lua_pushboolean(S, 0); return 1; }
    float t = tanf(rcFov / 2);
    float sx = rcX + rcW / 2 + (lat / depth) / t * (rcW / 2);
    int c = (int)((sx - rcX) / rcW * (float)zcols);
    if (c < 0 || c >= zcols || depth > zbuf[c]) { lua_pushboolean(S, 0); return 1; }
    float r = size / depth * rcH * 0.5f;
    float sy = rcY + rcH / 2 + r * 0.35f;
    float k = 1.0f / (1.0f + depth * 0.12f);
    ui_clip(rcX, rcY, rcW, rcH);
    u32 colr = lua_isnoneornil(S, 7) ? C2D_Color32(240, 90, 90, 255) : col(S, 7);
    ui_circle(sx, sy, r, shade(colr, k));
    ui_circle(sx - r * 0.25f, sy - r * 0.25f, r * 0.45f, shade(ui_color_mix(colr, C2D_Color32(255, 255, 255, 255), 0.45f), k));
    ui_clip_reset();
    lua_pushboolean(S, 1);
    lua_pushnumber(S, sx); lua_pushnumber(S, sy); lua_pushnumber(S, r);
    return 4;
}
static int l_ray_sprite(lua_State *S) {
    float px = num(S, 1), py = num(S, 2), ang = num(S, 3), tx = num(S, 4), ty = num(S, 5), size = num(S, 6);
    C2D_Image im = get_img(S, 7);
    float dx = tx - px, dy = ty - py;
    float dirx = cosf(ang), diry = sinf(ang);
    float depth = dx * dirx + dy * diry;
    float lat = dx * (-diry) + dy * dirx;
    if (!im.tex || depth < 0.15f || zcols == 0) { lua_pushboolean(S, 0); return 1; }
    float t = tanf(rcFov / 2);
    float sx = rcX + rcW / 2 + (lat / depth) / t * (rcW / 2);
    int c = (int)((sx - rcX) / rcW * (float)zcols);
    if (c < 0 || c >= zcols || depth > zbuf[c]) { lua_pushboolean(S, 0); return 1; }
    float hh = size / depth * rcH;
    float ww = hh * (float)im.w / (float)im.h;
    float k = 1.0f / (1.0f + depth * 0.12f);
    ui_clip(rcX, rcY, rcW, rcH);
    ui_image_ex(im, 0, 0, (float)im.w, (float)im.h, sx - ww / 2, rcY + rcH / 2 - hh / 2 + hh * 0.2f, ww, hh, 0, false, false, shade(C2D_Color32(255, 255, 255, 255), k));
    ui_clip_reset();
    lua_pushboolean(S, 1);
    return 1;
}

/* ------------------------------------------------------------------ 3D: camara, cubos, esfinges... */
typedef struct { float depth; int kind, n; float p[6][2]; float r; u32 col; } Item;
static Item items[MAX_FACES];
static int nitems;
static struct { float x, y, z, yaw, pitch, fov, vx, vy, vw, vh, cy, sy, cp, sp, f; u32 fog; float fogFar; bool on; } cam;
static const float LIGHT[3] = { 0.40f, 0.82f, 0.41f };

static void tf(float x, float y, float z, float *ox, float *oy, float *oz) {
    float dx = x - cam.x, dy = y - cam.y, dz = z - cam.z;
    float x1 = dx * cam.cy - dz * cam.sy;
    float z1 = dx * cam.sy + dz * cam.cy;
    *ox = x1;
    *oy = dy * cam.cp - z1 * cam.sp;
    *oz = dy * cam.sp + z1 * cam.cp;
}
static void proj(float x, float y, float z, float *sx, float *sy) {
    *sx = cam.vx + cam.vw / 2 + x / z * cam.f;
    *sy = cam.vy + cam.vh / 2 - y / z * cam.f;
}
static u32 lit(u32 c, float nx, float ny, float nz, float depth) {
    float d = nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2];
    if (d < 0) d = -d * 0.35f;
    float k = 0.42f + 0.58f * d;
    u32 s = shade(c, k > 1 ? 1 : k);
    float f = depth / cam.fogFar;
    if (f > 0) s = ui_color_mix(s, cam.fog, f > 1 ? 1 : f);
    return C2D_Color32(COLOR_R(s), COLOR_G(s), COLOR_B(s), COLOR_A(c));
}

/* agrega un poligono (4 vertices en mundo); cull = descartar caras de espaldas */
static void add_poly(const float v[4][3], u32 c, bool cull) {
    if (nitems >= MAX_FACES) return;
    float ax = v[1][0] - v[0][0], ay = v[1][1] - v[0][1], az = v[1][2] - v[0][2];
    float bx = v[3][0] - v[0][0], by = v[3][1] - v[0][1], bz = v[3][2] - v[0][2];
    float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
    float nl = sqrtf(nx * nx + ny * ny + nz * nz);
    if (nl < 1e-8f) return;
    nx /= nl; ny /= nl; nz /= nl;
    if (cull) {
        float cx = (v[0][0] + v[2][0]) / 2 - cam.x, cy2 = (v[0][1] + v[2][1]) / 2 - cam.y, cz = (v[0][2] + v[2][2]) / 2 - cam.z;
        if (nx * cx + ny * cy2 + nz * cz >= 0) return;
    }
    float tv[4][3];
    for (int i = 0; i < 4; i++) tf(v[i][0], v[i][1], v[i][2], &tv[i][0], &tv[i][1], &tv[i][2]);
    /* recorte contra el plano cercano z >= 0.1 */
    float out[6][3];
    int n = 0;
    const float NEAR = 0.1f;
    for (int i = 0; i < 4; i++) {
        const float *a = tv[i], *b = tv[(i + 1) % 4];
        bool ina = a[2] >= NEAR, inb = b[2] >= NEAR;
        if (ina && n < 6) { out[n][0] = a[0]; out[n][1] = a[1]; out[n][2] = a[2]; n++; }
        if (ina != inb && n < 6) {
            float t = (NEAR - a[2]) / (b[2] - a[2]);
            out[n][0] = a[0] + (b[0] - a[0]) * t; out[n][1] = a[1] + (b[1] - a[1]) * t; out[n][2] = NEAR; n++;
        }
    }
    if (n < 3) return;
    Item *it = &items[nitems++];
    it->kind = 0; it->n = n;
    float dsum = 0;
    for (int i = 0; i < n; i++) { proj(out[i][0], out[i][1], out[i][2], &it->p[i][0], &it->p[i][1]); dsum += out[i][2]; }
    it->depth = dsum / (float)n;
    it->col = lit(c, nx, ny, nz, it->depth);
}

static int l_scene3d(lua_State *S) {
    cam.x = num(S, 1); cam.y = num(S, 2); cam.z = num(S, 3);
    cam.yaw = num(S, 4); cam.pitch = num(S, 5);
    cam.fov = onum(S, 6, 70) * (float)M_PI / 180.0f;
    cam.vx = num(S, 7); cam.vy = num(S, 8); cam.vw = num(S, 9); cam.vh = num(S, 10);
    cam.cy = cosf(cam.yaw); cam.sy = sinf(cam.yaw); cam.cp = cosf(cam.pitch); cam.sp = sinf(cam.pitch);
    cam.f = (cam.vh / 2) / tanf(cam.fov / 2);
    u32 skyTop = lua_isnoneornil(S, 11) ? C2D_Color32(30, 60, 120, 255) : col(S, 11);
    u32 skyBot = lua_isnoneornil(S, 12) ? C2D_Color32(150, 190, 235, 255) : col(S, 12);
    cam.fog = skyBot; cam.fogFar = 60.0f; cam.on = true;
    nitems = 0;
    ui_clip(cam.vx, cam.vy, cam.vw, cam.vh);
    ui_gradient(cam.vx, cam.vy, cam.vw, cam.vh, skyTop, skyBot);
    ui_clip_reset();
    return 0;
}
static int l_fog3(lua_State *S) { cam.fog = col(S, 1); cam.fogFar = onum(S, 2, 60); return 0; }

static int l_cube(lua_State *S) {
    if (!cam.on) return luaL_error(S, "cube: llama primero a scene3d(...)");
    float x = num(S, 1), y = num(S, 2), z = num(S, 3), sx = num(S, 4) / 2, sy = num(S, 5) / 2, sz = num(S, 6) / 2;
    u32 c = col(S, 7);
    float x0 = x - sx, x1 = x + sx, y0 = y - sy, y1 = y + sy, z0 = z - sz, z1 = z + sz;
    float f[6][4][3] = {
        { {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1} },   /* +z */
        { {x1, y0, z0}, {x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0} },   /* -z */
        { {x1, y0, z1}, {x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1} },   /* +x */
        { {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {x0, y1, z0} },   /* -x */
        { {x0, y1, z1}, {x1, y1, z1}, {x1, y1, z0}, {x0, y1, z0} },   /* +y */
        { {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1} }    /* -y */
    };
    for (int i = 0; i < 6; i++) add_poly(f[i], c, true);
    return 0;
}
static int l_quad3(lua_State *S) {
    if (!cam.on) return luaL_error(S, "quad3: llama primero a scene3d(...)");
    float v[4][3];
    for (int i = 0; i < 4; i++) for (int j = 0; j < 3; j++) v[i][j] = num(S, 1 + i * 3 + j);
    add_poly(v, col(S, 13), false);
    return 0;
}
static int l_floor3(lua_State *S) {
    if (!cam.on) return luaL_error(S, "floor3: llama primero a scene3d(...)");
    float cx = num(S, 1), cz = num(S, 2), size = num(S, 3), y = num(S, 5);
    int tiles = (int)luaL_checkinteger(S, 4);
    if (tiles < 1) tiles = 1;
    if (tiles > 24) tiles = 24;
    u32 c1 = col(S, 6), c2 = col(S, 7);
    float ts = size / (float)tiles, x0 = cx - size / 2, z0 = cz - size / 2;
    for (int i = 0; i < tiles; i++)
        for (int j = 0; j < tiles; j++) {
            float a = x0 + (float)i * ts, b = z0 + (float)j * ts;
            float v[4][3] = { {a, y, b}, {a, y, b + ts}, {a + ts, y, b + ts}, {a + ts, y, b} };
            add_poly(v, ((i + j) & 1) ? c1 : c2, false);
        }
    return 0;
}
static int l_sphere3(lua_State *S) {
    if (!cam.on) return luaL_error(S, "sphere3: llama primero a scene3d(...)");
    float ox, oy, oz;
    tf(num(S, 1), num(S, 2), num(S, 3), &ox, &oy, &oz);
    if (oz < 0.1f || nitems >= MAX_FACES) return 0;
    Item *it = &items[nitems++];
    it->kind = 1; it->depth = oz;
    proj(ox, oy, oz, &it->p[0][0], &it->p[0][1]);
    it->r = num(S, 4) / oz * cam.f;
    it->col = lit(col(S, 5), 0.3f, 0.9f, 0.3f, oz);
    return 0;
}
static int l_line3(lua_State *S) {
    if (!cam.on) return luaL_error(S, "line3: llama primero a scene3d(...)");
    float a[3], b[3];
    tf(num(S, 1), num(S, 2), num(S, 3), &a[0], &a[1], &a[2]);
    tf(num(S, 4), num(S, 5), num(S, 6), &b[0], &b[1], &b[2]);
    if (a[2] < 0.1f || b[2] < 0.1f || nitems >= MAX_FACES) return 0;
    Item *it = &items[nitems++];
    it->kind = 2; it->depth = (a[2] + b[2]) / 2;
    proj(a[0], a[1], a[2], &it->p[0][0], &it->p[0][1]);
    proj(b[0], b[1], b[2], &it->p[1][0], &it->p[1][1]);
    it->col = col(S, 7);
    it->r = onum(S, 8, 1.5f);
    return 0;
}
static int l_project3(lua_State *S) {
    float ox, oy, oz, sx, sy;
    tf(num(S, 1), num(S, 2), num(S, 3), &ox, &oy, &oz);
    if (oz < 0.1f) { lua_pushnil(S); return 1; }
    proj(ox, oy, oz, &sx, &sy);
    lua_pushnumber(S, sx); lua_pushnumber(S, sy); lua_pushnumber(S, oz);
    return 3;
}
static int item_cmp(const void *a, const void *b) {
    float da = ((const Item *)a)->depth, db = ((const Item *)b)->depth;
    return da < db ? 1 : (da > db ? -1 : 0);
}
static int l_scene3d_end(lua_State *S) {
    (void)S;
    if (!cam.on) return 0;
    qsort(items, (size_t)nitems, sizeof(Item), item_cmp);
    ui_clip(cam.vx, cam.vy, cam.vw, cam.vh);
    for (int i = 0; i < nitems; i++) {
        Item *it = &items[i];
        if (it->kind == 0) {
            for (int k = 1; k + 1 < it->n; k++)
                ui_triangle(it->p[0][0], it->p[0][1], it->p[k][0], it->p[k][1], it->p[k + 1][0], it->p[k + 1][1], it->col);
            /* leve borde para que las aristas se lean aun con colores parecidos */
            for (int k = 0; k < it->n; k++) {
                int j = (k + 1) % it->n;
                ui_line(it->p[k][0], it->p[k][1], it->p[j][0], it->p[j][1], 0.6f, C2D_Color32(0, 0, 0, 50));
            }
        } else if (it->kind == 1) {
            ui_circle(it->p[0][0], it->p[0][1], it->r, shade(it->col, 0.75f));
            ui_circle(it->p[0][0] - it->r * 0.18f, it->p[0][1] - it->r * 0.2f, it->r * 0.72f, it->col);
            ui_circle(it->p[0][0] - it->r * 0.3f, it->p[0][1] - it->r * 0.35f, it->r * 0.25f, ui_color_mix(it->col, C2D_Color32(255, 255, 255, 255), 0.6f));
        } else {
            ui_line(it->p[0][0], it->p[0][1], it->p[1][0], it->p[1][1], it->r, it->col);
        }
    }
    ui_clip_reset();
    nitems = 0;
    cam.on = false;
    return 0;
}

/* ------------------------------------------------------------------ registro */
static void register_api(lua_State *S) {
    static const struct { const char *name; lua_CFunction fn; } api[] = {
        { "rgb", l_rgb }, { "hex", l_hex }, { "mix", l_mix }, { "alpha", l_alpha },
        { "rect", l_rect }, { "rrect", l_rrect }, { "circle", l_circle }, { "ring", l_ring }, { "line", l_line },
        { "tri", l_tri }, { "gradient", l_gradient }, { "shadow", l_shadow },
        { "text", l_text }, { "text_center", l_text_center }, { "text_right", l_text_right }, { "text_width", l_text_width },
        { "clip", l_clip }, { "clip_reset", l_clip_reset }, { "additive", l_additive },
        { "load_image", l_load_image }, { "sprite", l_sprite }, { "sprite_src", l_sprite_src }, { "image_size", l_image_size },
        { "btn", l_btn }, { "pressed", l_pressed }, { "stick", l_stick }, { "touch", l_touch },
        { "time", l_time }, { "quit", l_quit }, { "best", l_best }, { "submit_score", l_submit },
        { "raycast", l_raycast }, { "ray_dist", l_ray_dist }, { "ray_billboard", l_ray_billboard }, { "ray_sprite", l_ray_sprite },
        { "scene3d", l_scene3d }, { "scene3d_end", l_scene3d_end }, { "fog3", l_fog3 }, { "cube", l_cube }, { "quad3", l_quad3 },
        { "floor3", l_floor3 }, { "sphere3", l_sphere3 }, { "line3", l_line3 }, { "project3", l_project3 },
        { NULL, NULL } };
    for (int i = 0; api[i].name; i++) { lua_pushcfunction(S, api[i].fn); lua_setglobal(S, api[i].name); }
    if (luaL_loadbuffer(S, PRELUDE, strlen(PRELUDE), "prelude") == LUA_OK) lua_pcall(S, 0, 0, 0);
    else lua_pop(S, 1);
}

static bool run_protected(lua_State *S, int nargs) {
    lua_sethook(S, hook_limit, LUA_MASKCOUNT, INSTR_LIMIT);
    int rc = lua_pcall(S, nargs, 0, 0);
    lua_sethook(S, NULL, 0, 0);
    if (rc != LUA_OK) {
        const char *m = lua_tostring(S, -1);
        snprintf(errmsg, sizeof(errmsg), "%s", m ? m : "error desconocido");
        lua_pop(S, 1);
        return false;
    }
    return true;
}

static bool call_global(const char *name, int nargs, float a, float b) {
    if (!L || errored) return true;
    lua_getglobal(L, name);
    if (!lua_isfunction(L, -1)) { lua_pop(L, 1); return true; }
    if (nargs >= 1) lua_pushnumber(L, a);
    if (nargs >= 2) lua_pushnumber(L, b);
    if (!run_protected(L, nargs)) { errored = true; return false; }
    return true;
}

/* ------------------------------------------------------------------ escaneo */
static void read_meta(ScriptInfo *si, const char *folderName) {
    snprintf(si->title, MAX_NAME, "%s", folderName);
    si->desc[0] = '\0';
    lua_State *S = new_state();
    if (!S) return;
    register_api(S);
    char path[MAX_PATH * 2];
    snprintf(path, sizeof(path), "%s/main.lua", si->dir);
    if (luaL_loadfile(S, path) == LUA_OK && run_protected(S, 0)) {
        lua_getglobal(S, "GAME");
        if (lua_istable(S, -1)) {
            lua_getfield(S, -1, "title");
            if (lua_isstring(S, -1)) snprintf(si->title, MAX_NAME, "%s", lua_tostring(S, -1));
            lua_pop(S, 1);
            lua_getfield(S, -1, "description");
            if (lua_isstring(S, -1)) snprintf(si->desc, MAX_NAME, "%s", lua_tostring(S, -1));
            lua_pop(S, 1);
        }
        lua_pop(S, 1);
    } else {
        snprintf(si->desc, MAX_NAME, "(error: %.100s)", lua_isstring(S, -1) ? lua_tostring(S, -1) : errmsg);
    }
    lua_close(S);
}

static int info_cmp(const void *a, const void *b) {
    return strcasecmp(((const ScriptInfo *)a)->title, ((const ScriptInfo *)b)->title);
}

void script_rescan(void) {
    ninfo = 0;
    DIR *d = opendir(g_dir_games);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && ninfo < MAX_SCRIPTS) {
        if (e->d_name[0] == '.') continue;
        ScriptInfo *si = &infos[ninfo];
        snprintf(si->dir, sizeof(si->dir), "%s/%s", g_dir_games, e->d_name);
        char mp[MAX_PATH * 2];
        snprintf(mp, sizeof(mp), "%s/main.lua", si->dir);
        if (!file_exists(mp)) continue;
        read_meta(si, e->d_name);
        ninfo++;
    }
    closedir(d);
    if (ninfo > 1) qsort(infos, (size_t)ninfo, sizeof(ScriptInfo), info_cmp);
}

static bool dir_is_empty(const char *p) {
    DIR *d = opendir(p);
    if (!d) return true;
    struct dirent *e;
    bool empty = true;
    while ((e = readdir(d)) != NULL) if (e->d_name[0] != '.') { empty = false; break; }
    closedir(d);
    return empty;
}

static void install_examples(void) {
    char src[PATH_MAX_LEN + 32];
    static const char *cands[] = { "%s/../games", "%s/games", NULL };
    bool found = false;
    for (int i = 0; cands[i] && !found; i++) {
        snprintf(src, sizeof(src), cands[i], g_dir_assets);
        char probe[PATH_MAX_LEN + 64];
        snprintf(probe, sizeof(probe), "%s/", src);
        found = !dir_is_empty(src);
    }
    if (!found) { snprintf(src, sizeof(src), "/usr/share/3dspotilocal/games"); found = !dir_is_empty(src); }
    if (!found) return;
    pid_t pid = fork();
    if (pid == 0) {
        char from[PATH_MAX_LEN + 40];
        snprintf(from, sizeof(from), "%s/.", src);
        execlp("cp", "cp", "-r", from, g_dir_games, (char *)NULL);
        _exit(127);
    }
    if (pid > 0) waitpid(pid, NULL, 0);
}

void script_init(void) {
    if (!g_dir_games[0]) return;
    mkdir(g_dir_games, 0777);
    if (dir_is_empty(g_dir_games)) install_examples();   /* primera vez: copia los juegos de ejemplo */
    script_rescan();
}

void script_exit(void) { script_stop(); }
int script_count(void) { return ninfo; }
const char *script_title(int i) { return i >= 0 && i < ninfo ? infos[i].title : ""; }
const char *script_description(int i) { return i >= 0 && i < ninfo ? infos[i].desc : ""; }

/* ------------------------------------------------------------------ ejecucion */
void script_stop(void) {
    if (L) { lua_close(L); L = NULL; }
    for (int i = 1; i <= nimgs; i++) ui_texture_destroy(&imgs[i]);
    nimgs = 0;
    active = paused = errored = quitReq = started = false;
    cam.on = false;
    nitems = 0;
    zcols = 0;
    cur = -1;
}

bool script_start(int i) {
    script_stop();
    if (i < 0 || i >= ninfo) return false;
    cur = i;
    elapsed = 0;
    errmsg[0] = '\0';
    L = new_state();
    if (!L) { cur = -1; return false; }
    register_api(L);
    load_best();
    char path[MAX_PATH * 2];
    snprintf(path, sizeof(path), "%s/main.lua", infos[i].dir);
    active = true;
    if (luaL_loadfile(L, path) != LUA_OK) {
        const char *m = lua_tostring(L, -1);
        snprintf(errmsg, sizeof(errmsg), "%s", m ? m : "no se pudo leer main.lua");
        errored = true;
        return true;     /* se abre igual y muestra el error en pantalla */
    }
    if (!run_protected(L, 0)) { errored = true; return true; }
    call_global("init", 0, 0, 0);
    started = true;
    return true;
}

bool script_active(void) { return active; }
bool script_exit_requested(void) { return quitReq; }
bool script_errored(void) { return errored; }
const char *script_error(void) { return errmsg; }

void script_update(GameInput in) {
    if (!active) return;
    gin = in;
    if (in.down & KEY_START) paused = !paused;
    if (paused || errored) return;
    float dt = in.dt > 0.1f ? 0.1f : in.dt;
    elapsed += dt;
    call_global("update", 1, dt, 0);
}

void script_touch(int x, int y) {
    if (!active || paused || errored) return;
    call_global("touch", 2, (float)x, (float)y);
}

static void draw_error(float w, float h) {
    ui_rect(0, 0, w, h, C2D_Color32(40, 14, 16, 255));
    ui_text(12, 10, 0.5f, C2D_Color32(255, 110, 110, 255), "Error en el script");
    char line[64];
    size_t n = strlen(errmsg), s = 0;
    float y = 44;
    while (s < n && y < h - 20) {
        size_t len = n - s > 52 ? 52 : n - s;
        memcpy(line, errmsg + s, len);
        line[len] = '\0';
        ui_text(12, y, 0.34f, COL_TEXT, "%s", line);
        y += 15;
        s += len;
    }
    ui_text(12, h - 22, 0.36f, COL_SUBTEXT, "B: volver al menu");
}

static void draw_pause(float w, float h) {
    ui_rect(0, 0, w, h, C2D_Color32(0, 0, 0, 150));
    ui_text_center_raw(w / 2, h / 2 - 22, 0.8f, COL_TEXT, "PAUSA");
    ui_text_center_raw(w / 2, h / 2 + 18, 0.38f, COL_SUBTEXT, "START: seguir   B: salir");
}

void script_draw_top(void) {
    if (!active) return;
    if (errored) { draw_error(TOP_W, TOP_H); return; }
    if (!call_global("draw_top", 0, 0, 0)) { draw_error(TOP_W, TOP_H); return; }
    if (paused) draw_pause(TOP_W, TOP_H);
}

void script_draw_bottom(void) {
    if (!active) return;
    if (errored) { draw_error(BOT_W, BOT_H); return; }
    lua_getglobal(L, "draw_bottom");
    bool has = lua_isfunction(L, -1);
    lua_pop(L, 1);
    if (has) {
        if (!call_global("draw_bottom", 0, 0, 0)) { draw_error(BOT_W, BOT_H); return; }
    } else {
        ui_text_center_raw(BOT_W / 2, 90, 0.55f, COL_TEXT, infos[cur].title);
        ui_text_center_raw(BOT_W / 2, 130, 0.38f, COL_SUBTEXT, "B: salir   START: pausa");
    }
    if (paused) draw_pause(BOT_W, BOT_H);
}
