#include "games.h"
#include "audio.h"
#include "gfx_ui.h"
#include "settings.h"
#include "i18n.h"
#include "script.h"
#include <math.h>

#define MAX_NOTES 20000

typedef struct { u32 ms; unsigned char lane, state; } Beat;
typedef enum { ANALYZING, COUNTDOWN, PLAYING, RESULTS, GAME_ERROR } RhythmState;
static struct {
    GameKind kind;
    bool active, paused, ship;
    AudioStream *song;
    Beat *beats;
    int count, first, hits, misses, combo, best, score, lives, calibration;
    u64 scanned, windowSum;
    int windowCount, crossings, previous, rate;
    float average, lastEnergy, countdown, y, velocity, flash, grace;
    u32 touchKeys;
    RhythmState state;
    char title[MAX_NAME], error[MAX_NAME];
} game;

int game_total(void) { return GAME_COUNT + script_count(); }

const char *game_title(GameKind kind) {
    if ((int)kind >= GAME_COUNT) return script_title((int)kind - GAME_COUNT);
    static const char *names[] = {"Pulso de cuatro", "Cubo y nave", "Bloques 8x8",
        "Caida de bloques", "Salto verde", "Mundo de cubos", "Laberinto robot",
        "Serpiente", "2048", "Rompe ladrillos", "Pajarito", "Buscaminas", "Invasores",
        "Pong", "Topos", "Memoria", "Simon dice", "Ta-Te-Ti", "4 en linea", "Asteroides",
        "Dino corredor", "Luces", "Puzzle 15"};
    return tr(kind >= 0 && kind < GAME_COUNT ? names[kind] : "Juegos");
}

const char *game_description(GameKind kind) {
    if ((int)kind >= GAME_COUNT) return script_description((int)kind - GAME_COUNT);
    static const char *text[] = {"Cuatro carriles al ritmo de tu musica", "Salta y vuela sobre los pulsos de tu cancion",
        "Encaja piezas y completa filas y columnas", "Gira piezas, completa lineas y supera tu marca",
        "Plataformas, monedas y una meta por alcanzar", "Explora, rompe y coloca bloques en 3D",
        "Un shooter 2.5D con robots y una salida",
        "Come, crece y no te muerdas la cola", "Une fichas iguales hasta llegar a 2048",
        "Rebota la bola y destruye todos los ladrillos", "Pasa entre los tubos sin chocar",
        "Descubre las casillas sin pisar una mina", "Defende la Tierra de las oleadas",
        "Rebota la pelota y gana al rival", "Golpea los topos y esquiva las bombas",
        "Encuentra todas las parejas", "Repite la secuencia de colores",
        "Tres en raya contra la consola", "Alinea cuatro fichas antes que la consola",
        "Destruye las rocas sin chocar", "Salta los cactus y agachate ante los pajaros",
        "Apaga todas las luces", "Ordena las fichas del 1 al 15"};
    return tr(kind >= 0 && kind < GAME_COUNT ? text[kind] : "");
}

static bool is_puzzle(GameKind k) { return k >= GAME_BLOCKS && k <= GAME_PLATFORM; }
static bool is_arcade(GameKind k) { return k >= GAME_SNAKE && k <= GAME_INVADERS; }
static bool is_more(GameKind k) { return k >= GAME_PONG && k < GAME_COUNT; }

bool game_needs_song(GameKind kind) { return kind == GAME_RHYTHM || kind == GAME_DASH; }

void game_stop(void) {
    script_stop();
    settings_flush();
    if (game.song) {
        audio_out_stop();
        audio_close(game.song);
    }
    free(game.beats);
    memset(&game, 0, sizeof(game));
}

static void rhythm_error(const char *text) {
    audio_out_stop();
    snprintf(game.error, sizeof(game.error), "%s", text);
    game.state = GAME_ERROR;
}

bool game_start(GameKind kind, const char *songPath) {
    game_stop();
    if ((int)kind >= GAME_COUNT) return script_start((int)kind - GAME_COUNT);
    if (kind < 0) return false;
    game.kind = kind;
    if (game_needs_song(kind)) {
        if (!songPath) return false;
        game.song = audio_open(songPath);
        game.beats = calloc(MAX_NOTES, sizeof(Beat));
        if (!game.song || !game.beats) { game_stop(); return false; }
        game.rate = audio_sample_rate(game.song);
        if (audio_total_frames(game.song) > (u64)game.rate * 60 * 45) {
            game_stop();
            return false;
        }
        snprintf(game.title, sizeof(game.title), "%s", path_basename(songPath));
        strip_ext(game.title);
        game.state = ANALYZING;
    } else if (is_puzzle(kind)) {
        puzzle_start(kind);
    } else if (is_arcade(kind)) {
        arcade_start(kind);
    } else if (is_more(kind)) {
        more_start(kind);
    } else {
        world_start(kind);
    }
    game.active = true;
    return true;
}

static void rhythm_restart(void) {
    audio_out_stop();
    if (!audio_seek(game.song, 0)) { rhythm_error("No se pudo reiniciar la cancion."); return; }
    for (int i = 0; i < game.count; i++) game.beats[i].state = 0;
    game.first = game.hits = game.misses = game.combo = game.best = game.score = 0;
    game.lives = 5;
    game.countdown = 3;
    game.y = 193;
    game.velocity = game.flash = game.grace = 0;
    game.ship = false;
    game.state = COUNTDOWN;
    game.paused = false;
}

static void analyze_window(void) {
    float energy = (float)game.windowSum / game.windowCount;
    u32 ms = (u32)((game.scanned - game.windowCount) * 1000 / game.rate);
    int minimumGap = (game.kind == GAME_DASH ? 850 : 240) + (1 - g_settings.difficulty) * 80;
    bool separated = !game.count || ms - game.beats[game.count - 1].ms >= (u32)minimumGap;
    float flux = energy - game.lastEnergy;
    if (ms > 1200 && separated && energy > 450 && energy > game.average * 1.25f &&
        flux > fmaxf(150, game.average * 0.18f) && game.count < MAX_NOTES) {
        unsigned lane = ((unsigned)game.crossings + (unsigned)energy / 180 + game.count * 7) % 4;
        game.beats[game.count++] = (Beat){ms, (unsigned char)lane, 0};
    }
    game.average = game.average * 0.94f + energy * 0.06f;
    game.lastEnergy = energy;
    game.windowCount = game.crossings = 0;
    game.windowSum = 0;
}

static void analyze_song(void) {
    /* Must not live on the stack: the 3DS main-thread stack is small and the FLAC/MP3
     * decoders called below already need up to 16 KB of it. */
    static s16 pcm[AUDIO_CHUNK_FRAMES * 2];
    // Bounded decoding keeps input responsive while the beat map is prepared.
    for (int block = 0; block < 2; block++) {
        size_t frames = audio_read(game.song, pcm, AUDIO_CHUNK_FRAMES);
        if (!frames) {
            if (!game.count) { rhythm_error("No se detectaron pulsos. Proba otra cancion."); return; }
            rhythm_restart();
            return;
        }
        for (size_t i = 0; i < frames; i++) {
            int sample = ((int)pcm[i * 2] + pcm[i * 2 + 1]) / 2;
            if ((sample < 0) != (game.previous < 0)) game.crossings++;
            game.previous = sample;
            game.windowSum += (unsigned)abs(sample);
            game.windowCount++;
            game.scanned++;
            if (game.windowCount >= game.rate / 50) analyze_window();
        }
    }
}

static u32 song_ms(void) {
    if (!game.song) return 0;
    return (u32)(audio_out_position() * 1000 / game.rate);
}

static void register_hit(void) {
    game.hits++;
    game.combo++;
    if (game.combo > game.best) game.best = game.combo;
    game.score += 100 + (game.combo > 20 ? 20 : game.combo) * 10;
}

static void register_miss(void) {
    game.misses++;
    game.combo = 0;
    game.flash = 0.25f;
}

static void update_lanes(GameInput input, int now) {
    const u32 keys[] = {KEY_LEFT, KEY_DOWN, KEY_UP, KEY_RIGHT};
    if (input.down & KEY_L) game.calibration = clampi(game.calibration - 10, -200, 200);
    if (input.down & KEY_R) game.calibration = clampi(game.calibration + 10, -200, 200);
    now += game.calibration;
    for (int lane = 0; lane < 4; lane++) {
        if (!(input.down & keys[lane])) continue;
        int found = -1, distance = 151;
        for (int i = game.first; i < game.count && (int)game.beats[i].ms <= now + 150; i++) {
            int delta = abs((int)game.beats[i].ms - now);
            if (!game.beats[i].state && game.beats[i].lane == lane && delta < distance) {
                found = i;
                distance = delta;
            }
        }
        if (found >= 0) { game.beats[found].state = 1; register_hit(); }
        else register_miss();
    }
    while (game.first < game.count && (int)game.beats[game.first].ms < now - 150) {
        if (!game.beats[game.first].state) {
            game.beats[game.first].state = 2;
            register_miss();
        }
        game.first++;
    }
}

static bool dash_ship(u32 ms) { return (ms / 16000) % 2 != 0; }
static float gate_y(const Beat *beat) { return 116 + sinf(beat->ms * 0.0015f) * 24; }

static void update_dash(GameInput input, u32 now) {
    bool ship = dash_ship(now);
    if (ship != game.ship) {
        game.ship = ship;
        game.y = ship ? 128 : 193;
        game.velocity = 0;
        game.grace = 0.7f;
    }
    if (game.grace > 0) game.grace -= input.dt;
    bool held = (input.held & (KEY_A | KEY_TOUCH)) != 0;
    if (game.ship) {
        game.velocity += (held ? -540 : 430) * input.dt;
        game.velocity = fmaxf(-170, fminf(170, game.velocity));
        game.y += game.velocity * input.dt;
        if (game.y < 40) { game.y = 40; game.velocity = 0; }
        if (game.y > 190) { game.y = 190; game.velocity = 0; }
    } else {
        if ((input.down & KEY_A) && game.y >= 192.9f) game.velocity = -310;
        game.velocity += 850 * input.dt;
        game.y += game.velocity * input.dt;
        if (game.y > 193) { game.y = 193; game.velocity = 0; }
    }
    for (int i = game.first; i < game.count; i++) {
        Beat *beat = &game.beats[i];
        int delta = (int)beat->ms - (int)now;
        if (delta > 180) break;
        u32 phase = beat->ms % 16000;
        if (phase < 900 || phase > 15100) { beat->state = 1; continue; }
        if (beat->state) continue;
        bool collision = abs(delta) < 105 && game.grace <= 0 &&
            (game.ship ? fabsf(game.y - gate_y(beat)) > 43 : game.y + 10 > 177);
        if (collision) {
            beat->state = 2;
            register_miss();
            game.lives--;
            game.grace = 0.45f;
        } else if (delta < -110) {
            beat->state = 1;
            register_hit();
        }
    }
    while (game.first < game.count && (int)game.beats[game.first].ms < (int)now - 200)
        game.first++;
    if (game.lives <= 0) { audio_out_pause(true); game.state = RESULTS; }
}

void game_update(GameInput input) {
    if (script_active()) { script_update(input); return; }
    if (!game.active) return;
    input.dt = fmaxf(0, fminf(input.dt, 0.05f));
    input.down |= game.touchKeys;
    game.touchKeys = 0;
    if (input.down & KEY_START) {
        game.paused = !game.paused;
        if (game.song && game.state == PLAYING) audio_out_pause(game.paused);
        return;
    }
    if (game.paused) return;
    if (!game_needs_song(game.kind)) {
        if (is_puzzle(game.kind)) puzzle_update(input);
        else if (is_arcade(game.kind)) arcade_update(input);
        else if (is_more(game.kind)) more_update(input);
        else world_update(input);
        return;
    }
    if ((input.down & KEY_X) && game.state != ANALYZING && game.state != GAME_ERROR) {
        rhythm_restart();
        return;
    }
    if (game.state == ANALYZING) { analyze_song(); return; }
    if (game.state == COUNTDOWN) {
        game.countdown -= input.dt;
        if (game.countdown <= 0) {
            if (!audio_out_start(game.song)) { rhythm_error("No se pudo reproducir la cancion."); return; }
            game.state = PLAYING;
        }
        return;
    }
    if (game.state != PLAYING) return;
    if (game.flash > 0) game.flash -= input.dt;
    audio_out_update();
    u32 now = song_ms();
    if (game.kind == GAME_RHYTHM) update_lanes(input, (int)now);
    else update_dash(input, now);
    if (audio_out_finished()) {
        if (game.kind == GAME_RHYTHM) {
            for (int i = game.first; i < game.count; i++)
                if (!game.beats[i].state) { game.beats[i].state = 2; register_miss(); }
        }
        game.state = RESULTS;
    }
}

void game_touch(int x, int y) {
    if (script_active()) { script_touch(x, y); return; }
    if (!game.active || game.paused) return;
    if (!game_needs_song(game.kind)) {
        if (is_puzzle(game.kind)) puzzle_touch(x, y);
        else if (is_arcade(game.kind)) arcade_touch(x, y);
        else if (is_more(game.kind)) more_touch(x, y);
        else world_touch(x, y);
    } else if (game.kind == GAME_DASH) {
        game.touchKeys |= KEY_A;
    } else if (x >= 0 && x < 320 && y >= 72 && y < 200) {
        static const u32 keys[] = {KEY_LEFT, KEY_DOWN, KEY_UP, KEY_RIGHT};
        game.touchKeys |= keys[x / 80];
    }
}

static u32 lane_color(int lane) {
    static const unsigned char rgb[4][3] = {{29,185,84},{60,150,240},{240,180,40},{230,80,130}};
    return C2D_Color32(rgb[lane][0], rgb[lane][1], rgb[lane][2], 255);
}

static void draw_lanes(void) {
    int now = (int)song_ms() + game.calibration;
    for (int i = 0; i < 4; i++) {
        ui_rect(76 + i * 62, 35, 58, 190, COL_SURFACE2);
        ui_rounded(82 + i * 62, 194, 46, 13, 4, lane_color(i));
    }
    for (int i = game.first; i < game.count; i++) {
        Beat *beat = &game.beats[i];
        int delta = (int)beat->ms - now;
        if (delta > 1800) break;
        if (beat->state || delta < -180) continue;
        float y = 200 - delta * 0.085f;
        ui_rounded(84 + beat->lane * 62, y - 6, 42, 12, 4, lane_color(beat->lane));
    }
    ui_text(10, 70, 0.4f, COL_GREEN, "x%d", game.combo);
    ui_text(334, 70, 0.35f, COL_SUBTEXT, "%d", game.misses);
}

static void draw_dash(void) {
    u32 now = song_ms();
    ui_rect(0, 30, 400, 175, C2D_Color32(14, 26, 40, 255));
    for (int i = 0; i < 12; i++) {
        float x = (float)((i * 53 + 5000 - (now / 30) % 5000) % 440);
        ui_rect(x, 40 + (i * 29) % 90, 2, 2, COL_SUBTEXT);
    }
    ui_rect(0, 205, 400, 35, COL_SURFACE2);
    ui_rect(0, 205, 400, 2, COL_GREEN);
    for (int i = game.first; i < game.count; i++) {
        Beat *beat = &game.beats[i];
        int delta = (int)beat->ms - (int)now;
        if (delta > 2000) break;
        u32 phase = beat->ms % 16000;
        if (phase < 900 || phase > 15100 || delta < -350) continue;
        float x = 82 + delta * 0.18f;
        u32 col = beat->state == 2 ? COL_SUBTEXT : COL_GREEN;
        if (dash_ship(beat->ms)) {
            float gap = gate_y(beat);
            ui_rect(x - 9, 30, 18, gap - 85, col);
            ui_rect(x - 9, gap + 55, 18, 205 - gap - 55, col);
        } else {
            ui_triangle(x - 11, 204, x, 178, x + 11, 204, col);
        }
    }
    if (game.ship) ui_triangle(69, game.y - 9, 96, game.y, 69, game.y + 9, COL_TEXT);
    else ui_rounded(72, game.y - 10, 20, 20, 3, COL_TEXT);
    ui_text(12, 215, 0.4f, COL_TEXT, "%s   Vidas %d", game.ship ? "NAVE" : "CUBO", game.lives);
    ui_text_right(390, 216, 0.34f, COL_SUBTEXT, "Cambio de modo cada 16 s");
}

void game_draw_top(void) {
    if (script_active()) { script_draw_top(); return; }
    if (!game.active) return;
    if (!game_needs_song(game.kind)) {
        if (is_puzzle(game.kind)) puzzle_draw_top();
        else if (is_arcade(game.kind)) arcade_draw_top();
        else if (is_more(game.kind)) more_draw_top();
        else world_draw_top();
    } else {
        ui_text(12, 8, 0.55f, COL_GREEN, "%s", game_title(game.kind));
        if (game.state == ANALYZING) {
            u64 total = audio_total_frames(game.song);
            float progress = total ? fminf(1, (float)game.scanned / total) : 0;
            ui_text_center(200, 76, 0.55f, COL_TEXT, "Analizando tu cancion");
            ui_text_center(200, 110, 0.4f, COL_SUBTEXT, "Detectando cambios de energia y pulsos");
            ui_rect(40, 151, 320, 8, COL_SURFACE2);
            ui_rect(40, 151, 320 * progress, 8, COL_GREEN);
            ui_text(40, 175, 0.45f, COL_TEXT, "%d%%   %d notas", (int)(progress * 100), game.count);
        } else if (game.state == GAME_ERROR) {
            ui_text_clipped(20, 100, 0.45f, COL_TEXT, 360, game.error);
        } else if (game.state == COUNTDOWN) {
            char text[24];
            snprintf(text, sizeof(text), "%d", (int)ceilf(game.countdown));
            ui_text_center(200, 85, 2.0f, COL_GREEN, text);
            ui_text_center(200, 170, 0.45f, COL_TEXT, "Preparate para tu cancion");
        } else if (game.state == RESULTS) {
            ui_text_center(200, 52, 0.7f, COL_TEXT, game.lives > 0 ? "Cancion terminada" : "Fin de la partida");
            ui_text(70, 100, 0.6f, COL_GREEN, "Puntos: %d", game.score);
            ui_text(70, 138, 0.45f, COL_TEXT, "Aciertos %d  Fallos %d", game.hits, game.misses);
            ui_text(70, 168, 0.45f, COL_TEXT, "Mejor combo: %d", game.best);
            ui_text_center(200, 206, 0.4f, COL_SUBTEXT, "X: repetir   B: elegir otro juego");
        } else {
            if (game.kind == GAME_RHYTHM) draw_lanes(); else draw_dash();
            ui_text_right_raw(388, 9, 0.42f, COL_TEXT, game.title);
            ui_text(8, 32, 0.4f, COL_GREEN, "%d", game.score);
            if (game.flash > 0) ui_rect(0, 0, 400, 4, C2D_Color32(240, 70, 70, 255));
        }
    }
    if (game.paused) {
        ui_rounded(90, 82, 220, 70, 8, COL_SURFACE2);
        ui_text_center(200, 94, 0.7f, COL_GREEN, "Pausa");
        ui_text_center(200, 129, 0.4f, COL_TEXT, "START: continuar   B: menu");
    }
}

void game_draw_bottom(void) {
    if (script_active()) { script_draw_bottom(); return; }
    if (!game.active) return;
    if (!game_needs_song(game.kind)) {
        if (is_puzzle(game.kind)) puzzle_draw_bottom();
        else if (is_arcade(game.kind)) arcade_draw_bottom();
        else if (is_more(game.kind)) more_draw_bottom();
        else world_draw_bottom();
        return;
    }
    ui_text_clipped(12, 10, 0.46f, COL_TEXT, 296, game.title);
    if (game.kind == GAME_RHYTHM) {
        ui_text_center(160, 43, 0.38f, COL_SUBTEXT, "Cruceta o toca los cuatro carriles");
        static const char *labels[] = {"IZQ", "ABAJO", "ARRIBA", "DER"};
        for (int i = 0; i < 4; i++) {
            ui_rounded(i * 80 + 4, 72, 72, 120, 8, lane_color(i));
            ui_text_center(i * 80 + 40, 122, 0.38f, COL_BLACK, labels[i]);
        }
        ui_text(12, 201, 0.35f, COL_SUBTEXT, "L/R: ajuste %d ms", game.calibration);
    } else {
        ui_rounded(22, 62, 276, 122, 12, COL_GREEN);
        ui_text_center(160, 86, 0.65f, COL_BLACK, "A / TOCAR");
        ui_text_center(160, 125, 0.42f, COL_BLACK, "Cubo: pulsa para saltar");
        ui_text_center(160, 150, 0.42f, COL_BLACK, "Nave: manten para subir");
        ui_text_center(160, 196, 0.34f, COL_SUBTEXT, "Los obstaculos siguen los pulsos detectados");
    }
    ui_text_center(160, 222, 0.34f, COL_SUBTEXT, "START: pausa   X: repetir   B: menu");
}
