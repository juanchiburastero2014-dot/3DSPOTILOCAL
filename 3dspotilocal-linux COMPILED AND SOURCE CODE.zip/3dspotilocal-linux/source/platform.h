/* platform.h - capa de compatibilidad: reemplaza <3ds.h>/citro2d con tipos y constantes
 * equivalentes, asi la logica de la app y de los 23 minijuegos se reutiliza sin cambios. */
#ifndef VIBRA_PLATFORM_H
#define VIBRA_PLATFORM_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int16_t  s16;
typedef int32_t  s32;
typedef int64_t  s64;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ---- botones: mismos bits que libctru ---- */
#define KEY_A       (1u << 0)
#define KEY_B       (1u << 1)
#define KEY_SELECT  (1u << 2)
#define KEY_START   (1u << 3)
#define KEY_DRIGHT  (1u << 4)
#define KEY_DLEFT   (1u << 5)
#define KEY_DUP     (1u << 6)
#define KEY_DDOWN   (1u << 7)
#define KEY_R       (1u << 8)
#define KEY_L       (1u << 9)
#define KEY_X       (1u << 10)
#define KEY_Y       (1u << 11)
#define KEY_TOUCH   (1u << 20)
#define KEY_CPAD_RIGHT (1u << 28)
#define KEY_CPAD_LEFT  (1u << 29)
#define KEY_CPAD_UP    (1u << 30)
#define KEY_CPAD_DOWN  (1u << 31)
#define KEY_UP      (KEY_DUP    | KEY_CPAD_UP)
#define KEY_DOWN    (KEY_DDOWN  | KEY_CPAD_DOWN)
#define KEY_LEFT    (KEY_DLEFT  | KEY_CPAD_LEFT)
#define KEY_RIGHT   (KEY_DRIGHT | KEY_CPAD_RIGHT)

/* ---- color: RGBA en bytes (r en el byte bajo), igual que C2D_Color32 ---- */
#define C2D_Color32(r, g, b, a) ((u32)(((u32)(r) & 0xFF) | (((u32)(g) & 0xFF) << 8) | (((u32)(b) & 0xFF) << 16) | (((u32)(a) & 0xFF) << 24)))
#define COLOR_R(c) ((int)((c) & 0xFF))
#define COLOR_G(c) ((int)(((c) >> 8) & 0xFF))
#define COLOR_B(c) ((int)(((c) >> 16) & 0xFF))
#define COLOR_A(c) ((int)(((c) >> 24) & 0xFF))

/* ---- imagen lista para dibujar (textura del backend) ---- */
typedef struct { void *tex; int w, h; } C2D_Image;

/* milisegundos desde un punto arbitrario (monotonico) */
static inline u64 osGetTime(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (u64)ts.tv_sec * 1000u + (u64)(ts.tv_nsec / 1000000);
}

/* ---- carpetas de datos (se resuelven al iniciar, ver platform_init_paths) ---- */
#define PATH_MAX_LEN 512
extern char g_dir_base[PATH_MAX_LEN];
extern char g_dir_music[PATH_MAX_LEN];
extern char g_dir_video[PATH_MAX_LEN];
extern char g_dir_covers[PATH_MAX_LEN];
extern char g_dir_lyrics[PATH_MAX_LEN];
extern char g_dir_games[PATH_MAX_LEN];
extern char g_dir_assets[PATH_MAX_LEN];
extern char g_path_settings[PATH_MAX_LEN];
extern char g_path_covers_cfg[PATH_MAX_LEN];

/* override puede ser NULL. Orden: override, $SPOTILOCAL_HOME, ~/3dSpotiLocal */
void platform_init_paths(const char *override, const char *exeDir);

#endif
