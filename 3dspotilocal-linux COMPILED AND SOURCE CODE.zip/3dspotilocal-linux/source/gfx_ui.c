/* gfx_ui.c - backend grafico SDL2 + FreeType.
 * Cada pantalla de la 3DS se dibuja en una textura "supersampleada" (T veces mas grande) y despues se
 * compone en la ventana con filtro lineal: formas suaves, texto nitido, cualquier tamano de ventana. */
#include "gfx_ui.h"
#include "i18n.h"
#include <SDL2/SDL.h>
#include <stdarg.h>
#include <ft2build.h>
#include FT_FREETYPE_H

#define STBI_NO_HDR
#define STBI_NO_LINEAR
#include "stb_image.h"

#define FONT_K 29.0f              /* tamano de fuente (px) para scale = 1.0 */
#define TEXT_CACHE 512

/* ------------------------------------------------------------------ estado */
static SDL_Window   *win;
static SDL_Renderer *ren;
static SDL_Texture  *tgtTop, *tgtBot, *tgtMain;
static bool  deskMode;
static float deskS = 1, mainW = 800, mainH = 450, zoomK = 1;
static int   mainPxW, mainPxH;
static int   T = 2;
static float curW = TOP_W, curH = TOP_H;
static float offX, offY, fadeAmt;
static bool  fullscreen, noLimiter, addBlend;
static int   layoutMode;                       /* 0 auto, 1 lado a lado, 2 apiladas */
static float dtSec = 1.0f / 60.0f;
static Uint64 lastTicks, startTicks, frameStart;
static bool  screenshotPending;
static C2D_Image cinemaImg;
static bool  cinemaForce;
static u64   lastActivity, lastClickMs;
static int   lastMx = -1, lastMy = -1;
static char  screenshotPath[MAX_PATH];

/* layout actual (px de salida) */
static float lyS = 1, lyBS = 1, lyTopX, lyTopY, lyBotX, lyBotY;
static int   outW = 800, outH = 480, winW_ = 800, winH_ = 480;

static inline float PX(float v) { return v * (float)T; }
static inline void set_col(u32 c) { SDL_SetRenderDrawColor(ren, COLOR_R(c), COLOR_G(c), COLOR_B(c), COLOR_A(c)); }
static inline SDL_Color to_sdl(u32 c) { SDL_Color k = { (Uint8)COLOR_R(c), (Uint8)COLOR_G(c), (Uint8)COLOR_B(c), (Uint8)COLOR_A(c) }; return k; }

/* ------------------------------------------------------------------ fuentes */
static FT_Library ftLib;
static FT_Face faceReg, faceBold;

static bool try_face(FT_Face *out, const char *path) {
    if (!path || !path[0]) return false;
    return FT_New_Face(ftLib, path, 0, out) == 0;
}

static bool fonts_init(void) {
    if (FT_Init_FreeType(&ftLib) != 0) return false;
    char p[PATH_MAX_LEN + 64];
    snprintf(p, sizeof(p), "%s/fonts/LiberationSans-Regular.ttf", g_dir_assets);
    bool ok = try_face(&faceReg, p);
    static const char *sysReg[] = {
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/liberation-sans/LiberationSans-Regular.ttf",
        "/usr/share/fonts/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
        "/usr/share/fonts/noto/NotoSans-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf", NULL };
    for (int i = 0; !ok && sysReg[i]; i++) ok = try_face(&faceReg, sysReg[i]);
    if (!ok) return false;
    snprintf(p, sizeof(p), "%s/fonts/LiberationSans-Bold.ttf", g_dir_assets);
    bool okb = try_face(&faceBold, p);
    static const char *sysBold[] = {
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/liberation-sans/LiberationSans-Bold.ttf",
        "/usr/share/fonts/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf", NULL };
    for (int i = 0; !okb && sysBold[i]; i++) okb = try_face(&faceBold, sysBold[i]);
    if (!okb) faceBold = faceReg;
    return true;
}

static unsigned utf8_next(const unsigned char **ps) {
    const unsigned char *s = *ps;
    unsigned c = *s++;
    if (c < 0x80) { *ps = s; return c; }
    int extra = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
    unsigned cp = extra == 3 ? (c & 0x07) : extra == 2 ? (c & 0x0F) : extra == 1 ? (c & 0x1F) : 0xFFFD;
    for (int i = 0; i < extra; i++) {
        if ((*s & 0xC0) != 0x80) { *ps = s; return 0xFFFD; }
        cp = (cp << 6) | (*s++ & 0x3F);
    }
    *ps = s;
    return cp;
}

typedef struct {
    u32  hash; int px; bool bold;
    char *str;
    SDL_Texture *tex; int w, h;
    u32  used;
} TextEntry;
static TextEntry tcache[TEXT_CACHE];
static u32 tick;

static u32 hash_str(const char *s, int px, bool bold) {
    u32 h = 2166136261u ^ (u32)px ^ (bold ? 0x9e3779b9u : 0);
    for (; *s; s++) h = (h ^ (unsigned char)*s) * 16777619u;
    return h;
}

static FT_Face face_for(bool bold, int px) {
    FT_Face f = bold ? faceBold : faceReg;
    FT_Set_Pixel_Sizes(f, 0, (FT_UInt)px);
    return f;
}

static int font_px(float scale) {
    int px = (int)lroundf(scale * FONT_K * (float)T);
    return px < 6 ? 6 : px;
}
static bool font_bold(float scale) { return scale >= 0.7f; }

/* ancho en unidades 26.6 de la cadena a ese tamano */
static long measure_units(const char *str, int px, bool bold) {
    FT_Face f = face_for(bold, px);
    long pen = 0;
    FT_UInt prev = 0;
    const unsigned char *s = (const unsigned char *)str;
    while (*s) {
        unsigned cp = utf8_next(&s);
        FT_UInt gi = FT_Get_Char_Index(f, cp);
        if (FT_HAS_KERNING(f) && prev && gi) {
            FT_Vector k;
            FT_Get_Kerning(f, prev, gi, FT_KERNING_UNFITTED, &k);
            pen += k.x;
        }
        if (FT_Load_Glyph(f, gi, FT_LOAD_NO_HINTING) == 0) pen += f->glyph->advance.x;
        prev = gi;
    }
    return pen;
}

static TextEntry *text_entry(const char *str, int px, bool bold) {
    u32 h = hash_str(str, px, bold);
    TextEntry *free_ = NULL, *oldest = &tcache[0];
    for (int i = 0; i < TEXT_CACHE; i++) {
        TextEntry *e = &tcache[i];
        if (e->str && e->hash == h && e->px == px && e->bold == bold && strcmp(e->str, str) == 0) {
            e->used = ++tick;
            return e;
        }
        if (!e->str && !free_) free_ = e;
        if (e->used < oldest->used) oldest = e;
    }
    TextEntry *e = free_ ? free_ : oldest;
    if (e->str) { free(e->str); e->str = NULL; if (e->tex) SDL_DestroyTexture(e->tex); e->tex = NULL; }

    FT_Face f = face_for(bold, px);
    int asc = (int)((f->size->metrics.ascender + 63) >> 6);
    int desc = (int)((-f->size->metrics.descender + 63) >> 6);
    int lineH = asc + desc;
    long wUnits = measure_units(str, px, bold);
    int w = (int)((wUnits + 63) >> 6) + 4;
    if (w < 1) w = 1;
    if (w > 4096) w = 4096;
    u8 *alpha = (u8 *)calloc((size_t)w * (size_t)lineH, 1);
    if (!alpha) return NULL;
    long pen = 0;
    FT_UInt prev = 0;
    const unsigned char *s = (const unsigned char *)str;
    while (*s) {
        unsigned cp = utf8_next(&s);
        FT_UInt gi = FT_Get_Char_Index(f, cp);
        if (FT_HAS_KERNING(f) && prev && gi) {
            FT_Vector k;
            FT_Get_Kerning(f, prev, gi, FT_KERNING_UNFITTED, &k);
            pen += k.x;
        }
        if (FT_Load_Glyph(f, gi, FT_LOAD_NO_HINTING | FT_LOAD_TARGET_LIGHT) == 0 &&
            FT_Render_Glyph(f->glyph, FT_RENDER_MODE_NORMAL) == 0) {
            FT_Bitmap *bm = &f->glyph->bitmap;
            int gx = (int)(pen >> 6) + f->glyph->bitmap_left + 1;
            int gy = asc - f->glyph->bitmap_top;
            for (unsigned yy = 0; yy < bm->rows; yy++) {
                int dy = gy + (int)yy;
                if (dy < 0 || dy >= lineH) continue;
                for (unsigned xx = 0; xx < bm->width; xx++) {
                    int dx = gx + (int)xx;
                    if (dx < 0 || dx >= w) continue;
                    u8 v = bm->buffer[yy * (unsigned)bm->pitch + xx];
                    u8 *d = &alpha[(size_t)dy * (size_t)w + (size_t)dx];
                    int nv = *d + v;
                    *d = (u8)(nv > 255 ? 255 : nv);
                }
            }
            pen += f->glyph->advance.x;
        }
        prev = gi;
    }
    u8 *rgba = (u8 *)malloc((size_t)w * (size_t)lineH * 4);
    if (!rgba) { free(alpha); return NULL; }
    for (size_t i = 0; i < (size_t)w * (size_t)lineH; i++) {
        rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = 255;
        rgba[i * 4 + 3] = alpha[i];
    }
    free(alpha);
    SDL_Texture *tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, w, lineH);
    if (tex) {
        SDL_UpdateTexture(tex, NULL, rgba, w * 4);
        SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
        SDL_SetTextureScaleMode(tex, SDL_ScaleModeLinear);
    }
    free(rgba);
    e->hash = h; e->px = px; e->bold = bold;
    e->str = strdup(str);
    e->tex = tex; e->w = w; e->h = lineH;
    e->used = ++tick;
    return e;
}

static void text_cache_clear(void) {
    for (int i = 0; i < TEXT_CACHE; i++) {
        if (tcache[i].tex) SDL_DestroyTexture(tcache[i].tex);
        free(tcache[i].str);
        memset(&tcache[i], 0, sizeof(tcache[i]));
    }
}

/* ------------------------------------------------------------------ ventana / layout */
static void make_targets(void) {
    if (tgtTop) SDL_DestroyTexture(tgtTop);
    if (tgtBot) SDL_DestroyTexture(tgtBot);
    tgtTop = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET, TOP_W * T, TOP_H * T);
    tgtBot = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET, BOT_W * T, BOT_H * T);
    if (tgtTop) SDL_SetTextureScaleMode(tgtTop, SDL_ScaleModeLinear);
    if (tgtBot) SDL_SetTextureScaleMode(tgtBot, SDL_ScaleModeLinear);
    text_cache_clear();
}

static void make_main(void) {
    int w = (int)ceilf(mainW * (float)T), h = (int)ceilf(mainH * (float)T);
    if (w < 8) w = 8;
    if (h < 8) h = 8;
    if (tgtMain && w == mainPxW && h == mainPxH) return;
    if (tgtMain) SDL_DestroyTexture(tgtMain);
    tgtMain = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET, w, h);
    if (tgtMain) SDL_SetTextureScaleMode(tgtMain, SDL_ScaleModeLinear);
    mainPxW = w; mainPxH = h;
}

static void compute_layout(void) {
    SDL_GetRendererOutputSize(ren, &outW, &outH);
    SDL_GetWindowSize(win, &winW_, &winH_);
    if (outW < 1) outW = 1;
    if (outH < 1) outH = 1;
    const float m = 5.0f, gap = 9.0f;
    float sideW = TOP_W + gap + BOT_W + 2 * m, sideH = TOP_H + 2 * m;
    float stkW = TOP_W + 2 * m, stkH = TOP_H + gap + BOT_H + 2 * m;
    float sSide = fminf((float)outW / sideW, (float)outH / sideH);
    float sStk = fminf((float)outW / stkW, (float)outH / stkH);
    if (deskMode) {                                  /* UI unificada: el lienzo ocupa toda la ventana */
        deskS = (float)outH / 560.0f * zoomK;
        if (deskS < 0.6f) deskS = 0.6f;
        if (deskS > 5.0f) deskS = 5.0f;
        mainW = (float)outW / deskS;
        mainH = (float)outH / deskS;
        int w2 = (int)ceilf(deskS);
        if (w2 < 1) w2 = 1;
        if (w2 > 3) w2 = 3;
        if (w2 != T || !tgtTop) { T = w2; make_targets(); }
        make_main();
        return;
    }
    bool cine = cinemaImg.tex != NULL;
    bool stacked = layoutMode == 2 || (layoutMode == 0 && sStk > sSide * 1.04f);
    if (cine) {                                  /* panel de controles abajo al centro; la pantalla superior no se usa */
        lyS = fminf((float)outW * 0.46f / BOT_W, (float)outH * 0.42f / BOT_H);
        lyBS = lyS;
        if (lyS < 0.6f) lyS = 0.6f;
        lyBotX = ((float)outW - BOT_W * lyS) / 2;
        lyBotY = (float)outH - BOT_H * lyS - 14.0f * lyS * 0.5f;
        lyTopX = -10000; lyTopY = -10000;
    } else if (layoutMode == 3) {                 /* grande: arriba ocupa la ventana, la tactil flota en una esquina */
        lyS = fminf((float)outW / TOP_W, (float)outH / TOP_H);
        lyBS = lyS * 0.40f;
        lyTopX = ((float)outW - TOP_W * lyS) / 2;
        lyTopY = ((float)outH - TOP_H * lyS) / 2;
        lyBotX = (float)outW - BOT_W * lyBS - 14.0f;
        lyBotY = (float)outH - BOT_H * lyBS - 14.0f;
    } else if (!stacked) {
        lyS = sSide;
        lyBS = lyS;
        float cw = (TOP_W + gap + BOT_W) * lyS;
        lyTopX = ((float)outW - cw) / 2;
        lyTopY = ((float)outH - TOP_H * lyS) / 2;
        lyBotX = lyTopX + (TOP_W + gap) * lyS;
        lyBotY = lyTopY;
    } else {
        lyS = sStk;
        lyBS = lyS;
        float ch = (TOP_H + gap + BOT_H) * lyS;
        lyTopX = ((float)outW - TOP_W * lyS) / 2;
        lyTopY = ((float)outH - ch) / 2;
        lyBotX = ((float)outW - BOT_W * lyS) / 2;
        lyBotY = lyTopY + (TOP_H + gap) * lyS;
    }
    int want = (int)ceilf(fmaxf(lyS, lyBS));
    if (want < 1) want = 1;
    if (want > 3) want = 3;
    if (want != T || !tgtTop) { T = want; make_targets(); }
    make_main();
}

bool ui_init(const char *title, int w, int h, bool software) {
    noLimiter = software;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) != 0) {
        fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());
        return false;
    }
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
    win = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h,
                           SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if (!win) { fprintf(stderr, "SDL_CreateWindow: %s\n", SDL_GetError()); return false; }
    SDL_SetWindowMinimumSize(win, 400, 240);
    if (!software) ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_TARGETTEXTURE);
    if (!ren) ren = SDL_CreateRenderer(win, -1, software ? SDL_RENDERER_SOFTWARE : 0);
    if (!ren) { fprintf(stderr, "SDL_CreateRenderer: %s\n", SDL_GetError()); return false; }
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    if (!fonts_init()) {
        fprintf(stderr, "No encontre una fuente TTF (assets/fonts o fuentes del sistema).\n");
        return false;
    }
    {   /* icono de la ventana */
        char p[PATH_MAX_LEN + 32];
        snprintf(p, sizeof(p), "%s/icon.png", g_dir_assets);
        int iw, ih, comp;
        unsigned char *px = stbi_load(p, &iw, &ih, &comp, 4);
        if (px) {
            SDL_Surface *s = SDL_CreateRGBSurfaceWithFormatFrom(px, iw, ih, 32, iw * 4, SDL_PIXELFORMAT_ABGR8888);
            if (s) { SDL_SetWindowIcon(win, s); SDL_FreeSurface(s); }
            stbi_image_free(px);
        }
    }
    compute_layout();
    if (!tgtTop || !tgtBot) { fprintf(stderr, "No se pudieron crear las texturas de render: %s\n", SDL_GetError()); return false; }
    startTicks = lastTicks = SDL_GetTicks64();
    return true;
}

void ui_exit(void) {
    text_cache_clear();
    if (tgtTop) SDL_DestroyTexture(tgtTop);
    if (tgtBot) SDL_DestroyTexture(tgtBot);
    if (tgtMain) SDL_DestroyTexture(tgtMain);
    tgtTop = tgtBot = tgtMain = NULL;
    if (ren) SDL_DestroyRenderer(ren);
    if (win) SDL_DestroyWindow(win);
    ren = NULL; win = NULL;
    if (faceBold && faceBold != faceReg) FT_Done_Face(faceBold);
    if (faceReg) FT_Done_Face(faceReg);
    if (ftLib) FT_Done_FreeType(ftLib);
    faceReg = faceBold = NULL; ftLib = NULL;
    SDL_Quit();
}

void ui_cinema(C2D_Image img, bool forceControls) { cinemaImg = img; cinemaForce = forceControls; }
static bool cinema_controls_visible(void) { return cinemaForce || (SDL_GetTicks64() - lastActivity) < 3000; }

float ui_dt(void) { return dtSec; }
double ui_time(void) { return (double)(SDL_GetTicks64() - startTicks) / 1000.0; }

void ui_toggle_fullscreen(void) {
    fullscreen = !fullscreen;
    SDL_SetWindowFullscreen(win, fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
}
void ui_cycle_layout(void) { layoutMode = (layoutMode + 1) % 4; }

/* ------------------------------------------------------------------ entrada */
static u32 prevHeld;
static bool dragging, f11Prev, f2Prev, f12Prev;
static SDL_GameController *pad;
static u64 repeatAt[32];
static bool pausePulse;

static void pad_refresh(void) {
    if (pad) return;
    for (int i = 0; i < SDL_NumJoysticks(); i++)
        if (SDL_IsGameController(i)) { pad = SDL_GameControllerOpen(i); if (pad) break; }
}

bool ui_poll_input(UiInput *in) {
    memset(in, 0, sizeof(*in));
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        if (e.type == SDL_QUIT) in->quit = true;
        else if (e.type == SDL_MOUSEWHEEL) in->wheel += e.wheel.y;
        else if (e.type == SDL_CONTROLLERDEVICEADDED) pad_refresh();
        else if (e.type == SDL_CONTROLLERDEVICEREMOVED) { if (pad) SDL_GameControllerClose(pad); pad = NULL; pad_refresh(); }
    }
    pad_refresh();
    const Uint8 *k = SDL_GetKeyboardState(NULL);

    u32 held = 0;
    int cx = 0, cy = 0;
    /* teclado: flechas = cruceta, WASD = circle pad */
    if (k[SDL_SCANCODE_UP])    held |= KEY_DUP;
    if (k[SDL_SCANCODE_DOWN])  held |= KEY_DDOWN;
    if (k[SDL_SCANCODE_LEFT])  held |= KEY_DLEFT;
    if (k[SDL_SCANCODE_RIGHT]) held |= KEY_DRIGHT;
    if (k[SDL_SCANCODE_W]) cy += 156;
    if (k[SDL_SCANCODE_S]) cy -= 156;
    if (k[SDL_SCANCODE_A]) cx -= 156;
    if (k[SDL_SCANCODE_D]) cx += 156;
    if (k[SDL_SCANCODE_RETURN] || k[SDL_SCANCODE_KP_ENTER] || k[SDL_SCANCODE_J] || k[SDL_SCANCODE_Z]) held |= KEY_A;
    if (k[SDL_SCANCODE_BACKSPACE] || k[SDL_SCANCODE_ESCAPE] || k[SDL_SCANCODE_K] || k[SDL_SCANCODE_X]) held |= KEY_B;
    if (k[SDL_SCANCODE_U]) held |= KEY_X;
    if (k[SDL_SCANCODE_I]) held |= KEY_Y;
    if (k[SDL_SCANCODE_Q]) held |= KEY_L;
    if (k[SDL_SCANCODE_E]) held |= KEY_R;
    if (k[SDL_SCANCODE_SPACE]) held |= KEY_START;
    if (k[SDL_SCANCODE_TAB]) held |= KEY_SELECT;
    /* gamepad: botones por posicion, como en la consola (A = el de la derecha) */
    if (pad) {
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_B)) held |= KEY_A;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_A)) held |= KEY_B;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_Y)) held |= KEY_X;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_X)) held |= KEY_Y;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_LEFTSHOULDER)) held |= KEY_L;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER)) held |= KEY_R;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_START)) held |= KEY_START;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_BACK)) held |= KEY_SELECT;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_UP)) held |= KEY_DUP;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_DOWN)) held |= KEY_DDOWN;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_LEFT)) held |= KEY_DLEFT;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_RIGHT)) held |= KEY_DRIGHT;
        if (SDL_GameControllerGetAxis(pad, SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 12000) held |= KEY_L;
        if (SDL_GameControllerGetAxis(pad, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 12000) held |= KEY_R;
        int ax = SDL_GameControllerGetAxis(pad, SDL_CONTROLLER_AXIS_LEFTX);
        int ay = -SDL_GameControllerGetAxis(pad, SDL_CONTROLLER_AXIS_LEFTY);
        if (abs(ax) > 6000) cx += ax * 156 / 32767;
        if (abs(ay) > 6000) cy += ay * 156 / 32767;
    }
    if (cx > 156) cx = 156;
    if (cx < -156) cx = -156;
    if (cy > 156) cy = 156;
    if (cy < -156) cy = -156;
    in->circleX = cx; in->circleY = cy;
    if (cx > 50) held |= KEY_CPAD_RIGHT;
    if (cx < -50) held |= KEY_CPAD_LEFT;
    if (cy > 50) held |= KEY_CPAD_UP;
    if (cy < -50) held |= KEY_CPAD_DOWN;

    /* mouse = stylus sobre la pantalla inferior */
    int mx, my;
    Uint32 mb = SDL_GetMouseState(&mx, &my);
    float fx = (winW_ > 0) ? (float)mx * (float)outW / (float)winW_ : (float)mx;
    float fy = (winH_ > 0) ? (float)my * (float)outH / (float)winH_ : (float)my;
    float bx = (fx - lyBotX) / lyBS, by = (fy - lyBotY) / lyBS;
    bool inside = bx >= 0 && by >= 0 && bx < BOT_W && by < BOT_H;
    Uint64 nowMs = SDL_GetTicks64();
    {   /* mouse en el lienzo unico */
        in->mouseX = fx / deskS;
        in->mouseY = fy / deskS;
        in->mouseInside = fx >= 0 && fy >= 0 && fx < (float)outW && fy < (float)outH;
        in->mouseMoved = (mx != lastMx || my != lastMy);
        bool ld = (mb & SDL_BUTTON_LMASK) != 0, rd = (mb & 4) != 0;
        static bool lPrev, rPrev;
        in->mouseDown = ld;
        in->mouseClicked = ld && !lPrev;
        in->mouseReleased = !ld && lPrev;
        in->rightClicked = rd && !rPrev;
        lPrev = ld; rPrev = rd;
    }
    if (mx != lastMx || my != lastMy) { lastActivity = nowMs; lastMx = mx; lastMy = my; }
    bool cine = cinemaImg.tex != NULL;
    bool ctrlVisible = !cine || cinema_controls_visible();
    static bool prevLeft;
    bool leftDown = (mb & SDL_BUTTON_LMASK) != 0;
    bool leftPressed = leftDown && !prevLeft;
    prevLeft = leftDown;
    if (cine && leftPressed) {
        lastActivity = nowMs;
        if (nowMs - lastClickMs < 350) ui_toggle_fullscreen();
        lastClickMs = nowMs;
    }
    bool clickOnPanel = inside && ctrlVisible;
    if (leftDown) {
        if (clickOnPanel && !dragging && !(prevHeld & KEY_TOUCH)) dragging = true;
    } else dragging = false;
    if (cine && leftPressed && !clickOnPanel && !deskMode) pausePulse = true;   /* clic sobre el video: pausa/reanuda */
    if (dragging) {
        in->touching = true;
        in->touchX = (int)fminf(fmaxf(bx, 0), BOT_W - 1);
        in->touchY = (int)fminf(fmaxf(by, 0), BOT_H - 1);
        held |= KEY_TOUCH;
    }

    /* atajos de la ventana */
    bool f11 = k[SDL_SCANCODE_F11] || (k[SDL_SCANCODE_LALT] && k[SDL_SCANCODE_RETURN]);
    bool f2 = k[SDL_SCANCODE_F2], f12 = k[SDL_SCANCODE_F12];
    {   static bool f3p, f4p;
        bool f3 = k[SDL_SCANCODE_F3], f4 = k[SDL_SCANCODE_F4];
        if (f3 && !f3p) zoomK = fmaxf(0.6f, zoomK / 1.12f);
        if (f4 && !f4p) zoomK = fminf(1.8f, zoomK * 1.12f);
        f3p = f3; f4p = f4;
    }
    if (f11 && !f11Prev) ui_toggle_fullscreen();
    if (f2 && !f2Prev) ui_cycle_layout();
    if (f12 && !f12Prev) {
        time_t t = time(NULL);
        snprintf(screenshotPath, sizeof(screenshotPath), "%s/screenshot_%ld.bmp", g_dir_base, (long)t);
        screenshotPending = true;
    }
    f11Prev = f11; f2Prev = f2; f12Prev = f12;
    if (k[SDL_SCANCODE_LALT] && k[SDL_SCANCODE_RETURN]) held &= ~KEY_A;

    if (held & ~prevHeld) lastActivity = nowMs;                      /* cualquier tecla muestra los controles */
    in->held = held;
    in->down = held & ~prevHeld;
    if (pausePulse) { in->down |= KEY_A; pausePulse = false; }
    in->downRepeat = in->down;
    u64 now = nowMs;
    u32 dirs = KEY_DUP | KEY_DDOWN | KEY_DLEFT | KEY_DRIGHT | KEY_CPAD_UP | KEY_CPAD_DOWN | KEY_CPAD_LEFT | KEY_CPAD_RIGHT;
    for (int b = 0; b < 32; b++) {
        u32 bit = 1u << b;
        if (!(dirs & bit)) continue;
        if (in->down & bit) repeatAt[b] = now + 420;
        else if ((held & bit) && now >= repeatAt[b]) { in->downRepeat |= bit; repeatAt[b] = now + 70; }
    }
    prevHeld = held;
    return !in->quit;
}

/* ------------------------------------------------------------------ frame */
static void begin_target(SDL_Texture *t, float lw, float lh, u32 clearCol) {
    SDL_SetRenderTarget(ren, t);
    SDL_RenderSetClipRect(ren, NULL);
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    addBlend = false;
    curW = lw; curH = lh;
    set_col(clearCol);
    SDL_RenderClear(ren);
}

void ui_frame_begin(void) {
    Uint64 now = SDL_GetTicks64();
    float d = (float)(now - lastTicks) / 1000.0f;
    lastTicks = now;
    frameStart = now;
    if (d < 0.0005f) d = 0.0005f;
    if (d > 0.1f) d = 0.1f;
    dtSec = d;
    compute_layout();
    offX = offY = 0;
    fadeAmt = 0;
}

void ui_scene_top(void) { begin_target(tgtTop, TOP_W, TOP_H, COL_BG); }
void ui_scene_bottom(void) { begin_target(tgtBot, BOT_W, BOT_H, COL_BG); }
void ui_scene_main(void) { begin_target(tgtMain, mainW, mainH, cinemaImg.tex ? 0u : COL_BG); }
void ui_set_desktop(bool on) {
    if (deskMode == on) return;
    deskMode = on;
    if (ren) compute_layout();
}
bool ui_is_desktop(void) { return deskMode; }
float ui_main_w(void) { return mainW; }
float ui_main_h(void) { return mainH; }
bool ui_cinema_controls_visible(void) { return cinema_controls_visible(); }

void ui_clear(u32 color) {
    SDL_RenderSetClipRect(ren, NULL);
    set_col(color);
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_NONE);
    SDL_RenderClear(ren);
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
}

/* ayudantes en espacio de ventana (composicion final) */
static void win_rect(float x, float y, float w, float h, u32 c) {
    SDL_FRect r = { x, y, w, h };
    set_col(c);
    SDL_RenderFillRectF(ren, &r);
}

static void win_shadow(float x, float y, float w, float h, float spread) {
    for (int i = 8; i >= 1; i--) {
        float g = spread * (float)i / 8.0f;
        int a = 9 + (8 - i) * 2;
        win_rect(x - g, y - g + spread * 0.35f, w + 2 * g, h + 2 * g, C2D_Color32(0, 0, 0, a));
    }
}

static bool save_bmp(const void *pixels, int w, int h, const char *path) {
    SDL_Surface *s = SDL_CreateRGBSurfaceWithFormatFrom((void *)pixels, w, h, 32, w * 4, SDL_PIXELFORMAT_ABGR8888);
    if (!s) return false;
    int r = SDL_SaveBMP(s, path);
    SDL_FreeSurface(s);
    return r == 0;
}

static void compose_background(void) {
    SDL_Vertex v[4];
    SDL_Color top = { 24, 26, 32, 255 }, bot = { 8, 9, 12, 255 };
    v[0].position = (SDL_FPoint){ 0, 0 };            v[0].color = top;
    v[1].position = (SDL_FPoint){ (float)outW, 0 };  v[1].color = top;
    v[2].position = (SDL_FPoint){ (float)outW, (float)outH }; v[2].color = bot;
    v[3].position = (SDL_FPoint){ 0, (float)outH };  v[3].color = bot;
    for (int i = 0; i < 4; i++) v[i].tex_coord = (SDL_FPoint){ 0, 0 };
    static const int idx[6] = { 0, 1, 2, 0, 2, 3 };
    SDL_RenderGeometry(ren, NULL, v, 4, idx, 6);
}

void ui_frame_end(void) {
    SDL_SetRenderTarget(ren, NULL);
    SDL_RenderSetClipRect(ren, NULL);
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    set_col(C2D_Color32(8, 9, 12, 255));
    SDL_RenderClear(ren);
    compose_background();

    float tw = TOP_W * lyS, th = TOP_H * lyS, bw = BOT_W * lyBS, bh = BOT_H * lyBS;
    if (deskMode) {
        SDL_FRect full = { 0, 0, (float)outW, (float)outH };
        if (cinemaImg.tex) {
            set_col(C2D_Color32(0, 0, 0, 255));
            SDL_RenderClear(ren);
            float sc = fminf((float)outW / (float)cinemaImg.w, (float)outH / (float)cinemaImg.h);
            float vw = (float)cinemaImg.w * sc, vh = (float)cinemaImg.h * sc;
            SDL_FRect vr = { ((float)outW - vw) / 2, ((float)outH - vh) / 2, vw, vh };
            SDL_RenderCopyF(ren, (SDL_Texture *)cinemaImg.tex, NULL, &vr);
            SDL_SetTextureBlendMode(tgtMain, SDL_BLENDMODE_BLEND);
            SDL_ShowCursor(cinema_controls_visible() ? 1 : 0);
        } else {
            SDL_SetTextureBlendMode(tgtMain, SDL_BLENDMODE_NONE);
            SDL_ShowCursor(1);
        }
        SDL_RenderCopyF(ren, tgtMain, NULL, &full);
        if (fadeAmt > 0.001f) win_rect(0, 0, (float)outW, (float)outH, C2D_Color32(0, 0, 0, (int)(fminf(fadeAmt, 1.0f) * 255)));
    } else if (cinemaImg.tex) {
        /* video a ventana completa + panel de controles semitransparente */
        set_col(C2D_Color32(0, 0, 0, 255));
        SDL_RenderClear(ren);
        float sc = fminf((float)outW / (float)cinemaImg.w, (float)outH / (float)cinemaImg.h);
        float vw = (float)cinemaImg.w * sc, vh = (float)cinemaImg.h * sc;
        SDL_FRect vr = { ((float)outW - vw) / 2, ((float)outH - vh) / 2, vw, vh };
        SDL_RenderCopyF(ren, (SDL_Texture *)cinemaImg.tex, NULL, &vr);
        if (cinema_controls_visible()) {
            SDL_FRect db2 = { lyBotX, lyBotY, bw, bh };
            win_shadow(lyBotX, lyBotY, bw, bh, 8.0f * lyS / 2.0f);
            SDL_SetTextureBlendMode(tgtBot, SDL_BLENDMODE_BLEND);
            SDL_SetTextureAlphaMod(tgtBot, 232);
            SDL_RenderCopyF(ren, tgtBot, NULL, &db2);
            SDL_SetTextureAlphaMod(tgtBot, 255);
            SDL_SetTextureBlendMode(tgtBot, SDL_BLENDMODE_NONE);
        }
        SDL_ShowCursor(cinema_controls_visible() ? 1 : 0);
    } else {
    SDL_ShowCursor(1);
    float spread = 10.0f * lyS / 2.0f;
    win_shadow(lyTopX, lyTopY, tw, th, spread);
    win_shadow(lyBotX, lyBotY, bw, bh, spread);
    SDL_FRect dt_ = { lyTopX, lyTopY, tw, th }, db_ = { lyBotX, lyBotY, bw, bh };
    SDL_SetTextureBlendMode(tgtTop, SDL_BLENDMODE_NONE);
    SDL_SetTextureBlendMode(tgtBot, SDL_BLENDMODE_NONE);
    SDL_RenderCopyF(ren, tgtTop, NULL, &dt_);
    SDL_RenderCopyF(ren, tgtBot, NULL, &db_);
    if (fadeAmt > 0.001f) {
        int a = (int)(fminf(fadeAmt, 1.0f) * 255);
        win_rect(dt_.x, dt_.y, dt_.w, dt_.h, C2D_Color32(0, 0, 0, a));
        win_rect(db_.x, db_.y, db_.w, db_.h, C2D_Color32(0, 0, 0, a));
    }
    }

    if (screenshotPending) {
        screenshotPending = false;
        ui_screenshot(screenshotPath);
    }
    SDL_RenderPresent(ren);
    if (!noLimiter) {   /* sin vsync (o con la ventana oculta) no dejamos que el loop gire en vacio */
        Uint64 spent = SDL_GetTicks64() - frameStart;
        if (spent < 4) SDL_Delay(16 - (Uint32)spent);
    }
}

void ui_request_screenshot(const char *path) {
    snprintf(screenshotPath, sizeof(screenshotPath), "%s", path);
    screenshotPending = true;
}

bool ui_screenshot(const char *path) {
    SDL_SetRenderTarget(ren, NULL);
    void *buf = malloc((size_t)outW * (size_t)outH * 4);
    if (!buf) return false;
    bool ok = SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_ABGR8888, buf, outW * 4) == 0 &&
              save_bmp(buf, outW, outH, path);
    free(buf);
    return ok;
}

static bool save_target(SDL_Texture *t, int w, int h, const char *path) {
    if (!t || !path) return true;
    SDL_SetRenderTarget(ren, t);
    void *buf = malloc((size_t)w * (size_t)h * 4);
    if (!buf) return false;
    bool ok = SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_ABGR8888, buf, w * 4) == 0 && save_bmp(buf, w, h, path);
    free(buf);
    SDL_SetRenderTarget(ren, NULL);
    return ok;
}

bool ui_save_screens(const char *topPath, const char *botPath) {
    bool a = save_target(tgtTop, TOP_W * T, TOP_H * T, topPath);
    bool b = save_target(tgtBot, BOT_W * T, BOT_H * T, botPath);
    return a && b;
}

/* ------------------------------------------------------------------ primitivas */
static const int QUAD_IDX[6] = { 0, 1, 2, 0, 2, 3 };

void ui_set_offset(float dx, float dy) { offX = dx; offY = dy; }
void ui_set_fade(float amount) { fadeAmt = amount; }

void ui_blend_add(bool on) {
    addBlend = on;
    SDL_SetRenderDrawBlendMode(ren, on ? SDL_BLENDMODE_ADD : SDL_BLENDMODE_BLEND);
}

void ui_clip(float x, float y, float w, float h) {
    SDL_Rect r = { (int)floorf(PX(x + offX)), (int)floorf(PX(y + offY)), (int)ceilf(PX(w)), (int)ceilf(PX(h)) };
    if (r.w < 0) r.w = 0;
    if (r.h < 0) r.h = 0;
    SDL_RenderSetClipRect(ren, &r);
}
void ui_clip_reset(void) { SDL_RenderSetClipRect(ren, NULL); }

void ui_rect(float x, float y, float w, float h, u32 color) {
    if (w <= 0 || h <= 0 || COLOR_A(color) == 0) return;
    SDL_FRect r = { PX(x + offX), PX(y + offY), PX(w), PX(h) };
    set_col(color);
    SDL_RenderFillRectF(ren, &r);
}

static void draw_fan(const SDL_FPoint *pts, int n, u32 color) {
    /* abanico alrededor de pts[0] (centro) */
    SDL_Vertex v[130];
    int idx[130 * 3];
    if (n > 129) n = 129;
    SDL_Color c = to_sdl(color);
    for (int i = 0; i < n; i++) { v[i].position = pts[i]; v[i].color = c; v[i].tex_coord = (SDL_FPoint){ 0, 0 }; }
    int ni = 0;
    for (int i = 1; i < n; i++) {
        idx[ni++] = 0; idx[ni++] = i; idx[ni++] = (i + 1 < n) ? i + 1 : 1;
    }
    SDL_RenderGeometry(ren, NULL, v, n, idx, ni);
}

void ui_circle(float cx, float cy, float r, u32 color) {
    if (r <= 0 || COLOR_A(color) == 0) return;
    int seg = (int)(r * (float)T * 0.9f) + 10;
    if (seg < 14) seg = 14;
    if (seg > 96) seg = 96;
    SDL_FPoint pts[100];
    float ox = PX(cx + offX), oy = PX(cy + offY), rr = PX(r);
    pts[0] = (SDL_FPoint){ ox, oy };
    for (int i = 0; i < seg; i++) {
        float a = (float)i * 2.0f * (float)M_PI / (float)seg;
        pts[i + 1] = (SDL_FPoint){ ox + cosf(a) * rr, oy + sinf(a) * rr };
    }
    draw_fan(pts, seg + 1, color);
}

void ui_rounded(float x, float y, float w, float h, float r, u32 color) {
    if (w <= 0 || h <= 0 || COLOR_A(color) == 0) return;
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    if (r < 0.5f) { ui_rect(x, y, w, h, color); return; }
    int cs = (int)(r * (float)T * 0.5f) + 4;
    if (cs > 14) cs = 14;
    SDL_FPoint pts[4 * 16 + 2];
    float X = PX(x + offX), Y = PX(y + offY), W = PX(w), H = PX(h), R = PX(r);
    int n = 0;
    pts[n++] = (SDL_FPoint){ X + W / 2, Y + H / 2 };
    const float cxs[4] = { X + W - R, X + W - R, X + R, X + R };
    const float cys[4] = { Y + R, Y + H - R, Y + H - R, Y + R };
    for (int c = 0; c < 4; c++) {
        float a0 = ((float)c * 90.0f - 90.0f) * (float)M_PI / 180.0f;
        for (int i = 0; i <= cs; i++) {
            float a = a0 + ((float)i / (float)cs) * (float)M_PI / 2.0f;
            pts[n++] = (SDL_FPoint){ cxs[c] + cosf(a) * R, cys[c] + sinf(a) * R };
        }
    }
    draw_fan(pts, n, color);
}

void ui_triangle(float x0, float y0, float x1, float y1, float x2, float y2, u32 color) {
    SDL_Vertex v[3];
    SDL_Color c = to_sdl(color);
    v[0].position = (SDL_FPoint){ PX(x0 + offX), PX(y0 + offY) };
    v[1].position = (SDL_FPoint){ PX(x1 + offX), PX(y1 + offY) };
    v[2].position = (SDL_FPoint){ PX(x2 + offX), PX(y2 + offY) };
    for (int i = 0; i < 3; i++) { v[i].color = c; v[i].tex_coord = (SDL_FPoint){ 0, 0 }; }
    static const int tri[3] = { 0, 1, 2 };
    SDL_RenderGeometry(ren, NULL, v, 3, tri, 3);
}

void ui_quad(const float *xy, u32 c0, u32 c1, u32 c2, u32 c3) {
    SDL_Vertex v[4];
    u32 cs[4] = { c0, c1, c2, c3 };
    for (int i = 0; i < 4; i++) {
        v[i].position = (SDL_FPoint){ PX(xy[i * 2] + offX), PX(xy[i * 2 + 1] + offY) };
        v[i].color = to_sdl(cs[i]);
        v[i].tex_coord = (SDL_FPoint){ 0, 0 };
    }
    SDL_RenderGeometry(ren, NULL, v, 4, QUAD_IDX, 6);
}

void ui_gradient(float x, float y, float w, float h, u32 top, u32 bottom) {
    float q[8] = { x, y, x + w, y, x + w, y + h, x, y + h };
    ui_quad(q, top, top, bottom, bottom);
}
void ui_gradient_h(float x, float y, float w, float h, u32 left, u32 right) {
    float q[8] = { x, y, x + w, y, x + w, y + h, x, y + h };
    ui_quad(q, left, right, right, left);
}

void ui_line(float x0, float y0, float x1, float y1, float thick, u32 color) {
    float dx = x1 - x0, dy = y1 - y0;
    float len = sqrtf(dx * dx + dy * dy);
    if (len < 0.001f) { ui_circle(x0, y0, thick / 2, color); return; }
    float nx = -dy / len * thick / 2, ny = dx / len * thick / 2;
    float q[8] = { x0 + nx, y0 + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny };
    ui_quad(q, color, color, color, color);
}

void ui_ring(float cx, float cy, float r, float thick, u32 color) {
    int seg = (int)(r * (float)T * 0.9f) + 12;
    if (seg < 16) seg = 16;
    if (seg > 90) seg = 90;
    SDL_Vertex v[2 * 91];
    int idx[6 * 90];
    SDL_Color c = to_sdl(color);
    float ro = PX(r), ri = PX(r - thick), ox = PX(cx + offX), oy = PX(cy + offY);
    for (int i = 0; i <= seg; i++) {
        float a = (float)i * 2.0f * (float)M_PI / (float)seg;
        v[2 * i].position = (SDL_FPoint){ ox + cosf(a) * ro, oy + sinf(a) * ro };
        v[2 * i + 1].position = (SDL_FPoint){ ox + cosf(a) * ri, oy + sinf(a) * ri };
        v[2 * i].color = v[2 * i + 1].color = c;
        v[2 * i].tex_coord = v[2 * i + 1].tex_coord = (SDL_FPoint){ 0, 0 };
    }
    int ni = 0;
    for (int i = 0; i < seg; i++) {
        int a = 2 * i, b = 2 * i + 1, c2 = 2 * i + 2, d = 2 * i + 3;
        idx[ni++] = a; idx[ni++] = b; idx[ni++] = c2;
        idx[ni++] = b; idx[ni++] = d; idx[ni++] = c2;
    }
    SDL_RenderGeometry(ren, NULL, v, 2 * (seg + 1), idx, ni);
}

void ui_shadow(float x, float y, float w, float h, float r, float spread, int alpha) {
    const int layers = 6;
    for (int i = layers; i >= 1; i--) {
        float g = spread * (float)i / (float)layers;
        int a = alpha / layers;
        ui_rounded(x - g, y - g + spread * 0.4f, w + 2 * g, h + 2 * g, r + g, C2D_Color32(0, 0, 0, a));
    }
}

/* ------------------------------------------------------------------ imagenes */
C2D_Image ui_texture_from_rgba(const u8 *rgba, int w, int h, bool linear) {
    C2D_Image none = { NULL, 0, 0 };
    SDL_Texture *t = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, w, h);
    if (!t) return none;
    SDL_UpdateTexture(t, NULL, rgba, w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    SDL_SetTextureScaleMode(t, linear ? SDL_ScaleModeLinear : SDL_ScaleModeNearest);
    C2D_Image img = { t, w, h };
    return img;
}

C2D_Image ui_texture_streaming(int w, int h) {
    C2D_Image none = { NULL, 0, 0 };
    SDL_Texture *t = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, w, h);
    if (!t) return none;
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_NONE);
    SDL_SetTextureScaleMode(t, SDL_ScaleModeLinear);
    C2D_Image img = { t, w, h };
    return img;
}

void ui_texture_update(C2D_Image img, const void *rgba, int pitch) {
    if (img.tex) SDL_UpdateTexture((SDL_Texture *)img.tex, NULL, rgba, pitch);
}

void ui_texture_destroy(C2D_Image *img) {
    if (img && img->tex) SDL_DestroyTexture((SDL_Texture *)img->tex);
    if (img) { img->tex = NULL; img->w = img->h = 0; }
}

void ui_image_ex(C2D_Image img, float sx, float sy, float sw, float sh,
                 float dx, float dy, float dw, float dh, float rotDeg, bool flipX, bool flipY, u32 tint) {
    if (!img.tex) return;
    SDL_Texture *t = (SDL_Texture *)img.tex;
    SDL_Rect src = { (int)sx, (int)sy, (int)sw, (int)sh };
    SDL_FRect dst = { PX(dx + offX), PX(dy + offY), PX(dw), PX(dh) };
    SDL_SetTextureColorMod(t, (Uint8)COLOR_R(tint), (Uint8)COLOR_G(tint), (Uint8)COLOR_B(tint));
    SDL_SetTextureAlphaMod(t, (Uint8)COLOR_A(tint));
    int flip = (flipX ? SDL_FLIP_HORIZONTAL : 0) | (flipY ? SDL_FLIP_VERTICAL : 0);
    SDL_RenderCopyExF(ren, t, &src, &dst, (double)rotDeg, NULL, (SDL_RendererFlip)flip);
    SDL_SetTextureColorMod(t, 255, 255, 255);
    SDL_SetTextureAlphaMod(t, 255);
}

void ui_image_tint(C2D_Image img, float x, float y, float w, float h, u32 color) {
    ui_image_ex(img, 0, 0, (float)img.w, (float)img.h, x, y, w, h, 0, false, false, color);
}

void ui_image(C2D_Image img, float x, float y, float w, float h) {
    ui_image_tint(img, x, y, w, h, C2D_Color32(255, 255, 255, 255));
}

/* ------------------------------------------------------------------ animacion */
float ui_smooth(float *v, float target, float speed) {
    float k = 1.0f - expf(-speed * dtSec);
    *v += (target - *v) * k;
    if (fabsf(target - *v) < 0.01f) *v = target;
    return *v;
}
float ui_ease_out(float t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); float u = 1 - t; return 1 - u * u * u; }
float ui_ease_in_out(float t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }
float ui_lerpf(float a, float b, float t) { return a + (b - a) * t; }
u32 ui_color_mix(u32 a, u32 b, float t) {
    if (t < 0) t = 0;
    if (t > 1) t = 1;
    return C2D_Color32((int)ui_lerpf((float)COLOR_R(a), (float)COLOR_R(b), t), (int)ui_lerpf((float)COLOR_G(a), (float)COLOR_G(b), t),
                       (int)ui_lerpf((float)COLOR_B(a), (float)COLOR_B(b), t), (int)ui_lerpf((float)COLOR_A(a), (float)COLOR_A(b), t));
}
u32 ui_color_alpha(u32 c, float a) {
    if (a < 0) a = 0;
    if (a > 1) a = 1;
    return C2D_Color32(COLOR_R(c), COLOR_G(c), COLOR_B(c), (int)((float)COLOR_A(c) * a));
}

/* ------------------------------------------------------------------ texto */
static void draw_text_str(float x, float y, float scale, u32 color, const char *str) {
    if (!str || !str[0] || COLOR_A(color) == 0) return;
    TextEntry *e = text_entry(str, font_px(scale), font_bold(scale));
    if (!e || !e->tex) return;
    SDL_FRect dst = { floorf(PX(x + offX) + 0.5f), floorf(PX(y + offY) + 0.5f), (float)e->w, (float)e->h };
    SDL_SetTextureColorMod(e->tex, (Uint8)COLOR_R(color), (Uint8)COLOR_G(color), (Uint8)COLOR_B(color));
    SDL_SetTextureAlphaMod(e->tex, (Uint8)COLOR_A(color));
    SDL_RenderCopyF(ren, e->tex, NULL, &dst);
}

float ui_text_width(const char *str, float scale) {
    if (!str || !str[0]) return 0;
    return (float)measure_units(str, font_px(scale), font_bold(scale)) / 64.0f / (float)T;
}

void ui_text(float x, float y, float scale, u32 color, const char *fmt, ...) {
    char buf[512];
    const char *f = tr(fmt);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    draw_text_str(x, y, scale, color, buf);
}

void ui_text_center_raw(float cx, float y, float scale, u32 color, const char *str) {
    draw_text_str(cx - ui_text_width(str, scale) / 2, y, scale, color, str);
}
void ui_text_center(float cx, float y, float scale, u32 color, const char *str) { ui_text_center_raw(cx, y, scale, color, tr(str)); }
void ui_text_right_raw(float rightX, float y, float scale, u32 color, const char *str) {
    draw_text_str(rightX - ui_text_width(str, scale), y, scale, color, str);
}
void ui_text_right(float rightX, float y, float scale, u32 color, const char *str) { ui_text_right_raw(rightX, y, scale, color, tr(str)); }

void ui_text_clipped(float x, float y, float scale, u32 color, float maxWidth, const char *str) {
    char buf[MAX_NAME];
    snprintf(buf, sizeof(buf), "%s", str);   /* texto de datos del usuario: nunca se traduce */
    if (ui_text_width(buf, scale) <= maxWidth) { draw_text_str(x, y, scale, color, buf); return; }
    size_t len = strlen(buf);
    while (len > 1) {
        len--;
        if (((unsigned char)buf[len] & 0xC0) == 0x80) continue;   /* no cortar un caracter UTF-8 a la mitad */
        buf[len] = '\0';
        char tmp[MAX_NAME + 4];
        snprintf(tmp, sizeof(tmp), "%s...", buf);
        if (ui_text_width(tmp, scale) <= maxWidth) { draw_text_str(x, y, scale, color, tmp); return; }
    }
    draw_text_str(x, y, scale, color, "...");
}

/* ------------------------------------------------------------------ iconos */
void ui_icon_play(float cx, float cy, float s, u32 color) {
    ui_triangle(cx - s * 0.5f, cy - s, cx - s * 0.5f, cy + s, cx + s * 0.8f, cy, color);
}
void ui_icon_pause(float cx, float cy, float s, u32 color) {
    ui_rounded(cx - s * 0.7f, cy - s, s * 0.5f, s * 2, s * 0.12f, color);
    ui_rounded(cx + s * 0.2f, cy - s, s * 0.5f, s * 2, s * 0.12f, color);
}
void ui_icon_next(float cx, float cy, float s, u32 color) {
    ui_triangle(cx - s * 0.6f, cy - s, cx - s * 0.6f, cy + s, cx + s * 0.4f, cy, color);
    ui_rounded(cx + s * 0.4f, cy - s, s * 0.35f, s * 2, s * 0.1f, color);
}
void ui_icon_prev(float cx, float cy, float s, u32 color) {
    ui_rounded(cx - s * 0.75f, cy - s, s * 0.35f, s * 2, s * 0.1f, color);
    ui_triangle(cx + s * 0.6f, cy - s, cx + s * 0.6f, cy + s, cx - s * 0.4f, cy, color);
}
