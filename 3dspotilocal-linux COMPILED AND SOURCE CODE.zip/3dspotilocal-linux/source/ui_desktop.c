/* ui_desktop.c - interfaz unificada para escritorio. Todo se dibuja en un solo lienzo que ocupa la ventana. */
#include "ui_desktop.h"
#include "image.h"
#include "covers.h"
#include "library.h"
#include "settings.h"
#include "script.h"
#include "i18n.h"

bool g_classic_ui = false;

#define SIDE_W    196.0f
#define PLAYER_H  82.0f
#define PAD       32.0f

#define C_SURF   C2D_Color32(0x16, 0x16, 0x16, 0xFF)
#define C_SURF2  C2D_Color32(0x24, 0x24, 0x24, 0xFF)
#define C_SURF3  C2D_Color32(0x32, 0x32, 0x32, 0xFF)
#define C_LINE   C2D_Color32(255, 255, 255, 22)
#define C_WHITE  C2D_Color32(255, 255, 255, 255)

/* ------------------------------------------------------------------ estado de entrada / animacion */
static float mx, my;
static bool  mdown, mclick, mrel, mmoved, rclick, keyNav;
static int   wheelN;
static bool  uiLive = true;                 /* false mientras hay un dialogo encima: lo de abajo no recibe clics */
static float hov[512];
static float CW, CH;

static bool over(float x, float y, float w, float h) { return uiLive && mx >= x && mx < x + w && my >= y && my < y + h; }
static float hover(int id, bool o) { float *p = &hov[id & 511]; ui_smooth(p, o ? 1.0f : 0.0f, 18.0f); return *p; }
static float th(float scale) { return scale * 29.0f * 1.15f; }

typedef struct { float pos, target; } Scr;
static Scr scLib, scAlbum, scVideos, scGames, scSettings, scPicker, scCovers;

static void scr_reset(Scr *s) { s->pos = s->target = 0; }

static void scr_apply(Scr *s, float contentH, float viewH, bool active) {
    float maxS = contentH > viewH ? contentH - viewH : 0;
    if (active && wheelN) s->target -= (float)wheelN * 70.0f;
    if (s->target < 0) s->target = 0;
    if (s->target > maxS) s->target = maxS;
    ui_smooth(&s->pos, s->target, 16.0f);
    if (s->pos < 0) s->pos = 0;
    if (s->pos > maxS) s->pos = maxS;
}

static void scr_reveal(Scr *s, float top, float bot, float viewH) {
    if (top - 12 < s->target) s->target = top - 12;
    else if (bot + 12 > s->target + viewH) s->target = bot + 12 - viewH;
    if (s->target < 0) s->target = 0;
}

static void scrollbar(Scr *s, float x, float y, float h, float contentH, float viewH) {
    if (contentH <= viewH + 1) return;
    float maxS = contentH - viewH;
    float thumbH = fmaxf(36.0f, h * viewH / contentH);
    float ty = y + (h - thumbH) * (s->pos / maxS);
    bool o = over(x - 8, y, 18, h);
    float hv = hover((int)(x * 3 + y), o || (mdown && o));
    ui_rounded(x, ty, 6 + hv * 3, thumbH, 3, C2D_Color32(255, 255, 255, (int)(50 + hv * 90)));
    if (mdown && o) {
        float f = (my - y - thumbH / 2) / (h - thumbH);
        s->target = fminf(fmaxf(f, 0), 1) * maxS;
    }
}

/* ------------------------------------------------------------------ widgets */
static void text_c(float cx, float y, float sc, u32 c, const char *s) { ui_text_center(cx, y, sc, c, s); }

static bool pill(int id, float x, float y, float w, float h, const char *label, bool primary, float sc) {
    bool o = over(x, y, w, h);
    float hv = hover(id, o);
    u32 bg = primary ? ui_color_mix(COL_GREEN, C_WHITE, hv * 0.22f) : ui_color_mix(C_SURF3, C2D_Color32(0x55, 0x55, 0x55, 255), hv);
    if (hv > 0.01f) ui_shadow(x, y, w, h, h / 2, 5, (int)(80 * hv));
    ui_rounded(x, y, w, h, h / 2, bg);
    text_c(x + w / 2, y + (h - th(sc)) / 2 + 1, sc, primary ? COL_BLACK : C_WHITE, label);
    return mclick && o;
}

static void cover_art(const char *path, float x, float y, float s, const char *title) {
    C2D_Image im = image_get(path);
    if (im.tex) { ui_image(im, x, y, s, s); return; }
    ui_gradient(x, y, s, s, ui_color_mix(COL_GREEN_DK, C_SURF3, 0.35f), C_SURF2);
    char ini[8] = "♪";
    if (title && title[0] && (unsigned char)title[0] < 0x80) { ini[0] = title[0]; ini[1] = 0; }
    ui_text_center_raw(x + s / 2, y + s / 2 - th(s / 120.0f) / 2, s / 120.0f, C2D_Color32(255, 255, 255, 150), ini);
}

static void fmt_time(u64 ms, char *out, size_t n) {
    u64 s = ms / 1000;
    snprintf(out, n, "%u:%02u", (unsigned)(s / 60), (unsigned)(s % 60));
}

/* barra de progreso con arrastre. Devuelve 2 al soltar (usar *frac), 1 mientras se arrastra, 0 si no. */
static int seek_drag = -1;
static int seekbar(int id, float x, float y, float w, float frac, float *out, u32 col) {
    bool o = over(x - 4, y - 10, w + 8, 24);
    float hv = hover(id, o || seek_drag == id);
    int rc = 0;
    float f = frac;
    if (mclick && o) seek_drag = id;
    if (seek_drag == id) {
        f = fminf(fmaxf((mx - x) / w, 0), 1);
        rc = 1;
        if (mrel || !mdown) { rc = 2; seek_drag = -1; }
    }
    if (f < 0) f = 0;
    if (f > 1) f = 1;
    float bh = 4 + hv * 2;
    ui_rounded(x, y + 2 - hv, w, bh, bh / 2, C2D_Color32(255, 255, 255, 60));
    ui_rounded(x, y + 2 - hv, fmaxf(w * f, bh), bh, bh / 2, hv > 0.3f ? col : C_WHITE);
    if (hv > 0.02f) ui_circle(x + w * f, y + 4 - hv, 5.5f * hv + 0.5f, C_WHITE);
    *out = f;
    return rc;
}

/* ------------------------------------------------------------------ estado de la app (portadas, letras, toasts) */
static char playCoverPath[MAX_PATH];
static const Track *playCoverFor;

static const char *playing_cover(App *app) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) return "";
    if (playCoverFor != t) {
        playCoverFor = t;
        if (!covers_track_find(al, t, playCoverPath, sizeof(playCoverPath)))
            snprintf(playCoverPath, sizeof(playCoverPath), "%s", al->coverPath);
    }
    return playCoverPath;
}

static void sync_lyrics(App *app) {
    Track *t = player_current(&app->player);
    if (t == app->lyricsFor) return;
    app->lyricsFor = t;
    app->lyricsOffset = 0;
    app->showLyrics = false;
    lyrics_free();
    if (t && lyrics_load(t->path)) app->showLyrics = g_settings.lyricsAuto;
}

static double toastT0 = -100;
static char toastShown[MAX_NAME];
static void toast(App *app) {
    if (app->error[0] && strcmp(app->error, toastShown) != 0) { snprintf(toastShown, sizeof(toastShown), "%s", app->error); toastT0 = ui_time(); }
    if (!app->error[0]) { toastShown[0] = 0; return; }
    double age = ui_time() - toastT0;
    if (age > 3.6) { app->error[0] = 0; return; }
    float a = age < 0.25 ? (float)(age / 0.25) : (age > 3.2 ? (float)((3.6 - age) / 0.4) : 1.0f);
    float w = fminf(CW - 40, ui_text_width(app->error, 0.45f) + 48);
    float x = (CW - w) / 2, y = CH - (app->player.active ? PLAYER_H + 70 : 70) + (1 - a) * 14;
    ui_shadow(x, y, w, 40, 20, 8, (int)(120 * a));
    ui_rounded(x, y, w, 40, 20, ui_color_alpha(C2D_Color32(0x2e, 0x2e, 0x2e, 255), a));
    ui_text_center_raw(CW / 2, y + 9, 0.45f, ui_color_alpha(C_WHITE, a), app->error);
}

static void open_album(App *app, int i) {
    app->albumViewIdx = i;
    app->albumCursor = 0;
    app->screen = SCREEN_ALBUM;
    scr_reset(&scAlbum);
}

static void play_track(App *app, int album, int track) {
    if (!player_play_track(&app->player, album, track))
        snprintf(app->error, sizeof(app->error), "%s", tr("No se pudo abrir la cancion (o dura mas de 45 min)."));
    else playCoverFor = NULL;
}

static void start_game(App *app, GameKind kind, const char *song) {
    if (game_needs_song(kind) || !g_settings.gameMusic) player_stop(&app->player);
    if (game_start(kind, song)) {
        app->gameKind = kind;
        app->screen = SCREEN_GAME;
    } else {
        snprintf(app->error, sizeof(app->error), "%s",
                 tr(game_needs_song(kind) ? "No se pudo abrir la cancion (o dura mas de 45 min)." : "No se pudo iniciar el juego."));
    }
}

static int song_total(App *app) {
    int n = 0;
    for (int i = 0; i < app->lib->albumCount; i++) n += app->lib->albums[i].trackCount;
    return n;
}
static bool song_at(App *app, int idx, int *al, int *tr_) {
    for (int a = 0; a < app->lib->albumCount; a++) {
        if (idx < app->lib->albums[a].trackCount) { *al = a; *tr_ = idx; return true; }
        idx -= app->lib->albums[a].trackCount;
    }
    return false;
}

static void reload_library(App *app) {
    player_stop(&app->player);
    app_close_video(app);
    image_clear_all();
    lyrics_free();
    app->lyricsFor = NULL;
    playCoverFor = NULL;
    covers_init();
    library_scan(app->lib);
    script_rescan();
    app->libCursor = app->albumViewIdx = app->albumCursor = app->videoCursor = app->gameCursor = 0;
    scr_reset(&scLib); scr_reset(&scAlbum); scr_reset(&scVideos); scr_reset(&scGames);
    snprintf(app->error, sizeof(app->error), tr("Biblioteca: %d albumes, %d videos."), app->lib->albumCount, app->lib->videoCount);
}

/* ------------------------------------------------------------------ dialogos (selector de cancion y de caratula) */
static bool songPickOpen, coverPickOpen;
static GameKind songPickKind;
static int  songCur, coverCur;

/* ------------------------------------------------------------------ pantallas */
static int libCols = 4, gameCols = 3;

static void header(float x, float y, const char *title, const char *sub) {
    ui_text(x, y, 0.9f, C_WHITE, "%s", tr(title));
    if (sub && sub[0]) ui_text_clipped(x, y + 40, 0.42f, COL_SUBTEXT, 600, sub);
}

static void screen_library(App *app, float x, float y, float w, float h) {
    Library *lib = app->lib;
    int n = lib->albumCount;
    float cardW = 158, gapY = 20, cardH = cardW + 56, headH = 104;
    int cols = (int)((w - 2 * PAD + 20) / (cardW + 20));
    if (cols < 1) cols = 1;
    float gapX = cols > 1 ? (w - 2 * PAD - (float)cols * cardW) / (float)(cols - 1) : 0;
    if (gapX > 56) gapX = 56;
    libCols = cols;
    int rows = (n + cols - 1) / cols;
    float contentH = headH + (float)rows * (cardH + gapY) + PAD;
    bool in = over(x, y, w, h);
    if (n > 0 && keyNav) {
        int r = app->libCursor / cols;
        scr_reveal(&scLib, headH + (float)r * (cardH + gapY), headH + (float)r * (cardH + gapY) + cardH, h);
    }
    scr_apply(&scLib, contentH, h, in);
    ui_clip(x, y, w, h);
    float oy = y - scLib.pos;
    char sub[96];
    snprintf(sub, sizeof(sub), tr("%d albumes"), n);
    char sub2[48];
    snprintf(sub2, sizeof(sub2), tr("%d videos"), lib->videoCount);
    char both[160];
    snprintf(both, sizeof(both), "%s   ·   %s", sub, sub2);
    header(x + PAD, oy + 26, "Tu biblioteca", both);
    if (n == 0) {
        text_c(x + w / 2, y + h / 2 - 30, 0.6f, C_WHITE, "Todavia no hay albumes");
        text_c(x + w / 2, y + h / 2 + 12, 0.42f, COL_SUBTEXT, "Primero pone musica en ~/3dSpotiLocal/Music.");
    }
    for (int i = 0; i < n; i++) {
        int c = i % cols, r = i / cols;
        float cx = x + PAD + (float)c * (cardW + gapX), cy = oy + headH + (float)r * (cardH + gapY);
        if (cy > y + h || cy + cardH < y) continue;
        Album *al = &lib->albums[i];
        bool o = over(cx, cy, cardW, cardH) && over(x, y, w, h);
        float hv = hover(100 + i % 300, o);
        bool sel = keyNav && i == app->libCursor;
        float lift = hv * 4;
        if (sel) ui_rounded(cx - 4, cy - lift - 4, cardW + 8, cardW + 8, 8, COL_GREEN);
        ui_shadow(cx, cy - lift, cardW, cardW, 6, 7 + hv * 7, 80);
        cover_art(al->coverPath, cx, cy - lift, cardW, al->title);
        float pbx = cx + cardW - 30, pby = cy - lift + cardW - 30 + (1 - hv) * 12;
        bool onPlay = o && (mx - pbx) * (mx - pbx) + (my - pby) * (my - pby) < 22 * 22;
        if (hv > 0.02f) {
            ui_shadow(pbx - 20, pby - 20, 40, 40, 20, 4, (int)(90 * hv));
            ui_circle(pbx, pby, 20 + (onPlay ? 2 : 0), ui_color_alpha(COL_GREEN, hv));
            ui_icon_play(pbx, pby, 8, ui_color_alpha(COL_BLACK, hv));
        }
        ui_text_clipped(cx, cy + cardW + 8, 0.44f, C_WHITE, cardW, al->title);
        ui_text_clipped(cx, cy + cardW + 8 + th(0.44f) + 1, 0.35f, COL_SUBTEXT, cardW, al->artist);
        if (mclick && o) {
            if (onPlay) play_track(app, i, 0);
            else open_album(app, i);
        }
    }
    ui_clip_reset();
    scrollbar(&scLib, x + w - 12, y + 6, h - 12, contentH, h);
}

static void screen_album(App *app, float x, float y, float w, float h) {
    Library *lib = app->lib;
    if (app->albumViewIdx < 0 || app->albumViewIdx >= lib->albumCount) { app->screen = SCREEN_LIBRARY; return; }
    Album *al = &lib->albums[app->albumViewIdx];
    float rowH = 50, headH = 268;
    float contentH = headH + (float)al->trackCount * rowH + PAD;
    bool in = over(x, y, w, h);
    if (keyNav) scr_reveal(&scAlbum, headH + (float)app->albumCursor * rowH, headH + (float)(app->albumCursor + 1) * rowH, h);
    scr_apply(&scAlbum, contentH, h, in);
    ui_clip(x, y, w, h);
    float oy = y - scAlbum.pos;
    /* volver */
    {
        float bx = x + PAD - 6, by = oy + 14, bw = ui_text_width("< Biblioteca", 0.44f) + 24;
        bool o = over(bx, by, bw, 30);
        float hv = hover(40, o);
        ui_rounded(bx, by, bw, 30, 15, ui_color_alpha(C_WHITE, 0.07f * hv));
        ui_text(bx + 12, by + 5, 0.44f, ui_color_mix(COL_SUBTEXT, C_WHITE, hv), "< Biblioteca");
        if (mclick && o) app->screen = SCREEN_LIBRARY;
    }
    float cs = 180, cx = x + PAD, cy = oy + 62;
    ui_shadow(cx, cy, cs, cs, 6, 12, 90);
    cover_art(al->coverPath, cx, cy, cs, al->title);
    float tx = cx + cs + 30, tw = x + w - PAD - tx;
    ui_text_clipped(tx, cy + 10, 0.95f, C_WHITE, tw, al->title);
    ui_text_clipped(tx, cy + 62, 0.55f, COL_SUBTEXT, tw, al->artist);
    char cnt[64];
    snprintf(cnt, sizeof(cnt), tr(al->trackCount == 1 ? "%d cancion" : "%d canciones"), al->trackCount);
    ui_text_clipped(tx, cy + 96, 0.4f, COL_SUBTEXT, tw, cnt);
    if (pill(41, tx, cy + cs - 44, 156, 44, "Reproducir", true, 0.5f) && al->trackCount > 0) play_track(app, app->albumViewIdx, 0);
    if (pill(42, tx + 170, cy + cs - 44, 210, 44, "Cambiar caratula", false, 0.42f)) { coverPickOpen = true; coverCur = 0; scr_reset(&scCovers); }
    /* pistas */
    Track *now = player_current(&app->player);
    for (int i = 0; i < al->trackCount; i++) {
        float ry = oy + headH + (float)i * rowH;
        if (ry > y + h || ry + rowH < y) continue;
        bool o = over(x + PAD - 10, ry, w - 2 * PAD + 20, rowH - 4) && over(x, y, w, h);
        float hv = hover(200 + i % 300, o);
        bool playing = now == &al->tracks[i];
        bool sel = keyNav && i == app->albumCursor;
        if (hv > 0.01f || sel) ui_rounded(x + PAD - 10, ry, w - 2 * PAD + 20, rowH - 4, 8, sel ? C_SURF3 : ui_color_alpha(C_WHITE, 0.07f * hv));
        if (playing) {   /* ecualizador animado */
            float t = (float)ui_time();
            for (int b = 0; b < 3; b++) {
                float bh = 6 + 8 * (0.5f + 0.5f * sinf(t * 7 + (float)b * 1.9f));
                if (audio_out_is_paused()) bh = 8;
                ui_rect(x + PAD + 4 + (float)b * 5, ry + 25 - bh / 2 + 4, 3, bh, COL_GREEN);
            }
        } else {
            char nb[12];
            snprintf(nb, sizeof(nb), "%d", i + 1);
            ui_text_right_raw(x + PAD + 26, ry + 12, 0.42f, hv > 0.3f ? C_WHITE : COL_SUBTEXT, nb);
        }
        ui_text_clipped(x + PAD + 46, ry + 11, 0.47f, playing ? COL_GREEN : C_WHITE, w - 2 * PAD - 60, al->tracks[i].title);
        if (mclick && o) { app->albumCursor = i; play_track(app, app->albumViewIdx, i); }
    }
    ui_clip_reset();
    scrollbar(&scAlbum, x + w - 12, y + 6, h - 12, contentH, h);
}

static void draw_lyrics_panel(App *app, Track *t, float x, float y, float w, float h) {
    (void)t;
    int n = lyrics_count();
    u64 pos = player_position_ms(&app->player), dur = player_duration_ms(&app->player);
    int cur = lyrics_current(pos, dur, app->lyricsOffset);
    static float lp = 0;
    if (lp < 0.5f && cur > 3) lp = (float)cur;
    ui_smooth(&lp, (float)cur, 7.0f);
    float lineH = 38;
    ui_clip(x, y, w, h);
    for (int i = 0; i < n; i++) {
        float ly = y + h / 2 - lineH / 2 + ((float)i - lp) * lineH;
        if (ly < y - lineH || ly > y + h) continue;
        const LyricLine *ln = lyrics_line(i);
        float d = fabsf((float)i - lp);
        float a = d < 0.5f ? 1.0f : fmaxf(0.18f, 0.65f - d * 0.16f);
        bool isCur = i == cur;
        u32 c = isCur ? COL_GREEN : ui_color_alpha(C_WHITE, a);
        ui_text_clipped(x, ly, isCur ? 0.66f : 0.5f, c, w, ln->text);
    }
    ui_clip_reset();
    if (!lyrics_timed()) ui_text(x, y + h + 4, 0.34f, COL_SUBTEXT, "Letra sin tiempos: cruceta arriba/abajo para ajustar");
}

static void screen_playing(App *app, float x, float y, float w, float h) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) { app->screen = SCREEN_LIBRARY; return; }
    sync_lyrics(app);
    {
        float bx = x + PAD - 6, by = y + 14, bw = ui_text_width("< Biblioteca", 0.44f) + 24;
        bool o = over(bx, by, bw, 30);
        float hv = hover(50, o);
        ui_rounded(bx, by, bw, 30, 15, ui_color_alpha(C_WHITE, 0.07f * hv));
        ui_text(bx + 12, by + 5, 0.44f, ui_color_mix(COL_SUBTEXT, C_WHITE, hv), "< Biblioteca");
        if (mclick && o) app->screen = SCREEN_LIBRARY;
    }
    float ctlH = 170;
    float cs = fminf(h - ctlH - 70, w * 0.40f);
    if (cs < 140) cs = 140;
    if (cs > 440) cs = 440;
    float cx = x + PAD + 14, cy = y + 56 + (h - ctlH - 56 - cs) / 2;
    if (cy < y + 52) cy = y + 52;
    ui_shadow(cx, cy, cs, cs, 6, 16, 100);
    cover_art(playing_cover(app), cx, cy, cs, al->title);
    float rx = cx + cs + 48, rw = x + w - PAD - rx;
    bool hasLy = lyrics_count() > 0;
    if (app->showLyrics && hasLy) {
        draw_lyrics_panel(app, t, rx, cy, rw, cs - 10);
    } else {
        ui_text_clipped(rx, cy + 10, 1.0f, C_WHITE, rw, t->title);
        ui_text_clipped(rx, cy + 70, 0.6f, COL_SUBTEXT, rw, al->artist);
        ui_text_clipped(rx, cy + 108, 0.46f, COL_SUBTEXT, rw, al->title);
        ui_text(rx, cy + 156, 0.42f, audio_out_is_paused() ? COL_SUBTEXT : COL_GREEN, audio_out_is_paused() ? "Pausa" : "Reproduciendo");
    }
    if (hasLy && pill(51, rx, cy + cs - 44, 110, 40, "Letra", app->showLyrics, 0.44f)) app->showLyrics = !app->showLyrics;

    /* progreso + controles */
    u64 pos = player_position_ms(&app->player), dur = player_duration_ms(&app->player);
    float bx = x + PAD + 14, bw = w - 2 * PAD - 28, by = y + h - 118;
    float frac = dur ? (float)pos / (float)dur : 0, f2;
    static float shown = 0;
    if (fabsf(frac - shown) > 0.4f) shown = frac;
    ui_smooth(&shown, frac, 16.0f);
    int sk = seekbar(52, bx, by, bw, shown, &f2, COL_GREEN);
    if (sk == 2) { player_seek_ms(&app->player, (u64)(f2 * (float)dur)); shown = f2; }
    char tb[16];
    fmt_time(sk == 1 ? (u64)(f2 * (float)dur) : pos, tb, sizeof(tb));
    ui_text(bx, by + 16, 0.36f, COL_SUBTEXT, "%s", tb);
    fmt_time(dur, tb, sizeof(tb));
    ui_text_right_raw(bx + bw, by + 16, 0.36f, COL_SUBTEXT, tb);

    float cyc = y + h - 52, mid = x + w / 2;
    {   /* shuffle / repeat */
        float sx = mid - 150, rx2 = mid + 150;
        bool o1 = over(sx - 44, cyc - 16, 88, 32), o2 = over(rx2 - 44, cyc - 16, 88, 32);
        ui_text_center_raw(sx, cyc - 9, 0.38f, app->player.shuffle ? COL_GREEN : ui_color_mix(COL_SUBTEXT, C_WHITE, hover(53, o1)), "SHUFFLE");
        if (mclick && o1) app->player.shuffle = !app->player.shuffle;
        const char *rep = app->player.repeat == REPEAT_ONE ? "REPEAT 1" : "REPEAT";
        ui_text_center_raw(rx2, cyc - 9, 0.38f, app->player.repeat != REPEAT_OFF ? COL_GREEN : ui_color_mix(COL_SUBTEXT, C_WHITE, hover(54, o2)), rep);
        if (mclick && o2) app->player.repeat = (RepeatMode)((app->player.repeat + 1) % 3);
    }
    {   /* prev / play / next */
        bool op = over(mid - 74, cyc - 22, 44, 44), on = over(mid + 30, cyc - 22, 44, 44);
        bool ol = over(mid - 28, cyc - 28, 56, 56);
        ui_icon_prev(mid - 52, cyc, 11, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(55, op)));
        float hv = hover(56, ol);
        ui_shadow(mid - 28, cyc - 28, 56, 56, 28, 6, (int)(60 + 60 * hv));
        ui_circle(mid, cyc, 28 + hv * 2, ui_color_mix(COL_GREEN, C_WHITE, hv * 0.2f));
        if (audio_out_is_paused()) ui_icon_play(mid + 1, cyc, 13, COL_BLACK); else ui_icon_pause(mid, cyc, 13, COL_BLACK);
        ui_icon_next(mid + 52, cyc, 11, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(57, on)));
        if (mclick && op) player_prev(&app->player);
        if (mclick && ol) player_toggle_pause(&app->player);
        if (mclick && on) player_next(&app->player);
    }
}

static void screen_videos(App *app, float x, float y, float w, float h) {
    Library *lib = app->lib;
    int n = lib->videoCount;
    float rowH = 62, headH = 104;
    float contentH = headH + (float)n * rowH + PAD;
    if (keyNav && n) scr_reveal(&scVideos, headH + (float)app->videoCursor * rowH, headH + (float)(app->videoCursor + 1) * rowH, h);
    scr_apply(&scVideos, contentH, h, over(x, y, w, h));
    ui_clip(x, y, w, h);
    float oy = y - scVideos.pos;
    char sub[64];
    snprintf(sub, sizeof(sub), tr("%d videos"), n);
    header(x + PAD, oy + 26, "Videos", sub);
    if (n == 0) {
        text_c(x + w / 2, y + h / 2 - 50, 0.6f, C_WHITE, "No hay videos (mp4, mkv, avi...)");
        text_c(x + w / 2, y + h / 2 - 6, 0.42f, COL_SUBTEXT, "Formatos: mp4, mkv, webm, avi, mov...");
        text_c(x + w / 2, y + h / 2 + 22, 0.42f, COL_SUBTEXT, "Necesita ffmpeg instalado en el sistema");
        text_c(x + w / 2, y + h / 2 + 56, 0.4f, COL_GREEN, "~/3dSpotiLocal/Videos/");
    }
    for (int i = 0; i < n; i++) {
        float ry = oy + headH + (float)i * rowH;
        if (ry > y + h || ry + rowH < y) continue;
        bool o = over(x + PAD - 10, ry, w - 2 * PAD + 20, rowH - 6) && over(x, y, w, h);
        float hv = hover(300 + i % 200, o);
        bool sel = keyNav && i == app->videoCursor;
        ui_rounded(x + PAD - 10, ry, w - 2 * PAD + 20, rowH - 6, 10, sel ? C_SURF3 : ui_color_mix(C_SURF, C_SURF3, hv));
        ui_circle(x + PAD + 24, ry + (rowH - 6) / 2, 19, ui_color_mix(C_SURF3, COL_GREEN, hv));
        ui_icon_play(x + PAD + 25, ry + (rowH - 6) / 2, 7, ui_color_mix(C_WHITE, COL_BLACK, hv));
        ui_text_clipped(x + PAD + 62, ry + (rowH - 6) / 2 - th(0.5f) / 2, 0.5f, C_WHITE, w - 2 * PAD - 80, lib->videos[i].title);
        if (mclick && o) { app->videoCursor = i; app_open_video(app, i); }
    }
    ui_clip_reset();
    scrollbar(&scVideos, x + w - 12, y + 6, h - 12, contentH, h);
}

static void screen_games(App *app, float x, float y, float w, float h) {
    int n = game_total();
    float cardW = 262, cardH = 118, gap = 18, headH = 104;
    int cols = (int)((w - 2 * PAD + gap) / (cardW + gap));
    if (cols < 1) cols = 1;
    float cw2 = (w - 2 * PAD - (float)(cols - 1) * gap) / (float)cols;
    if (cw2 > 340) cw2 = 340;
    gameCols = cols;
    int rows = (n + cols - 1) / cols;
    float contentH = headH + (float)rows * (cardH + gap) + PAD;
    if (keyNav) {
        int r = app->gameCursor / cols;
        scr_reveal(&scGames, headH + (float)r * (cardH + gap), headH + (float)r * (cardH + gap) + cardH, h);
    }
    scr_apply(&scGames, contentH, h, over(x, y, w, h));
    ui_clip(x, y, w, h);
    float oy = y - scGames.pos;
    header(x + PAD, oy + 26, "Minijuegos", NULL);
    for (int i = 0; i < n; i++) {
        int c = i % cols, r = i / cols;
        float cx = x + PAD + (float)c * (cw2 + gap), cy = oy + headH + (float)r * (cardH + gap);
        if (cy > y + h || cy + cardH < y) continue;
        GameKind k = (GameKind)i;
        bool o = over(cx, cy, cw2, cardH) && over(x, y, w, h);
        float hv = hover(520 - 1 - (i % 200), o);
        bool sel = keyNav && i == app->gameCursor;
        float lift = hv * 3;
        ui_shadow(cx, cy - lift, cw2, cardH, 12, 6 + hv * 6, 100);
        ui_rounded(cx, cy - lift, cw2, cardH, 12, sel ? C_SURF3 : ui_color_mix(C_SURF2, C_SURF3, hv));
        ui_rounded(cx, cy - lift, 5, cardH, 2.5f, i >= GAME_COUNT ? C2D_Color32(0x7a, 0xa8, 0xff, 255) : COL_GREEN);
        ui_text_clipped(cx + 20, cy - lift + 14, 0.55f, C_WHITE, cw2 - 36, game_title(k));
        ui_text_clipped(cx + 20, cy - lift + 14 + th(0.55f) + 2, 0.36f, COL_SUBTEXT, cw2 - 36, game_description(k));
        const char *tag = i >= GAME_COUNT ? "Tu juego en Lua" : (game_needs_song(k) ? "Con una cancion tuya" : NULL);
        if (tag) ui_text(cx + 20, cy - lift + cardH - 30, 0.36f, COL_GREEN, "%s", tag);
        int best = settings_best(i);
        if (best > 0 && i < GAME_COUNT) {
            char b[40];
            snprintf(b, sizeof(b), tr("Tu record: %d"), best);
            ui_text_right_raw(cx + cw2 - 16, cy - lift + cardH - 30, 0.36f, COL_SUBTEXT, b);
        }
        if (mclick && o) {
            app->gameCursor = i;
            if (!game_needs_song(k)) start_game(app, k, NULL);
            else if (song_total(app) == 0) snprintf(app->error, sizeof(app->error), "%s", tr("Primero pone musica en ~/3dSpotiLocal/Music."));
            else { songPickOpen = true; songPickKind = k; songCur = 0; scr_reset(&scPicker); }
        }
    }
    ui_clip_reset();
    scrollbar(&scGames, x + w - 12, y + 6, h - 12, contentH, h);
}

static void screen_settings(App *app, float x, float y, float w, float h) {
    int n = setting_count();
    float rowH = 64, headH = 104, colW = fminf(w - 2 * PAD, 760);
    float contentH = headH + (float)n * rowH + PAD;
    if (keyNav) scr_reveal(&scSettings, headH + (float)app->settingCursor * rowH, headH + (float)(app->settingCursor + 1) * rowH, h);
    scr_apply(&scSettings, contentH, h, over(x, y, w, h));
    ui_clip(x, y, w, h);
    float oy = y - scSettings.pos;
    header(x + PAD, oy + 26, "Ajustes", NULL);
    for (int i = 0; i < n; i++) {
        float ry = oy + headH + (float)i * rowH;
        if (ry > y + h || ry + rowH < y) continue;
        float rx = x + PAD - 10, rw = colW + 20;
        bool o = over(rx, ry, rw, rowH - 6) && over(x, y, w, h);
        float hv = hover(260 + i, o);
        bool sel = keyNav && i == app->settingCursor;
        ui_rounded(rx, ry, rw, rowH - 6, 10, sel ? C_SURF3 : ui_color_mix(C_SURF, C_SURF2, hv));
        ui_text(x + PAD + 6, ry + 9, 0.48f, C_WHITE, "%s", setting_name(i));
        if (hv > 0.5f || sel) ui_text_clipped(x + PAD + 6, ry + 9 + th(0.48f), 0.31f, COL_SUBTEXT, colW - 280, setting_help(i));
        SettingAction act = setting_action(i);
        if (act != ACT_NONE) {
            float bw = 150, bx = x + PAD + colW - bw;
            if (pill(700 + i, bx, ry + 8, bw, 38, setting_name(i), false, 0.4f) && o) { app->settingCursor = i; if (act == ACT_RELOAD) reload_library(app); else { settings_reset(); snprintf(app->error, sizeof(app->error), "%s", tr("Ajustes restaurados.")); } }
            continue;
        }
        char v[64];
        setting_value(i, v, sizeof(v));
        float vw = 190, vx = x + PAD + colW - vw;
        bool oL = over(vx, ry + 8, 34, 38), oR = over(vx + vw - 34, ry + 8, 34, 38);
        ui_rounded(vx, ry + 8, vw, 38, 19, C_SURF3);
        ui_text(vx + 12, ry + 14, 0.5f, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(560 + i, oL)), "<");
        ui_text(vx + vw - 22, ry + 14, 0.5f, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(600 + i, oR)), ">");
        ui_text_center_raw(vx + vw / 2, ry + 14, 0.44f, COL_GREEN, v);
        if (mclick && o) {
            app->settingCursor = i;
            setting_change(i, oL ? -1 : +1);
        }
    }
    ui_clip_reset();
    scrollbar(&scSettings, x + w - 12, y + 6, h - 12, contentH, h);
}

/* ------------------------------------------------------------------ dialogos */
static float dialog_dim(void) {
    ui_rect(0, 0, CW, CH, C2D_Color32(0, 0, 0, 170));
    return 1.0f;
}

static void song_picker(App *app) {
    int n = song_total(app);
    float pw = fminf(CW - 80, 640), ph = CH - 120, px = (CW - pw) / 2, py = 60;
    dialog_dim();
    ui_shadow(px, py, pw, ph, 14, 14, 160);
    ui_rounded(px, py, pw, ph, 14, C_SURF);
    ui_text(px + 24, py + 16, 0.65f, C_WHITE, "Elegi una cancion");
    ui_text(px + 24, py + 16 + th(0.65f), 0.34f, COL_SUBTEXT, "%s", game_title(songPickKind));
    float ly = py + 78, lh = ph - 92, rowH = 44;
    float contentH = (float)n * rowH;
    if (keyNav) scr_reveal(&scPicker, (float)songCur * rowH, (float)(songCur + 1) * rowH, lh);
    scr_apply(&scPicker, contentH, lh, over(px, ly, pw, lh));
    ui_clip(px, ly, pw, lh);
    for (int i = 0; i < n; i++) {
        float ry = ly + (float)i * rowH - scPicker.pos;
        if (ry > ly + lh || ry + rowH < ly) continue;
        int a, t;
        if (!song_at(app, i, &a, &t)) break;
        bool o = over(px + 10, ry, pw - 20, rowH - 4) && over(px, ly, pw, lh);
        float hv = hover(8 + i % 100, o);
        if (hv > 0.01f || (keyNav && i == songCur)) ui_rounded(px + 10, ry, pw - 20, rowH - 4, 8, (keyNav && i == songCur) ? C_SURF3 : ui_color_alpha(C_WHITE, 0.07f * hv));
        ui_text_clipped(px + 26, ry + 6, 0.46f, C_WHITE, pw - 60, app->lib->albums[a].tracks[t].title);
        ui_text_clipped(px + 26, ry + 6 + th(0.46f) - 2, 0.32f, COL_SUBTEXT, pw - 60, app->lib->albums[a].title);
        if (mclick && o) {
            songPickOpen = false;
            start_game(app, songPickKind, app->lib->albums[a].tracks[t].path);
        }
    }
    ui_clip_reset();
    scrollbar(&scPicker, px + pw - 14, ly, lh, contentH, lh);
    if (mclick && !over(px, py, pw, ph) && uiLive) songPickOpen = false;
}

static void cover_picker(App *app) {
    Album *al = &app->lib->albums[clampi(app->albumViewIdx, 0, app->lib->albumCount - 1)];
    int n = covers_image_count();
    float pw = fminf(CW - 80, 700), ph = CH - 120, px = (CW - pw) / 2, py = 60;
    dialog_dim();
    ui_shadow(px, py, pw, ph, 14, 14, 160);
    ui_rounded(px, py, pw, ph, 14, C_SURF);
    ui_text(px + 24, py + 16, 0.65f, C_WHITE, "Caratula del album");
    if (pill(900, px + pw - 24 - 230, py + 16, 230, 36, "Automatica (quitar la elegida)", false, 0.34f)) {
        covers_album_set(al, NULL);
        library_default_cover(al->folder, al->coverPath, MAX_PATH);
        snprintf(app->error, sizeof(app->error), "%s", tr("Caratula automatica restaurada."));
        coverPickOpen = false;
        return;
    }
    float gy = py + 70, gh = ph - 84, cell = 112, gap = 14;
    int cols = (int)((pw - 40 + gap) / (cell + gap));
    if (cols < 1) cols = 1;
    int rows = (n + cols - 1) / cols;
    float contentH = (float)rows * (cell + gap);
    scr_apply(&scCovers, contentH, gh, over(px, gy, pw, gh));
    ui_clip(px, gy, pw, gh);
    if (n == 0) ui_text_center_raw(px + pw / 2, gy + 40, 0.42f, COL_SUBTEXT, tr("No hay imagenes. Copia .jpg, .png o .bmp a ~/3dSpotiLocal/Covers/ y volve a abrir esta pantalla."));
    for (int i = 0; i < n; i++) {
        int c = i % cols, r = i / cols;
        float cx = px + 20 + (float)c * (cell + gap), cy = gy + (float)r * (cell + gap) - scCovers.pos;
        if (cy > gy + gh || cy + cell < gy) continue;
        bool o = over(cx, cy, cell, cell) && over(px, gy, pw, gh);
        float hv = hover(120 + i % 200, o);
        char path[MAX_PATH];
        covers_image_path(i, path, sizeof(path));
        if (hv > 0.02f) ui_rounded(cx - 4, cy - 4, cell + 8, cell + 8, 8, ui_color_alpha(COL_GREEN, hv));
        cover_art(path, cx, cy, cell, "");
        if (mclick && o) {
            covers_album_set(al, covers_image_name(i));
            char p2[MAX_PATH];
            if (covers_album_chosen(al, p2, sizeof(p2))) snprintf(al->coverPath, MAX_PATH, "%s", p2);
            snprintf(app->error, sizeof(app->error), "%s", tr("Caratula guardada."));
            coverPickOpen = false;
        }
    }
    ui_clip_reset();
    scrollbar(&scCovers, px + pw - 14, gy, gh, contentH, gh);
    if (mclick && !over(px, py, pw, ph) && uiLive) coverPickOpen = false;
}

/* ------------------------------------------------------------------ barra lateral y mini reproductor */
static const struct { Screen s; const char *label; } NAV[4] = {
    { SCREEN_LIBRARY, "Musica" }, { SCREEN_VIDEOS, "Videos" }, { SCREEN_GAMES, "Juegos" }, { SCREEN_SETTINGS, "Ajustes" } };

static int nav_active(const App *app) {
    switch (app->screen) {
        case SCREEN_LIBRARY: case SCREEN_ALBUM: case SCREEN_PLAYING: return 0;
        case SCREEN_VIDEOS: return 1;
        case SCREEN_GAMES: return 2;
        case SCREEN_SETTINGS: return 3;
        default: return 0;
    }
}

static void sidebar(App *app, float h) {
    ui_rect(0, 0, SIDE_W, h, C_SURF);
    ui_rect(SIDE_W - 1, 0, 1, h, C_LINE);
    ui_circle(34, 40, 11, COL_GREEN);
    ui_text_center_raw(34, 40 - th(0.4f) / 2, 0.4f, COL_BLACK, "♪");
    ui_text(54, 24, 0.62f, C_WHITE, "3dSpotiLocal");
    static float barY = -1;
    int act = nav_active(app);
    float ty = 92 + (float)act * 46;
    if (barY < 0) barY = ty;
    ui_smooth(&barY, ty, 16.0f);
    ui_rounded(12, barY, SIDE_W - 24, 40, 10, ui_color_alpha(C_WHITE, 0.09f));
    ui_rounded(12, barY + 9, 4, 22, 2, COL_GREEN);
    for (int i = 0; i < 4; i++) {
        float y = 92 + (float)i * 46;
        bool o = over(12, y, SIDE_W - 24, 40);
        float hv = hover(30 + i, o);
        if (hv > 0.01f && i != act) ui_rounded(12, y, SIDE_W - 24, 40, 10, ui_color_alpha(C_WHITE, 0.05f * hv));
        ui_text(34, y + 8, 0.5f, i == act ? C_WHITE : ui_color_mix(COL_SUBTEXT, C_WHITE, hv), "%s", NAV[i].label);
        if (mclick && o) {
            if (NAV[i].s != app->screen) app->screen = NAV[i].s;
        }
    }
}

static void miniplayer(App *app) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) return;
    float y0 = CH - PLAYER_H;
    ui_rect(0, y0, CW, PLAYER_H, C2D_Color32(0x1c, 0x1c, 0x1c, 255));
    ui_rect(0, y0, CW, 1, C_LINE);
    bool oInfo = over(0, y0, 340, PLAYER_H);
    float hvI = hover(70, oInfo);
    cover_art(playing_cover(app), 16, y0 + 13, 56, al->title);
    ui_text_clipped(86, y0 + 17, 0.46f, ui_color_mix(C_WHITE, COL_GREEN, hvI * 0.0f), 236, t->title);
    ui_text_clipped(86, y0 + 17 + th(0.46f), 0.36f, COL_SUBTEXT, 236, al->artist);
    if (mclick && oInfo) app->screen = SCREEN_PLAYING;

    float mid = CW / 2, cy = y0 + 26;
    bool op = over(mid - 76, cy - 20, 40, 40), on = over(mid + 36, cy - 20, 40, 40), ol = over(mid - 22, cy - 22, 44, 44);
    ui_icon_prev(mid - 56, cy, 9, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(71, op)));
    float hv = hover(72, ol);
    ui_circle(mid, cy, 19 + hv * 1.5f, ui_color_mix(C_WHITE, COL_GREEN, 0.0f + hv * 0.0f));
    if (audio_out_is_paused()) ui_icon_play(mid + 1, cy, 8, COL_BLACK); else ui_icon_pause(mid, cy, 8, COL_BLACK);
    ui_icon_next(mid + 56, cy, 9, ui_color_mix(COL_SUBTEXT, C_WHITE, hover(73, on)));
    if (mclick && op) player_prev(&app->player);
    if (mclick && ol) player_toggle_pause(&app->player);
    if (mclick && on) player_next(&app->player);

    u64 pos = player_position_ms(&app->player), dur = player_duration_ms(&app->player);
    float bw = fminf(520, CW * 0.42f), bx = mid - bw / 2, by = y0 + 58;
    static float shown = 0;
    float frac = dur ? (float)pos / (float)dur : 0, f2;
    if (fabsf(frac - shown) > 0.4f) shown = frac;
    ui_smooth(&shown, frac, 16.0f);
    int sk = seekbar(74, bx, by, bw, shown, &f2, COL_GREEN);
    if (sk == 2) { player_seek_ms(&app->player, (u64)(f2 * (float)dur)); shown = f2; }
    char tb[16];
    fmt_time(sk == 1 ? (u64)(f2 * (float)dur) : pos, tb, sizeof(tb));
    ui_text_right_raw(bx - 10, by - 3, 0.32f, COL_SUBTEXT, tb);
    fmt_time(dur, tb, sizeof(tb));
    ui_text(bx + bw + 10, by - 3, 0.32f, COL_SUBTEXT, "%s", tb);

    {   /* shuffle / repeat */
        float rx = CW - 24;
        const char *rep = app->player.repeat == REPEAT_ONE ? "REPEAT 1" : "REPEAT";
        float rw = ui_text_width(rep, 0.34f);
        bool o2 = over(rx - rw - 6, y0 + 20, rw + 12, 26);
        ui_text_right_raw(rx, y0 + 26, 0.34f, app->player.repeat != REPEAT_OFF ? COL_GREEN : ui_color_mix(COL_SUBTEXT, C_WHITE, hover(75, o2)), rep);
        if (mclick && o2) app->player.repeat = (RepeatMode)((app->player.repeat + 1) % 3);
        float sw = ui_text_width("SHUFFLE", 0.34f);
        float sx = rx - rw - 28 - sw;
        bool o1 = over(sx - 6, y0 + 20, sw + 12, 26);
        ui_text(sx, y0 + 26, 0.34f, app->player.shuffle ? COL_GREEN : ui_color_mix(COL_SUBTEXT, C_WHITE, hover(76, o1)), "SHUFFLE");
        if (mclick && o1) app->player.shuffle = !app->player.shuffle;
    }
}

/* ------------------------------------------------------------------ video (modo cine) */
static void cinema_hud(App *app) {
    if (!app->video) return;
    bool paused = video_is_paused(app->video);
    if (!(ui_cinema_controls_visible() || paused)) return;
    float a = 1.0f;
    ui_gradient(0, 0, CW, 90, C2D_Color32(0, 0, 0, (int)(170 * a)), C2D_Color32(0, 0, 0, 0));
    ui_gradient(0, CH - 150, CW, 150, C2D_Color32(0, 0, 0, 0), C2D_Color32(0, 0, 0, (int)(200 * a)));
    const char *title = app->lib->videos[clampi(app->videoIndex, 0, app->lib->videoCount - 1)].title;
    {
        float bw = ui_text_width("< Videos", 0.48f) + 26;
        bool o = over(18, 16, bw, 34);
        float hv = hover(80, o);
        ui_rounded(18, 16, bw, 34, 17, C2D_Color32(255, 255, 255, (int)(24 + 40 * hv)));
        ui_text(31, 22, 0.48f, C_WHITE, "< Videos");
        if (mclick && o) { app_close_video(app); app->screen = SCREEN_VIDEOS; return; }
    }
    ui_text_clipped(30 + ui_text_width("< Videos", 0.48f) + 30, 22, 0.52f, C_WHITE, CW - 260, title);
    u64 pos = video_position_ms(app->video), dur = video_duration_ms(app->video);
    float bx = 30, bw = CW - 60, by = CH - 70;
    float frac = dur ? (float)pos / (float)dur : 0, f2;
    int sk = seekbar(81, bx, by, bw, frac, &f2, COL_GREEN);
    if (sk == 2) video_seek(app->video, (u64)(f2 * (float)dur));
    char tb[16];
    fmt_time(sk == 1 ? (u64)(f2 * (float)dur) : pos, tb, sizeof(tb));
    ui_text(bx, by + 16, 0.38f, C_WHITE, "%s", tb);
    fmt_time(dur, tb, sizeof(tb));
    ui_text_right_raw(bx + bw, by + 16, 0.38f, C_WHITE, tb);
    float mid = CW / 2, cy = CH - 32;
    bool op = over(mid - 90, cy - 22, 50, 44), on = over(mid + 40, cy - 22, 50, 44), ol = over(mid - 26, cy - 26, 52, 52);
    ui_icon_prev(mid - 62, cy, 10, ui_color_mix(C2D_Color32(220, 220, 220, 255), C_WHITE, hover(82, op)));
    float hv = hover(83, ol);
    ui_circle(mid, cy, 24 + hv * 2, C_WHITE);
    if (paused) ui_icon_play(mid + 1, cy, 11, COL_BLACK); else ui_icon_pause(mid, cy, 11, COL_BLACK);
    ui_icon_next(mid + 62, cy, 10, ui_color_mix(C2D_Color32(220, 220, 220, 255), C_WHITE, hover(84, on)));
    if (mclick && op) video_seek(app->video, pos > 10000 ? pos - 10000 : 0);
    if (mclick && ol) video_pause(app->video, !paused);
    if (mclick && on) video_seek(app->video, pos + 10000);
    /* clic sobre el video (fuera de los controles) = pausa */
    if (mclick && !op && !on && !ol && my < CH - 90 && my > 60 && !(my > by - 12)) video_pause(app->video, !paused);
}

/* ------------------------------------------------------------------ teclado / gamepad */
static void section_step(App *app, int dir) {
    int a = nav_active(app);
    a = (a + dir + 4) % 4;
    app->screen = NAV[a].s;
}

static void desk_back(App *app) {
    if (songPickOpen) { songPickOpen = false; return; }
    if (coverPickOpen) { coverPickOpen = false; return; }
    switch (app->screen) {
        case SCREEN_ALBUM: app->screen = SCREEN_LIBRARY; break;
        case SCREEN_PLAYING: app->screen = SCREEN_LIBRARY; break;
        case SCREEN_VIDEO: app_close_video(app); app->screen = SCREEN_VIDEOS; break;
        default: app->screen = SCREEN_LIBRARY; break;
    }
}

static void grid_move(int *cur, int n, int cols, u32 down) {
    if (n <= 0) { *cur = 0; return; }
    if (down & KEY_LEFT)  *cur = clampi(*cur - 1, 0, n - 1);
    if (down & KEY_RIGHT) *cur = clampi(*cur + 1, 0, n - 1);
    if (down & KEY_UP)    *cur = clampi(*cur - cols, 0, n - 1);
    if (down & KEY_DOWN)  *cur = clampi(*cur + cols, 0, n - 1);
}

static void handle_keys(App *app, u32 down) {
    if (!down) return;
    keyNav = true;
    if (down & KEY_B) { desk_back(app); return; }
    if (songPickOpen) {
        int n = song_total(app);
        if (down & KEY_DOWN) songCur = clampi(songCur + 1, 0, n - 1);
        if (down & KEY_UP) songCur = clampi(songCur - 1, 0, n - 1);
        if (down & KEY_A) {
            int a, t;
            if (song_at(app, songCur, &a, &t)) { songPickOpen = false; start_game(app, songPickKind, app->lib->albums[a].tracks[t].path); }
        }
        return;
    }
    if (coverPickOpen) return;
    if ((down & KEY_START) && player_current(&app->player) && app->screen != SCREEN_VIDEO) { player_toggle_pause(&app->player); return; }
    switch (app->screen) {
        case SCREEN_LIBRARY: {
            grid_move(&app->libCursor, app->lib->albumCount, libCols, down);
            if ((down & KEY_A) && app->lib->albumCount > 0) open_album(app, clampi(app->libCursor, 0, app->lib->albumCount - 1));
            break;
        }
        case SCREEN_ALBUM: {
            if (app->albumViewIdx < 0 || app->albumViewIdx >= app->lib->albumCount) break;
            Album *al = &app->lib->albums[app->albumViewIdx];
            if (down & KEY_DOWN) app->albumCursor = clampi(app->albumCursor + 1, 0, al->trackCount - 1);
            if (down & KEY_UP) app->albumCursor = clampi(app->albumCursor - 1, 0, al->trackCount - 1);
            if ((down & KEY_A) && al->trackCount > 0) play_track(app, app->albumViewIdx, app->albumCursor);
            if (down & KEY_Y) { coverPickOpen = true; coverCur = 0; scr_reset(&scCovers); }
            break;
        }
        case SCREEN_PLAYING:
            if (down & KEY_A) player_toggle_pause(&app->player);
            if (down & KEY_RIGHT) player_next(&app->player);
            if (down & KEY_LEFT) player_prev(&app->player);
            if (down & KEY_R) player_seek_ms(&app->player, player_position_ms(&app->player) + 5000);
            if (down & KEY_L) { u64 p = player_position_ms(&app->player); player_seek_ms(&app->player, p > 5000 ? p - 5000 : 0); }
            if (down & KEY_X) { if (lyrics_count() > 0) app->showLyrics = !app->showLyrics; else app->player.shuffle = !app->player.shuffle; }
            if (down & KEY_Y) app->player.repeat = (RepeatMode)((app->player.repeat + 1) % 3);
            if (app->showLyrics && !lyrics_timed()) { if (down & KEY_UP) app->lyricsOffset--; if (down & KEY_DOWN) app->lyricsOffset++; }
            return;
        case SCREEN_VIDEOS: {
            int n = app->lib->videoCount;
            if (down & KEY_DOWN) app->videoCursor = clampi(app->videoCursor + 1, 0, n - 1);
            if (down & KEY_UP) app->videoCursor = clampi(app->videoCursor - 1, 0, n - 1);
            if ((down & KEY_A) && n > 0) app_open_video(app, clampi(app->videoCursor, 0, n - 1));
            break;
        }
        case SCREEN_VIDEO:
            if (!app->video) break;
            if ((down & KEY_A) || (down & KEY_START)) video_pause(app->video, !video_is_paused(app->video));
            if (down & KEY_RIGHT) video_seek(app->video, video_position_ms(app->video) + 5000);
            if (down & KEY_LEFT) { u64 p = video_position_ms(app->video); video_seek(app->video, p > 5000 ? p - 5000 : 0); }
            return;
        case SCREEN_GAMES: {
            int n = game_total();
            grid_move(&app->gameCursor, n, gameCols, down);
            if (down & KEY_A) {
                GameKind k = (GameKind)clampi(app->gameCursor, 0, n - 1);
                if (!game_needs_song(k)) start_game(app, k, NULL);
                else if (song_total(app) == 0) snprintf(app->error, sizeof(app->error), "%s", tr("Primero pone musica en ~/3dSpotiLocal/Music."));
                else { songPickOpen = true; songPickKind = k; songCur = 0; scr_reset(&scPicker); }
            }
            break;
        }
        case SCREEN_SETTINGS: {
            int n = setting_count();
            if (down & KEY_DOWN) app->settingCursor = clampi(app->settingCursor + 1, 0, n - 1);
            if (down & KEY_UP) app->settingCursor = clampi(app->settingCursor - 1, 0, n - 1);
            int i = clampi(app->settingCursor, 0, n - 1);
            SettingAction act = setting_action(i);
            if (down & KEY_LEFT) { if (act == ACT_NONE) setting_change(i, -1); }
            if ((down & KEY_RIGHT) && act == ACT_NONE) setting_change(i, +1);
            if (down & KEY_A) {
                if (act == ACT_RELOAD) reload_library(app);
                else if (act == ACT_RESET) { settings_reset(); snprintf(app->error, sizeof(app->error), "%s", tr("Ajustes restaurados.")); }
                else setting_change(i, +1);
            }
            break;
        }
        default: break;
    }
    if (down & (KEY_Y | KEY_SELECT)) {
        if (app->screen != SCREEN_PLAYING && app->screen != SCREEN_ALBUM && app->screen != SCREEN_VIDEO) section_step(app, 1);
    }
    if ((down & KEY_SELECT) && app->screen == SCREEN_ALBUM) section_step(app, 1);
}

/* ------------------------------------------------------------------ un frame */
void desk_frame(App *app, const UiInput *in) {
    CW = ui_main_w();
    CH = ui_main_h();
    mx = in->mouseX; my = in->mouseY;
    mdown = in->mouseDown; mclick = in->mouseClicked; mrel = in->mouseReleased; rclick = in->rightClicked;
    mmoved = in->mouseMoved;
    wheelN = in->wheel;
    if (mmoved || mclick || wheelN) keyNav = false;
    if (app->screen == SCREEN_GAME_SONGS) app->screen = SCREEN_GAMES;
    if (app->screen == SCREEN_COVER_PICK) app->screen = SCREEN_ALBUM;

    /* entrada de teclado/gamepad */
    handle_keys(app, in->downRepeat);
    if (rclick) desk_back(app);

    /* transicion entre pantallas */
    static Screen prev = SCREEN_LIBRARY;
    static double t0 = -10;
    if (app->screen != prev) { prev = app->screen; t0 = ui_time(); }
    float e = ui_ease_out((float)((ui_time() - t0) / 0.28));
    if (e > 1) e = 1;

    ui_scene_main();
    bool cinema = app->screen == SCREEN_VIDEO && app->video;
    if (!cinema) {
        bool pv = player_current(&app->player) != NULL && app->screen != SCREEN_PLAYING;
        float ch = CH - (pv ? PLAYER_H : 0);
        /* dialogos: lo de abajo no recibe clics mientras estan abiertos */
        bool modal = songPickOpen || coverPickOpen;
        bool saveLive = uiLive;
        uiLive = !modal;
        sidebar(app, ch);
        float cx = SIDE_W, cw = CW - SIDE_W;
        ui_clip(cx, 0, cw, ch);
        ui_set_offset(0, (1 - e) * 12);
        switch (app->screen) {
            case SCREEN_LIBRARY:  screen_library(app, cx, 0, cw, ch); break;
            case SCREEN_ALBUM:    screen_album(app, cx, 0, cw, ch); break;
            case SCREEN_PLAYING:  screen_playing(app, cx, 0, cw, ch); break;
            case SCREEN_VIDEOS:   screen_videos(app, cx, 0, cw, ch); break;
            case SCREEN_GAMES:    screen_games(app, cx, 0, cw, ch); break;
            case SCREEN_SETTINGS: screen_settings(app, cx, 0, cw, ch); break;
            default: break;
        }
        ui_set_offset(0, 0);
        if (e < 1) ui_rect(cx, 0, cw, ch, C2D_Color32(0x12, 0x12, 0x12, (int)((1 - e) * 200)));
        ui_clip_reset();
        if (pv) miniplayer(app);
        uiLive = saveLive;
        if (songPickOpen) song_picker(app);
        if (coverPickOpen) cover_picker(app);
    } else {
        cinema_hud(app);
    }
    toast(app);
    wheelN = 0;
}
