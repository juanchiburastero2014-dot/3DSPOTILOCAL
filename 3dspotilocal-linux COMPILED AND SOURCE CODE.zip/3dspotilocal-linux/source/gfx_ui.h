#ifndef VIBRA_UI_H
#define VIBRA_UI_H

#include "common.h"

/* ---------------------------------------------------------------------------
 * Capa grafica (SDL2 + FreeType). Las coordenadas son las de la 3DS:
 * pantalla superior 400x240, inferior 320x240. Internamente se dibuja a mayor
 * resolucion (supersampling) asi que las formas y el texto salen nitidos.
 * ------------------------------------------------------------------------- */

typedef struct {
    u32  down, held;          /* botones estilo 3DS (KEY_*) */
    u32  downRepeat;          /* como 'down' pero las direcciones se repiten al mantenerlas (para menus) */
    bool touching;            /* click izquierdo dentro de la pantalla inferior */
    int  touchX, touchY;      /* posicion en coordenadas de la pantalla inferior */
    int  wheel;               /* rueda del mouse: >0 arriba, <0 abajo */
    int  circleX, circleY;    /* "circle pad": WASD o stick izquierdo, -156..156 */
    bool quit;                /* se cerro la ventana */
    /* mouse en modo escritorio (coordenadas del lienzo unico, ver ui_main_w/h) */
    float mouseX, mouseY;
    bool  mouseInside, mouseMoved, mouseDown, mouseClicked, mouseReleased, rightClicked;
} UiInput;

bool ui_init(const char *title, int winW, int winH, bool software);
void ui_exit(void);
bool ui_poll_input(UiInput *in);           /* un llamado por frame */
float ui_dt(void);                         /* segundos del ultimo frame */
double ui_time(void);                      /* segundos desde que arranco */

/* Modo escritorio: un unico lienzo del tamano de la ventana (UI nueva). Modo dual: las dos pantallas de la 3DS
 * (se usa en los juegos, que fueron disenados asi). */
void  ui_set_desktop(bool on);
bool  ui_is_desktop(void);
void  ui_scene_main(void);
float ui_main_w(void);
float ui_main_h(void);
bool  ui_cinema_controls_visible(void);

/* Un frame: begin -> (scene_top, dibujo)(scene_bottom, dibujo) -> end */
void ui_frame_begin(void);
void ui_frame_end(void);
void ui_scene_top(void);
void ui_scene_bottom(void);
void ui_clear(u32 color);

/* Primitivas */
void ui_rect(float x, float y, float w, float h, u32 color);
void ui_rounded(float x, float y, float w, float h, float r, u32 color);
void ui_circle(float cx, float cy, float r, u32 color);
void ui_triangle(float x0, float y0, float x1, float y1, float x2, float y2, u32 color);
void ui_image(C2D_Image img, float x, float y, float w, float h);
void ui_image_tint(C2D_Image img, float x, float y, float w, float h, u32 color);

/* Extras (nuevos en la version Linux; los usan la UI y los scripts Lua) */
void ui_gradient(float x, float y, float w, float h, u32 top, u32 bottom);
void ui_gradient_h(float x, float y, float w, float h, u32 left, u32 right);
void ui_line(float x0, float y0, float x1, float y1, float thick, u32 color);
void ui_ring(float cx, float cy, float r, float thick, u32 color);
void ui_shadow(float x, float y, float w, float h, float r, float spread, int alpha);
void ui_quad(const float *xy8, u32 c0, u32 c1, u32 c2, u32 c3);   /* 4 vertices (x,y) con color por vertice */
void ui_image_ex(C2D_Image img, float sx, float sy, float sw, float sh,
                 float dx, float dy, float dw, float dh, float rotDeg, bool flipX, bool flipY, u32 tint);
void ui_clip(float x, float y, float w, float h);   /* recorta el dibujo; ui_clip_reset() lo quita */
void ui_clip_reset(void);
void ui_blend_add(bool on);                          /* mezcla aditiva (brillos) */
void ui_set_offset(float dx, float dy);              /* desplaza todo lo que se dibuje */
void ui_set_fade(float amount);                      /* 0..1 velo negro sobre ambas pantallas */

/* Animacion */
float ui_smooth(float *v, float target, float speed);   /* acerca v a target (exponencial, independiente del fps) */
float ui_ease_out(float t);
float ui_ease_in_out(float t);
float ui_lerpf(float a, float b, float t);
u32   ui_color_mix(u32 a, u32 b, float t);
u32   ui_color_alpha(u32 c, float a);                   /* multiplica el alfa */

/* Texto. y es el borde superior de la linea; scale ~0.45 es texto normal. */
void ui_text(float x, float y, float scale, u32 color, const char *fmt, ...);
void ui_text_center_raw(float cx, float y, float scale, u32 color, const char *str);
void ui_text_right_raw(float rightX, float y, float scale, u32 color, const char *str);
void ui_text_center(float cx, float y, float scale, u32 color, const char *str);
void ui_text_right(float rightX, float y, float scale, u32 color, const char *str);
float ui_text_width(const char *str, float scale);
void ui_text_clipped(float x, float y, float scale, u32 color, float maxWidth, const char *str);

/* Iconos vectoriales de la barra de reproduccion */
void ui_icon_play(float cx, float cy, float s, u32 color);
void ui_icon_pause(float cx, float cy, float s, u32 color);
void ui_icon_next(float cx, float cy, float s, u32 color);
void ui_icon_prev(float cx, float cy, float s, u32 color);

/* Texturas (para caratulas, video, sprites de los scripts) */
C2D_Image ui_texture_from_rgba(const u8 *rgba, int w, int h, bool linear);
C2D_Image ui_texture_streaming(int w, int h);
void      ui_texture_update(C2D_Image img, const void *rgba, int pitch);
void      ui_texture_destroy(C2D_Image *img);

/* Modo cine: mientras hay una imagen, ocupa toda la ventana (respetando proporcion) y la pantalla tactil queda como
 * panel de controles abajo, visible al mover el mouse / tocar teclas (o siempre si forceControls). */
void ui_cinema(C2D_Image img, bool forceControls);

/* Ventana */
void ui_toggle_fullscreen(void);
void ui_cycle_layout(void);
void ui_request_screenshot(const char *path);   /* guarda la ventana completa al terminar el proximo frame */
bool ui_screenshot(const char *path);        /* guarda la ventana completa en .bmp */
bool ui_save_screens(const char *topPath, const char *botPath);  /* solo cada pantalla, en .bmp */

#endif
