#ifndef VIBRA_APP_H
#define VIBRA_APP_H

#include "common.h"
#include "player.h"
#include "video.h"
#include "games.h"
#include "lyrics.h"
#include "gfx_ui.h"

typedef struct {
    Library    *lib;
    Player      player;
    VideoPlayer *video;
    Screen      screen;

    int  libCursor;
    int  libScroll;
    int  albumViewIdx;
    int  albumCursor;
    int  albumScroll;
    int  videoCursor;
    int  videoScroll;
    int  videoIndex;
    int  gameCursor;
    int  gameScroll;
    int  songCursor;
    int  songScroll;
    GameKind gameKind;
    int  settingCursor;
    int  settingScroll;
    /* lyrics + covers */
    const Track *lyricsFor;
    bool showLyrics;
    int  lyricsOffset;
    int  coverCursor;
    int  coverScroll;
    bool coverForTrack;
    int  coverAlbum;
    int  coverTrack;

    char error[MAX_NAME];
    bool running;
    u32  frames;
} App;

void app_init(App *app, Library *lib);
void app_exit(App *app);
void app_open_video(App *app, int index);
void app_close_video(App *app);
void app_frame(App *app, const UiInput *in);   /* un frame completo: entrada, logica y dibujo */

#endif