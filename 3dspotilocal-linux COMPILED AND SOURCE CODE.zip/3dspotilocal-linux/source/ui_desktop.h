#ifndef VIBRA_UI_DESKTOP_H
#define VIBRA_UI_DESKTOP_H

#include "app.h"

/* UI de escritorio: un unico lienzo del tamano de la ventana (barra lateral, grilla de albumes, reproductor,
 * videos, juegos y ajustes). Los juegos siguen usando el modo de dos pantallas. */
extern bool g_classic_ui;          /* --clasico: vuelve a las dos pantallas virtuales de la 3DS */

/* Dibuja y atiende un frame de la UI de escritorio (todas las pantallas menos SCREEN_GAME). */
void desk_frame(App *app, const UiInput *in);

#endif
