#include "lyrics.h"
#include "gfx_ui.h"
#include <ctype.h>

#define LYRICS_DIR g_dir_lyrics
#define MAX_FILE   (64 * 1024)
#define WRAP_W     372.0f
#define WRAP_SCALE 0.5f

static LyricLine *lines;
static int count;
static bool timed;

void lyrics_free(void) {
    free(lines);
    lines = NULL;
    count = 0;
    timed = false;
}

int lyrics_count(void) { return count; }
bool lyrics_timed(void) { return timed; }
const LyricLine *lyrics_line(int i) { return i >= 0 && i < count ? &lines[i] : NULL; }

static bool read_file(const char *path, char **out) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    char *buf = (char *)malloc(MAX_FILE + 1);
    if (!buf) { fclose(f); return false; }
    size_t n = fread(buf, 1, MAX_FILE, f);
    fclose(f);
    if (n == 0) { free(buf); return false; }
    buf[n] = '\0';
    *out = buf;
    return true;
}

static bool find_lyrics_file(const char *trackPath, char **out) {
    char path[MAX_PATH];
    static const char *exts[] = { ".txt", ".lrc", NULL };
    snprintf(path, sizeof(path), "%s", trackPath);
    char *dot = strrchr(path, '.');
    char *slash = strrchr(path, '/');
    if (!dot || (slash && dot < slash)) dot = path + strlen(path);
    for (int i = 0; exts[i]; i++) {
        snprintf(dot, sizeof(path) - (size_t)(dot - path), "%s", exts[i]);
        if (read_file(path, out)) return true;
    }
    /* fallback: ~/3dSpotiLocal/Lyrics/<song name>.txt */
    char name[MAX_NAME];
    snprintf(name, sizeof(name), "%s", path_basename(trackPath));
    strip_ext(name);
    for (int i = 0; exts[i]; i++) {
        snprintf(path, sizeof(path), "%s/%s%s", LYRICS_DIR, name, exts[i]);
        if (read_file(path, out)) return true;
    }
    return false;
}

/* Parses "[mm:ss]" / "[mm:ss.xx]". Returns characters consumed, or 0 if it is not a time tag. */
static int parse_tag(const char *s, int *ms) {
    if (*s != '[') return 0;
    const char *p = s + 1;
    if (!isdigit((unsigned char)*p)) return 0;
    int min = 0;
    while (isdigit((unsigned char)*p) && min < 1000) min = min * 10 + (*p++ - '0');
    if (*p != ':') return 0;
    p++;
    if (!isdigit((unsigned char)*p)) return 0;
    int sec = 0, frac = 0, fracDigits = 0;
    while (isdigit((unsigned char)*p) && sec < 1000) sec = sec * 10 + (*p++ - '0');
    if (*p == '.' || *p == ':') {
        p++;
        while (isdigit((unsigned char)*p)) {
            if (fracDigits < 3) { frac = frac * 10 + (*p - '0'); fracDigits++; }
            p++;
        }
    }
    if (*p != ']') return 0;
    while (fracDigits < 3) { frac *= 10; fracDigits++; }
    *ms = (min * 60 + sec) * 1000 + frac;
    return (int)(p - s) + 1;
}

static bool add_line(const char *text, size_t len, int ms) {
    if (count >= LYRIC_MAX_LINES) return false;
    LyricLine *l = &lines[count++];
    if (len >= LYRIC_TEXT) len = LYRIC_TEXT - 1;
    /* do not cut a UTF-8 sequence in half */
    while (len > 0 && ((unsigned char)text[len] & 0xC0) == 0x80) len--;
    memcpy(l->text, text, len);
    l->text[len] = '\0';
    l->ms = ms;
    return true;
}

/* Greedy word wrap using the real font metrics. */
static void add_wrapped(const char *text, int ms) {
    size_t total = strlen(text);
    if (total == 0) { add_line("", 0, ms); return; }
    size_t start = 0;
    while (start < total) {
        size_t end = total, lastSpace = 0;
        bool broke = false;
        char tmp[LYRIC_TEXT];
        for (size_t i = start; i < total && i - start < LYRIC_TEXT - 2; i++) {
            if (text[i] == ' ') lastSpace = i;
            size_t len = i + 1 - start;
            if (((unsigned char)text[i + 1] & 0xC0) == 0x80) continue;   /* mid UTF-8 sequence */
            memcpy(tmp, text + start, len);
            tmp[len] = '\0';
            if (ui_text_width(tmp, WRAP_SCALE) > WRAP_W) {
                end = lastSpace > start ? lastSpace : i;
                if (end <= start) end = i;
                broke = true;
                break;
            }
        }
        if (!broke && total - start > LYRIC_TEXT - 2)   /* too long for one buffer even if it fits the screen */
            end = lastSpace > start ? lastSpace : start + LYRIC_TEXT - 2;
        while (end > start + 1 && ((unsigned char)text[end] & 0xC0) == 0x80) end--;   /* never split a UTF-8 character */
        if (end <= start) {                                                           /* always make progress */
            end = start + 1;
            while (end < total && ((unsigned char)text[end] & 0xC0) == 0x80) end++;
        }
        if (!add_line(text + start, end - start, ms)) return;
        start = end;
        while (start < total && text[start] == ' ') start++;
    }
}

bool lyrics_load(const char *trackPath) {
    lyrics_free();
    if (!trackPath) return false;
    char *buf = NULL;
    if (!find_lyrics_file(trackPath, &buf)) return false;
    lines = (LyricLine *)malloc(sizeof(LyricLine) * LYRIC_MAX_LINES);
    if (!lines) { free(buf); return false; }

    char *p = buf;
    if ((unsigned char)p[0] == 0xEF && (unsigned char)p[1] == 0xBB && (unsigned char)p[2] == 0xBF) p += 3;   /* BOM */
    int lastMs = -1;
    while (*p && count < LYRIC_MAX_LINES) {
        char *eol = p;
        while (*eol && *eol != '\n') eol++;
        char saved = *eol;
        *eol = '\0';
        size_t len = strlen(p);
        while (len && (p[len - 1] == '\r' || p[len - 1] == ' ' || p[len - 1] == '\t')) p[--len] = '\0';

        int ms = -1, tagMs, n;
        char *text = p;
        while ((n = parse_tag(text, &tagMs)) > 0) { ms = tagMs; text += n; }
        bool metaTag = (ms < 0 && text[0] == '[' && isalpha((unsigned char)text[1]) && strchr(text, ':') && text[strlen(text) - 1] == ']');
        if (!metaTag) {
            while (*text == ' ') text++;
            if (ms >= 0) { timed = true; lastMs = ms; }
            add_wrapped(text, ms >= 0 ? ms : lastMs);
        }
        if (!saved) break;
        p = eol + 1;
    }
    free(buf);

    /* Trim trailing blank lines; drop the result if there is nothing readable. */
    while (count > 0 && lines[count - 1].text[0] == '\0') count--;
    bool any = false;
    for (int i = 0; i < count && !any; i++) any = lines[i].text[0] != '\0';
    if (!any) { lyrics_free(); return false; }
    if (!timed) for (int i = 0; i < count; i++) lines[i].ms = -1;
    return true;
}

int lyrics_current(u64 posMs, u64 durMs, int manualOffset) {
    if (count == 0) return 0;
    int cur;
    if (timed) {
        cur = 0;
        for (int i = 0; i < count; i++)
            if (lines[i].ms >= 0 && (u64)lines[i].ms <= posMs + 250) cur = i;
            else if (lines[i].ms > (int)posMs + 250) break;
    } else {
        cur = durMs ? (int)((u64)count * posMs / durMs) : 0;
    }
    return clampi(cur + manualOffset, 0, count - 1);
}
