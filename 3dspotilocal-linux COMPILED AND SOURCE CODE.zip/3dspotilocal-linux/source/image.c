#include "image.h"
#include "gfx_ui.h"

#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define TEX_SIZE   512      /* las caratulas se guardan cuadradas (recorte centrado) */
#define CACHE_MAX  48

typedef struct {
    char      path[MAX_PATH];
    C2D_Image img;
    bool      used;
    u32       tick;
} CacheEntry;

static CacheEntry cache[CACHE_MAX];
static u32 tickCounter = 0;

static void entry_free(CacheEntry *e) {
    ui_texture_destroy(&e->img);
    e->used = false;
    e->path[0] = '\0';
}

/* Recorte cuadrado centrado + reduccion por promedio de cajas (se ve bastante mejor que "nearest"). */
static C2D_Image load_scaled(const char *path) {
    C2D_Image none = { NULL, 0, 0 };
    int w = 0, h = 0, comp = 0;
    if (!stbi_info(path, &w, &h, &comp) || w <= 0 || h <= 0 || w > 8192 || h > 8192) return none;
    unsigned char *src = stbi_load(path, &w, &h, &comp, 4);
    if (!src) return none;

    int side = w < h ? w : h;
    int ox = (w - side) / 2, oy = (h - side) / 2;
    int out = side < TEX_SIZE ? side : TEX_SIZE;
    if (out < 1) out = 1;
    unsigned char *dst = (unsigned char *)malloc((size_t)out * (size_t)out * 4);
    if (!dst) { stbi_image_free(src); return none; }

    for (int y = 0; y < out; y++) {
        int y0 = (int)((u64)y * (u64)side / (u64)out), y1 = (int)((u64)(y + 1) * (u64)side / (u64)out);
        if (y1 <= y0) y1 = y0 + 1;
        for (int x = 0; x < out; x++) {
            int x0 = (int)((u64)x * (u64)side / (u64)out), x1 = (int)((u64)(x + 1) * (u64)side / (u64)out);
            if (x1 <= x0) x1 = x0 + 1;
            unsigned acc[4] = { 0, 0, 0, 0 };
            unsigned n = 0;
            for (int yy = y0; yy < y1; yy++) {
                const unsigned char *row = src + ((size_t)(oy + yy) * (size_t)w + (size_t)(ox + x0)) * 4;
                for (int xx = x0; xx < x1; xx++, row += 4) {
                    acc[0] += row[0]; acc[1] += row[1]; acc[2] += row[2]; acc[3] += row[3];
                    n++;
                }
            }
            unsigned char *d = dst + ((size_t)y * (size_t)out + (size_t)x) * 4;
            d[0] = (unsigned char)(acc[0] / n); d[1] = (unsigned char)(acc[1] / n);
            d[2] = (unsigned char)(acc[2] / n); d[3] = (unsigned char)(acc[3] / n);
        }
    }
    stbi_image_free(src);
    C2D_Image img = ui_texture_from_rgba(dst, out, out, true);
    free(dst);
    return img;
}

C2D_Image image_get(const char *path) {
    C2D_Image none = { NULL, 0, 0 };
    if (!path || !path[0]) return none;
    tickCounter++;

    for (int i = 0; i < CACHE_MAX; i++) {
        if (cache[i].used && strcmp(cache[i].path, path) == 0) {
            cache[i].tick = tickCounter;
            return cache[i].img;
        }
    }

    int slot = -1;
    for (int i = 0; i < CACHE_MAX; i++) {
        if (!cache[i].used) { slot = i; break; }
    }
    if (slot < 0) {
        u32 oldest = 0xFFFFFFFF;
        for (int i = 0; i < CACHE_MAX; i++) {
            if (cache[i].tick < oldest) { oldest = cache[i].tick; slot = i; }
        }
        entry_free(&cache[slot]);
    }

    C2D_Image img = load_scaled(path);
    if (!img.tex) return none;

    cache[slot].used = true;
    cache[slot].tick = tickCounter;
    snprintf(cache[slot].path, MAX_PATH, "%s", path);
    cache[slot].img = img;
    return img;
}

void image_clear_all(void) {
    for (int i = 0; i < CACHE_MAX; i++) {
        if (cache[i].used) entry_free(&cache[i]);
    }
}
