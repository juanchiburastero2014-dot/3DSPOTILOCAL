/* video.c - reproduccion de video con ffmpeg/ffprobe por tuberias (pipes). */
#define _GNU_SOURCE
#include "video.h"
#include "audio.h"
#include "gfx_ui.h"
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>

#define MAX_OUT_W   1280
#define MAX_OUT_H   720
#define ARATE       44100
#define ABUF_BYTES  (32 * 1024)

struct VideoPlayer {
    char   path[MAX_PATH];
    int    srcW, srcH, outW, outH;
    double fps, duration;
    bool   hasAudio;

    pid_t  vpid, apid;
    int    vfd, afd;
    bool   vEof, aEof, procs;

    u8    *assemble, *ready, *disp;
    size_t fill, frameSize;
    bool   haveReady;
    long long frameIdx;              /* indice del proximo cuadro que sale de ffmpeg */
    double readyPts;

    u8     abuf[ABUF_BYTES];
    size_t aFill;
    u64    audioFed;                 /* frames de audio encolados desde el ultimo (re)inicio */

    double startSec;                 /* donde empezo (seek) = origen del reloj de audio */
    double vStart;                   /* origen del video (puede reiniciarse para recuperar el sincronismo) */
    int    dropStreak;
    u64    lastResync;
    double lastClock;
    u64    wallStart, wallPausedAt, wallPausedTotal;
    bool   playing, paused, finished, needFrame, audioOpen;
    C2D_Image tex;
    u64    shown;                    /* cuadros mostrados (diagnostico) */
};

/* ------------------------------------------------------------------ procesos */
static int run_capture(char *const argv[], char *out, size_t n) {
    int pfd[2];
    if (pipe(pfd) != 0) return -1;
    pid_t pid = fork();
    if (pid < 0) { close(pfd[0]); close(pfd[1]); return -1; }
    if (pid == 0) {
        dup2(pfd[1], 1);
        close(pfd[0]); close(pfd[1]);
        int nul = open("/dev/null", O_WRONLY);
        if (nul >= 0) dup2(nul, 2);
        execvp(argv[0], argv);
        _exit(127);
    }
    close(pfd[1]);
    size_t len = 0;
    ssize_t r;
    while (len < n - 1 && (r = read(pfd[0], out + len, n - 1 - len)) > 0) len += (size_t)r;
    out[len] = '\0';
    close(pfd[0]);
    int st = 0;
    waitpid(pid, &st, 0);
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}

static pid_t spawn_reader(char *const argv[], int *fdOut) {
    int pfd[2];
    if (pipe(pfd) != 0) return -1;
    pid_t pid = fork();
    if (pid < 0) { close(pfd[0]); close(pfd[1]); return -1; }
    if (pid == 0) {
        dup2(pfd[1], 1);
        close(pfd[0]); close(pfd[1]);
        int nul = open("/dev/null", O_RDWR);
        if (nul >= 0) { dup2(nul, 2); dup2(nul, 0); }
        execvp(argv[0], argv);
        _exit(127);
    }
    close(pfd[1]);
    fcntl(pfd[0], F_SETFL, fcntl(pfd[0], F_GETFL) | O_NONBLOCK);
#ifdef F_SETPIPE_SZ
    fcntl(pfd[0], F_SETPIPE_SZ, 1 << 20);      /* tuberia de 1 MB: un cuadro entero entra de una */
#endif
    *fdOut = pfd[0];
    return pid;
}

static void kill_procs(VideoPlayer *v) {
    if (v->vpid > 0) { kill(v->vpid, SIGKILL); waitpid(v->vpid, NULL, 0); }
    if (v->apid > 0) { kill(v->apid, SIGKILL); waitpid(v->apid, NULL, 0); }
    if (v->vfd >= 0) close(v->vfd);
    if (v->afd >= 0) close(v->afd);
    v->vpid = v->apid = -1;
    v->vfd = v->afd = -1;
    v->procs = false;
}

static bool spawn_procs(VideoPlayer *v) {
    char ss[32], vf[128], fpsb[32];
    char vss[32];
    snprintf(ss, sizeof(ss), "%.3f", v->startSec);
    snprintf(vss, sizeof(vss), "%.3f", v->vStart = v->startSec);
    snprintf(vf, sizeof(vf), "fps=%.3f,scale=%d:%d:flags=fast_bilinear", v->fps, v->outW, v->outH);
    snprintf(fpsb, sizeof(fpsb), "%.3f", v->fps);
    char *vargv[] = { "ffmpeg", "-v", "error", "-ss", vss, "-i", v->path, "-an", "-sn", "-vf", vf,
                      "-pix_fmt", "rgba", "-f", "rawvideo", "-", NULL };
    v->vpid = spawn_reader(vargv, &v->vfd);
    if (v->vpid < 0) return false;
    if (v->hasAudio) {
        char *aargv[] = { "ffmpeg", "-v", "error", "-ss", ss, "-i", v->path, "-vn", "-sn", "-ac", "2",
                          "-ar", "44100", "-f", "s16le", "-", NULL };
        v->apid = spawn_reader(aargv, &v->afd);
    }
    v->procs = true;
    v->vEof = false;
    v->aEof = !v->hasAudio;
    v->fill = 0;
    v->aFill = 0;
    v->haveReady = false;
    v->frameIdx = 0;
    v->audioFed = 0;
    v->wallStart = osGetTime();
    v->wallPausedTotal = 0;
    v->wallPausedAt = v->paused ? v->wallStart : 0;
    return true;
}

/* ------------------------------------------------------------------ API */
static double parse_rate(const char *s) {
    double a = 0, b = 1;
    if (sscanf(s, "%lf/%lf", &a, &b) >= 1 && b > 0) return a / b;
    return 0;
}

VideoPlayer *video_open(const char *path) {
    char out[1024];
    char *probe[] = { "ffprobe", "-v", "error", "-select_streams", "v:0",
                      "-show_entries", "stream=width,height,avg_frame_rate:format=duration",
                      "-of", "default=nw=1", (char *)path, NULL };
    if (run_capture(probe, out, sizeof(out)) != 0) return NULL;
    int w = 0, h = 0;
    double fps = 0, dur = 0;
    const char *p;
    if ((p = strstr(out, "width="))) w = atoi(p + 6);
    if ((p = strstr(out, "height="))) h = atoi(p + 7);
    if ((p = strstr(out, "avg_frame_rate="))) fps = parse_rate(p + 15);
    if ((p = strstr(out, "duration="))) dur = atof(p + 9);
    if (w <= 0 || h <= 0) return NULL;
    if (fps < 1 || fps > 120) fps = 30;
    if (fps > 60) fps = 60;

    char aout[256];
    char *aprobe[] = { "ffprobe", "-v", "error", "-select_streams", "a:0",
                       "-show_entries", "stream=codec_type", "-of", "default=nw=1", (char *)path, NULL };
    bool hasAudio = run_capture(aprobe, aout, sizeof(aout)) == 0 && strstr(aout, "audio") != NULL;

    VideoPlayer *v = (VideoPlayer *)calloc(1, sizeof(*v));
    if (!v) return NULL;
    snprintf(v->path, sizeof(v->path), "%s", path);
    v->srcW = w; v->srcH = h; v->fps = fps; v->duration = dur; v->hasAudio = hasAudio;
    double sc = 1.0;
    if (w > MAX_OUT_W) sc = (double)MAX_OUT_W / w;
    if (h * sc > MAX_OUT_H) sc = (double)MAX_OUT_H / h;
    v->outW = ((int)(w * sc)) & ~1;
    v->outH = ((int)(h * sc)) & ~1;
    if (v->outW < 2) v->outW = 2;
    if (v->outH < 2) v->outH = 2;
    v->frameSize = (size_t)v->outW * (size_t)v->outH * 4;
    v->assemble = (u8 *)malloc(v->frameSize);
    v->ready = (u8 *)malloc(v->frameSize);
    v->disp = (u8 *)malloc(v->frameSize);
    v->vpid = v->apid = -1;
    v->vfd = v->afd = -1;
    v->tex = ui_texture_streaming(v->outW, v->outH);
    if (!v->assemble || !v->ready || !v->disp || !v->tex.tex) { video_close(v); return NULL; }
    memset(v->assemble, 0, v->frameSize);
    ui_texture_update(v->tex, v->assemble, v->outW * 4);
    return v;
}

void video_close(VideoPlayer *v) {
    if (!v) return;
    kill_procs(v);
    if (v->audioOpen) audio_pcm_close();
    ui_texture_destroy(&v->tex);
    free(v->assemble);
    free(v->ready);
    free(v->disp);
    free(v);
}

void video_play(VideoPlayer *v) {
    if (!v || v->procs) return;
    v->paused = false;
    v->playing = true;
    v->finished = false;
    v->needFrame = true;
    if (v->hasAudio && !v->audioOpen) v->audioOpen = audio_pcm_open(ARATE);
    if (v->hasAudio && !v->audioOpen) v->hasAudio = false;   /* sin dispositivo de audio: sigue sin sonido */
    spawn_procs(v);
}

static double clock_now(VideoPlayer *v) {
    if (v->hasAudio && v->audioOpen) {
        u64 q = audio_pcm_queued();
        u64 played = v->audioFed > q ? v->audioFed - q : 0;
        return v->startSec + (double)played / ARATE;
    }
    u64 now = v->paused ? v->wallPausedAt : osGetTime();
    return v->startSec + (double)(now - v->wallStart - v->wallPausedTotal) / 1000.0;
}

void video_pause(VideoPlayer *v, bool pause) {
    if (!v || !v->playing || pause == v->paused) return;
    v->paused = pause;
    if (v->audioOpen) audio_pcm_pause(pause);
    if (pause) v->wallPausedAt = osGetTime();
    else { v->wallPausedTotal += osGetTime() - v->wallPausedAt; v->needFrame = false; }
}

bool video_is_paused(VideoPlayer *v) { return v && v->paused; }
bool video_finished(VideoPlayer *v) { return v && v->finished; }

static void pump_audio(VideoPlayer *v) {
    if (!v->audioOpen || v->aEof || v->afd < 0) return;
    while (audio_pcm_queued() < (size_t)(ARATE / 2)) {
        ssize_t r = read(v->afd, v->abuf + v->aFill, ABUF_BYTES - v->aFill);
        if (r < 0) { if (errno == EAGAIN || errno == EINTR) break; v->aEof = true; break; }
        if (r == 0) { v->aEof = true; break; }
        v->aFill += (size_t)r;
        size_t frames = v->aFill / 4;
        if (frames) {
            audio_pcm_queue((const s16 *)v->abuf, frames);
            v->audioFed += frames;
            size_t used = frames * 4;
            memmove(v->abuf, v->abuf + used, v->aFill - used);
            v->aFill -= used;
        }
    }
}

void video_update(VideoPlayer *v) {
    if (!v || !v->playing || !v->procs) return;
    if (v->paused && !v->needFrame) return;
    pump_audio(v);
    double clock = v->needFrame ? v->startSec : clock_now(v);
    v->lastClock = clock;

    /* Se leen todos los cuadros que ya "vencieron" y se sube solo el ultimo: si el loop va mas lento que el video
     * (ventana enorme, PC justa) el video sigue a su velocidad y salta cuadros en vez de ir en camara lenta. */
    u64 t0 = osGetTime();
    bool haveDisp = false;
    while (v->vfd >= 0 && !v->vEof && osGetTime() - t0 < 12) {
        if (!v->haveReady) {
            ssize_t r = read(v->vfd, v->assemble + v->fill, v->frameSize - v->fill);
            if (r < 0) { if (errno == EINTR) continue; if (errno == EAGAIN) break; v->vEof = true; break; }
            if (r == 0) { v->vEof = true; break; }
            v->fill += (size_t)r;
            if (v->fill < v->frameSize) continue;      /* sigue leyendo el mismo cuadro */
            u8 *t = v->assemble; v->assemble = v->ready; v->ready = t;
            v->fill = 0;
            v->haveReady = true;
            v->readyPts = v->vStart + (double)v->frameIdx / v->fps;
            v->frameIdx++;
        }
        if (!(v->haveReady && (v->readyPts <= clock || v->needFrame))) break;
        double late = clock - v->readyPts;
        if (late > 1.5 && !v->needFrame && osGetTime() - v->lastResync > 3000) {
            /* muy atrasados: en vez de decodificar y tirar cuadros, reiniciamos el video en la posicion actual */
            v->lastResync = osGetTime();
            v->haveReady = false;
            if (v->vpid > 0) { kill(v->vpid, SIGKILL); waitpid(v->vpid, NULL, 0); }
            if (v->vfd >= 0) close(v->vfd);
            char vss[32], vf[128];
            snprintf(vss, sizeof(vss), "%.3f", clock);
            snprintf(vf, sizeof(vf), "fps=%.3f,scale=%d:%d:flags=fast_bilinear", v->fps, v->outW, v->outH);
            char *vargv[] = { "ffmpeg", "-v", "error", "-ss", vss, "-i", v->path, "-an", "-sn", "-vf", vf,
                              "-pix_fmt", "rgba", "-f", "rawvideo", "-", NULL };
            v->vpid = spawn_reader(vargv, &v->vfd);
            v->vStart = clock;
            v->frameIdx = 0;
            v->fill = 0;
            break;
        }
        u8 *t = v->ready; v->ready = v->disp; v->disp = t;     /* candidato a mostrar */
        v->haveReady = false;
        v->needFrame = false;
        haveDisp = true;
    }
    if (haveDisp) {
        ui_texture_update(v->tex, v->disp, v->outW * 4);
        v->shown++;
    }

    /* terminado: ya no vienen cuadros y el audio se vacio */
    if (v->vEof && !v->haveReady) {
        bool audioDrained = !v->audioOpen || (v->aEof && audio_pcm_queued() == 0);
        if (audioDrained) v->finished = true;
    }
    if (v->duration > 0 && clock >= v->duration + 0.5) v->finished = true;
}

C2D_Image video_image(VideoPlayer *v) {
    C2D_Image none = { NULL, 0, 0 };
    return v ? v->tex : none;
}

u64 video_position_ms(VideoPlayer *v) {
    if (!v) return 0;
    double c = v->procs && v->playing ? (v->paused && v->needFrame ? v->startSec : clock_now(v)) : v->startSec;
    if (c < 0) c = 0;
    if (v->duration > 0 && c > v->duration) c = v->duration;
    return (u64)(c * 1000.0);
}

u64 video_frames_shown(VideoPlayer *v) { return v ? v->shown : 0; }

u64 video_duration_ms(VideoPlayer *v) { return v ? (u64)(v->duration * 1000.0) : 0; }

bool video_seek(VideoPlayer *v, u64 ms) {
    if (!v) return false;
    double t = (double)ms / 1000.0;
    if (v->duration > 0 && t > v->duration - 0.2) t = v->duration - 0.2;
    if (t < 0) t = 0;
    kill_procs(v);
    if (v->audioOpen) audio_pcm_clear();
    v->startSec = t;
    v->finished = false;
    v->needFrame = true;
    v->playing = true;
    return spawn_procs(v);
}
