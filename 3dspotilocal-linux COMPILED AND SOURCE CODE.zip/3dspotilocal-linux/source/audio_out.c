/* audio_out.c - salida de audio con SDL2 (cola de audio). Reemplaza al NDSP de la 3DS. */
#include "audio.h"
#include <SDL2/SDL.h>

static SDL_AudioDeviceID dev;
static int   devRate;
static AudioStream *dec;
static bool  active, paused, eofReached, sdlOk;
static u64   baseFrame, fedFrames;
static float masterVol = 1.0f;
static s16   chunk[AUDIO_CHUNK_FRAMES * 2];

/* ------------------------------------------------------------ PCM generico */
bool audio_pcm_open(int rate) {
    audio_pcm_close();
    if (!sdlOk) return false;
    SDL_AudioSpec want;
    memset(&want, 0, sizeof(want));
    want.freq = rate;
    want.format = AUDIO_S16SYS;
    want.channels = 2;
    want.samples = 1024;
    SDL_AudioSpec have;
    dev = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);   /* 0 = SDL convierte lo que haga falta */
    if (!dev) return false;
    devRate = rate;
    SDL_PauseAudioDevice(dev, 0);
    return true;
}

void audio_pcm_close(void) {
    if (dev) { SDL_CloseAudioDevice(dev); dev = 0; }
}

void audio_pcm_queue(const s16 *stereo, size_t frames) {
    if (!dev || frames == 0) return;
    static s16 tmp[AUDIO_CHUNK_FRAMES * 2];
    while (frames > 0) {
        size_t n = frames > AUDIO_CHUNK_FRAMES ? AUDIO_CHUNK_FRAMES : frames;
        memcpy(tmp, stereo, n * 2 * sizeof(s16));
        audio_apply_gain(tmp, n);
        if (masterVol < 0.999f)
            for (size_t i = 0; i < n * 2; i++) tmp[i] = (s16)((float)tmp[i] * masterVol);
        SDL_QueueAudio(dev, tmp, (Uint32)(n * 2 * sizeof(s16)));
        stereo += n * 2;
        frames -= n;
    }
}

size_t audio_pcm_queued(void) { return dev ? (size_t)SDL_GetQueuedAudioSize(dev) / 4 : 0; }
void   audio_pcm_clear(void) { if (dev) SDL_ClearQueuedAudio(dev); }
void   audio_pcm_pause(bool pause) { if (dev) SDL_PauseAudioDevice(dev, pause ? 1 : 0); }

/* ------------------------------------------------------------ musica */
bool audio_out_init(void) {
    sdlOk = SDL_InitSubSystem(SDL_INIT_AUDIO) == 0;
    return sdlOk;
}

void audio_out_exit(void) {
    audio_out_stop();
}

static void fill(void) {
    if (!dec || eofReached) return;
    size_t target = (size_t)devRate / 2;               /* ~0.5 s por delante */
    while (audio_pcm_queued() < target) {
        size_t frames = audio_read(dec, chunk, AUDIO_CHUNK_FRAMES);
        if (frames == 0) { eofReached = true; return; }
        fedFrames += frames;
        audio_pcm_queue(chunk, frames);
    }
}

bool audio_out_start(AudioStream *s) {
    if (!s) return false;
    audio_out_stop();
    if (!audio_pcm_open(audio_sample_rate(s))) return false;
    dec = s;
    eofReached = false;
    active = true;
    paused = false;
    baseFrame = audio_tell(s);
    fedFrames = 0;
    fill();
    return true;
}

void audio_out_stop(void) {
    audio_pcm_close();
    active = false;
    paused = false;
    eofReached = false;
    dec = NULL;
}

void audio_out_pause(bool pause) {
    if (!active) return;
    paused = pause;
    audio_pcm_pause(pause);
}

bool audio_out_is_paused(void) { return paused; }

void audio_out_update(void) {
    if (active && !paused) fill();
}

bool audio_out_finished(void) {
    return active && eofReached && audio_pcm_queued() == 0;
}

u64 audio_out_position(void) {
    if (!active || !dec) return 0;
    u64 queued = audio_pcm_queued();
    u64 played = fedFrames > queued ? fedFrames - queued : 0;
    u64 pos = baseFrame + played;
    u64 total = audio_total_frames(dec);
    if (total && pos > total) pos = total;
    return pos;
}

bool audio_out_seek(u64 frame) {
    if (!active || !dec) return false;
    if (!audio_seek(dec, frame)) return false;
    audio_pcm_clear();
    eofReached = false;
    baseFrame = frame;
    fedFrames = 0;
    fill();
    return true;
}

void audio_out_set_volume(float vol) {
    if (vol < 0) vol = 0;
    if (vol > 1) vol = 1;
    masterVol = vol;
}
