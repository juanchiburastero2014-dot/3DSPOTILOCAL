#include "common.h"
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>

char g_dir_base[PATH_MAX_LEN], g_dir_music[PATH_MAX_LEN], g_dir_video[PATH_MAX_LEN], g_dir_covers[PATH_MAX_LEN];
char g_dir_lyrics[PATH_MAX_LEN], g_dir_games[PATH_MAX_LEN], g_dir_assets[PATH_MAX_LEN];
char g_path_settings[PATH_MAX_LEN], g_path_covers_cfg[PATH_MAX_LEN];

static bool dir_has(const char *dir, const char *rel) {
    char p[PATH_MAX_LEN * 2];
    snprintf(p, sizeof(p), "%s/%s", dir, rel);
    return file_exists(p);
}

void platform_init_paths(const char *override, const char *exeDir) {
    const char *base = override && override[0] ? override : getenv("SPOTILOCAL_HOME");
    if (base && base[0]) {
        snprintf(g_dir_base, sizeof(g_dir_base), "%s", base);
    } else {
        const char *home = getenv("HOME");
        snprintf(g_dir_base, sizeof(g_dir_base), "%s/3dSpotiLocal", home && home[0] ? home : ".");
    }
    size_t n = strlen(g_dir_base);
    while (n > 1 && g_dir_base[n - 1] == '/') g_dir_base[--n] = '\0';
    snprintf(g_dir_music, sizeof(g_dir_music), "%s/Music", g_dir_base);
    snprintf(g_dir_video, sizeof(g_dir_video), "%s/Videos", g_dir_base);
    snprintf(g_dir_covers, sizeof(g_dir_covers), "%s/Covers", g_dir_base);
    snprintf(g_dir_lyrics, sizeof(g_dir_lyrics), "%s/Lyrics", g_dir_base);
    snprintf(g_dir_games, sizeof(g_dir_games), "%s/Games", g_dir_base);
    snprintf(g_path_settings, sizeof(g_path_settings), "%s/settings.cfg", g_dir_base);
    snprintf(g_path_covers_cfg, sizeof(g_path_covers_cfg), "%s/covers.cfg", g_dir_base);

    /* assets (fuentes, icono): junto al ejecutable, en ./assets o instalados en /usr/share */
    char cand[4][PATH_MAX_LEN];
    int nc = 0;
    if (exeDir && exeDir[0]) {
        snprintf(cand[nc++], PATH_MAX_LEN, "%s/assets", exeDir);
        snprintf(cand[nc++], PATH_MAX_LEN, "%s/../assets", exeDir);
    }
    snprintf(cand[nc++], PATH_MAX_LEN, "./assets");
    snprintf(cand[nc++], PATH_MAX_LEN, "/usr/share/3dspotilocal/assets");
    g_dir_assets[0] = '\0';
    for (int i = 0; i < nc; i++) {
        if (dir_has(cand[i], "fonts/LiberationSans-Regular.ttf")) { snprintf(g_dir_assets, sizeof(g_dir_assets), "%s", cand[i]); break; }
    }
    if (!g_dir_assets[0]) snprintf(g_dir_assets, sizeof(g_dir_assets), "%s", cand[0]);
}
