#ifndef VIBRA_COMMON_H
#define VIBRA_COMMON_H

#include "platform.h"

#define TOP_W 400
#define TOP_H 240
#define BOT_W 320
#define BOT_H 240

#define MAX_ALBUMS            128
#define MAX_TRACKS_PER_ALBUM  64
#define MAX_VIDEOS            128
#define MAX_PATH              512
#define MAX_NAME              128

#define MUSIC_DIR  g_dir_music
#define VIDEO_DIR  g_dir_video

/* Spotify-style palette. C2D_Color32 packs r,g,b,a. */
#define COL_BG        C2D_Color32(0x12, 0x12, 0x12, 0xFF)
#define COL_SURFACE   C2D_Color32(0x18, 0x18, 0x18, 0xFF)
#define COL_SURFACE2  C2D_Color32(0x28, 0x28, 0x28, 0xFF)
/* The accent colour is a setting, so it is a variable (see settings.c). */
extern u32 g_accent, g_accent_dk;
#define COL_GREEN     g_accent
#define COL_GREEN_DK  g_accent_dk
#define COL_TEXT      C2D_Color32(0xFF, 0xFF, 0xFF, 0xFF)
#define COL_SUBTEXT   C2D_Color32(0xB3, 0xB3, 0xB3, 0xFF)
#define COL_BAR_BG    C2D_Color32(0x4D, 0x4D, 0x4D, 0xFF)
#define COL_BLACK     C2D_Color32(0x00, 0x00, 0x00, 0xFF)

typedef enum {
    SCREEN_LIBRARY,
    SCREEN_ALBUM,
    SCREEN_PLAYING,
    SCREEN_VIDEOS,
    SCREEN_VIDEO,
    SCREEN_GAMES,
    SCREEN_GAME_SONGS,
    SCREEN_GAME,
    SCREEN_SETTINGS,
    SCREEN_COVER_PICK
} Screen;

typedef enum {
    REPEAT_OFF,
    REPEAT_ALL,
    REPEAT_ONE
} RepeatMode;

typedef struct {
    char path[MAX_PATH];
    char title[MAX_NAME];
    int  trackNo;
} Track;

typedef struct {
    char  folder[MAX_PATH];
    char  title[MAX_NAME];
    char  artist[MAX_NAME];
    char  coverPath[MAX_PATH];
    Track tracks[MAX_TRACKS_PER_ALBUM];
    int   trackCount;
} Album;

typedef struct {
    char path[MAX_PATH];
    char title[MAX_NAME];
} Video;

typedef struct {
    Album albums[MAX_ALBUMS];
    int   albumCount;
    Video videos[MAX_VIDEOS];
    int   videoCount;
} Library;

/* Small helpers shared across modules. */
static inline int clampi(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

void path_join(char *out, size_t n, const char *a, const char *b);
void strip_ext(char *s);
const char *path_basename(const char *p);
bool file_exists(const char *p);

#endif