# Crear minijuegos para 3dSpotiLocal

Un juego es una carpeta en `~/3dSpotiLocal/Games/` con un archivo `main.lua`. Aparece en la pestaña **Juegos**
después de los integrados. Copiá `plantilla/` y editala. Al tocar **Ajustes → Recargar biblioteca** se vuelve a escanear
(o reiniciá la app). Si el script tiene un error, la pantalla muestra el mensaje con archivo y línea; **B** vuelve al menú.

## Estructura

```lua
GAME = { title = "Nombre en el menu", description = "Una linea" }   -- opcional

function init() end             -- una vez, al abrir
function update(dt) end         -- cada frame (dt en segundos)
function draw_top() end         -- pantalla de arriba: 400 x 240
function draw_bottom() end      -- pantalla tactil: 320 x 240
function touch(x, y) end        -- opcional: se llama al apoyar el lapiz/mouse
```
Todas son opcionales. **B** sale al menú y **START** pausa (los maneja el motor, no los uses para otra cosa).
Fuera de las funciones solo definí variables; no dibujes ni leas entrada al cargar el archivo.
Constantes: `TOP_W, TOP_H = 400, 240` y `BOT_W, BOT_H = 320, 240`.

## Colores

Un color es un número. `rgb(r, g, b [, a])` (0–255), `hex(0xRRGGBB [, a])`, `mix(c1, c2, t)`, `alpha(c, 0..1)`.
Hay una tabla `color` lista: `black white gray dark green blue pink orange red yellow purple cyan transparent`.

## Dibujo 2D (coordenadas en píxeles de la 3DS, `y` crece hacia abajo)

| Función | |
|---|---|
| `rect(x,y,w,h,c)` · `rrect(x,y,w,h,radio,c)` | rectángulo / con esquinas redondas |
| `circle(x,y,r,c)` · `ring(x,y,r,grosor,c)` | círculo / aro |
| `line(x1,y1,x2,y2,grosor,c)` · `tri(x1,y1,x2,y2,x3,y3,c)` | línea / triángulo |
| `gradient(x,y,w,h,c1,c2 [,horizontal])` | degradé |
| `shadow(x,y,w,h,radio [,expansion,alfa])` | sombra suave debajo de algo |
| `text(x,y,tam,c,"txt")` · `text_center(cx,...)` · `text_right(xDer,...)` | texto (`tam` ≈ 0.45 normal, 0.7 título) |
| `text_width("txt", tam)` | ancho del texto |
| `clip(x,y,w,h)` · `clip_reset()` | recortar el dibujo a un rectángulo |
| `additive(true/false)` | mezcla aditiva (brillos, partículas) |
| `load_image("sprite.png" [, pixelado])` → id | carga una imagen **de la carpeta del juego** |
| `sprite(id,x,y,w,h [,rot,flipX,flipY,tinte])` | dibuja la imagen (rot en grados) |
| `sprite_src(id, sx,sy,sw,sh, x,y,w,h [,rot,flipX,flipY,tinte])` | un recorte (hojas de sprites) |
| `image_size(id)` → w, h | |

## Entrada y utilidades

* `btn("a")` mantenido · `pressed("a")` recién apretado. Nombres: `a b x y l r start select up down left right`.
* `stick()` → `x, y` entre -1 y 1 (**arriba = -1**); responde a la cruceta, WASD y el stick del gamepad.
* `touch()` → `x, y` del lapiz/mouse en la pantalla de abajo (o `nil` si no toca).
* `time()` segundos desde que empezó · `quit()` vuelve al menú.
* `best()` mejor puntaje guardado · `submit_score(n)` lo guarda si es mayor (queda en la carpeta del juego).
* Helpers: `clamp, lerp, sign, dist, rnd(n) / rnd(a,b) / rnd(), collide_rect(ax,ay,aw,ah, bx,by,bw,bh), collide_circle(ax,ay,ar,bx,by,br), ease_out(t), ease_in_out(t)`.
* Lua completo: `math`, `string`, `table`, `utf8`, `coroutine`.

## 2.5D: raycaster (estilo Doom/Wolfenstein)

El mapa es una lista de strings: `.` o espacio = vacío, `#` = pared, `1`..`9` = paredes de colores.

```lua
local MAP = { "#####", "#...#", "#.#.#", "#...#", "#####" }
raycast(MAP, px, py, angulo, x, y, w, h [, fov=66, colorCielo, colorSuelo])   -- dibuja la vista en ese rectángulo
local d, celda = ray_dist(MAP, px, py, angulo)                                 -- distancia a la pared y su caracter
ray_billboard(px, py, angulo, objX, objY, tamano, color)                       -- un objeto (esfera) en el mundo
ray_sprite(px, py, angulo, objX, objY, tamano, idImagen)                       -- lo mismo con un sprite
```
`px, py` son coordenadas en celdas (la celda de la fila 1, columna 1 ocupa de 0 a 1). Llamá a `ray_billboard`/`ray_sprite`
**después** de `raycast`: las paredes los tapan correctamente. Mapa máximo 64×64. Ejemplo: `ejemplo_25d_laberinto`.

## 3D: cámara y cubos

Ejes: **x** derecha, **y** arriba, **z** adelante. `yaw = 0` mira hacia +z; subir `yaw` gira a la derecha; `pitch > 0` mira arriba.
Siempre en este orden: `scene3d(...)`, objetos, `scene3d_end()`.

```lua
scene3d(camX, camY, camZ, yaw, pitch, fov, vx, vy, vw, vh [, cieloArriba, cieloAbajo])
cube(x, y, z, anchoX, altoY, largoZ, color)             -- centrado en (x,y,z), sombreado por cara
floor3(cx, cz, tamano, baldosas, y, color1, color2)     -- piso de ajedrez
sphere3(x, y, z, radio, color)                          -- esfera sombreada
line3(x1,y1,z1, x2,y2,z2, color [, grosor])
quad3(x1,y1,z1, ..., x4,y4,z4, color)                   -- cuadrilatero libre (4 puntos en orden)
fog3(colorNiebla, distanciaMax)                         -- niebla (por defecto el color del horizonte, 60)
local sx, sy, profundidad = project3(x, y, z)           -- posición en pantalla (o nil si está detrás) para HUD/etiquetas
scene3d_end()
```
Las caras se ordenan de lejos a cerca (algoritmo del pintor): ideal para escenas de cubos y arenas; hasta 6000 piezas por frame.
Ejemplo: `ejemplo_3d_gemas`.

## Consejos

* Movimiento independiente del fps: multiplicá velocidades por `dt`.
* Para dibujar en las dos pantallas lo mismo (por ejemplo un HUD), hacé una función local y llamala desde ambas.
* Un script no puede tocar archivos ni ejecutar comandos (no existen `io`, `os`, `load`), y si un frame tarda demasiado
  (bucle infinito) se corta con un error en vez de colgar la app.
* Sonidos propios todavía no están soportados (la música de fondo sigue sonando mientras jugás).
