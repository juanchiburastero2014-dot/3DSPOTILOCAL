#!/bin/sh
# Instala lo necesario para compilar y usar 3dSpotiLocal. Uso: sh install_deps.sh
set -e
if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y build-essential pkg-config libsdl2-dev libfreetype-dev liblua5.4-dev ffmpeg
elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y gcc make pkgconf-pkg-config SDL2-devel freetype-devel lua-devel ffmpeg-free
elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -S --needed base-devel pkgconf sdl2 freetype2 lua ffmpeg
elif command -v zypper >/dev/null 2>&1; then
    sudo zypper install -y gcc make pkg-config SDL2-devel freetype2-devel lua54-devel ffmpeg
else
    echo "No reconoci tu gestor de paquetes. Necesitas: compilador C, make, pkg-config, SDL2, FreeType, Lua 5.4 (desarrollo) y ffmpeg."
    exit 1
fi
echo "Listo. Ahora: make && ./3dspotilocal"
