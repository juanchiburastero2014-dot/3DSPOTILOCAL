#!/bin/sh
# Builds 3dSpotiLocal.bnr from banner.png + banner.wav (needed only for the .cia).
# Looks for the `bannertool` binary in the project folder, linux-x86_64/, tools/, the PATH and ~/Descargas|Downloads.
# You can also pass its path:   tools/build_banner.sh /ruta/a/bannertool
cd "$(dirname "$0")/.." || exit 1

BT="$1"
if [ -z "$BT" ]; then
    for c in ./bannertool ./linux-x86_64/bannertool ./tools/bannertool \
             "$HOME/Descargas/linux-x86_64/bannertool" "$HOME/Descargas/bannertool" \
             "$HOME/Downloads/linux-x86_64/bannertool" "$HOME/Downloads/bannertool"; do
        if [ -f "$c" ]; then BT="$c"; break; fi
    done
fi
[ -z "$BT" ] && command -v bannertool >/dev/null 2>&1 && BT=bannertool
if [ -z "$BT" ]; then
    BT=$(find . "$HOME/Descargas" "$HOME/Downloads" -maxdepth 3 -name bannertool -type f 2>/dev/null | head -n 1)
fi
if [ -z "$BT" ]; then
    echo "No encuentro bannertool. Bajalo con estos comandos (version Linux):"
    echo "  wget https://github.com/diasurgical/bannertool/releases/download/1.2.0/bannertool.zip"
    echo "  unzip -j bannertool.zip linux-x86_64/bannertool -d ."
    echo "y volve a correr este script (o pasale la ruta: tools/build_banner.sh /ruta/a/bannertool)."
    exit 1
fi

[ -f "$BT" ] && chmod +x "$BT" 2>/dev/null
echo "Usando: $BT"
if "$BT" makebanner -i banner.png -a banner.wav -o 3dSpotiLocal.bnr; then
    echo "Listo: 3dSpotiLocal.bnr"
else
    echo "bannertool fallo. Si dice 'cannot execute' o 'not found', es que ese archivo no es el binario de Linux x86_64."
    exit 1
fi
