#!/usr/bin/env python3
"""Generate icon.png (48x48), banner.png (256x128) and banner.wav (HOME Menu jingle).

Needs Pillow and numpy:  pip install pillow numpy
The generated files are already included in the project, so you only need this to change the design.
"""
import math
import sys
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
GREEN = (29, 185, 84)
DEEP = (8, 70, 40)
FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
]


def font(size):
    for path in FONT_CANDIDATES:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def gradient(w, h, top, bottom, diagonal=True):
    y, x = np.mgrid[0:h, 0:w]
    t = ((x / max(w - 1, 1)) * 0.5 + (y / max(h - 1, 1)) * 0.5) if diagonal else (y / max(h - 1, 1))
    arr = np.zeros((h, w, 3), dtype=np.float32)
    for c in range(3):
        arr[..., c] = top[c] + (bottom[c] - top[c]) * t
    return Image.fromarray(arr.astype(np.uint8), "RGB")


def draw_note(d, cx, cy, s, color):
    """Beamed pair of eighth notes, centred on (cx, cy), about 1.0*s wide."""
    head_w, head_h = 0.30 * s, 0.22 * s
    stem_w = 0.075 * s
    lx, rx = cx - 0.30 * s, cx + 0.30 * s
    bottom = cy + 0.32 * s
    top = cy - 0.40 * s
    for hx in (lx, rx):
        d.ellipse([hx - head_w, bottom - head_h, hx + head_w * 0.9, bottom + head_h], fill=color)
        d.rectangle([hx + head_w * 0.9 - stem_w, top, hx + head_w * 0.9, bottom], fill=color)
    d.polygon([(lx + head_w * 0.9 - stem_w, top), (rx + head_w * 0.9, top - 0.06 * s),
               (rx + head_w * 0.9, top + 0.18 * s), (lx + head_w * 0.9 - stem_w, top + 0.24 * s)], fill=color)


def make_icon():
    k = 8
    size = 48 * k
    bg = gradient(size, size, (40, 214, 106), DEEP).convert("RGBA")
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle([2 * k, 2 * k, size - 2 * k, size - 2 * k], radius=10 * k, fill=255)
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    img.paste(bg, (0, 0), mask)
    d = ImageDraw.Draw(img)
    # soft highlight
    hi = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(hi).ellipse([-size * 0.2, -size * 0.55, size * 1.2, size * 0.45], fill=(255, 255, 255, 38))
    img = Image.alpha_composite(img, Image.composite(hi, Image.new("RGBA", (size, size), (0, 0, 0, 0)), mask))
    d = ImageDraw.Draw(img)
    # sound arcs behind the note
    for r, a in ((19, 90), (14, 140)):
        d.arc([size / 2 - r * k, size / 2 - r * k, size / 2 + r * k, size / 2 + r * k], 200, 340, fill=(255, 255, 255, a), width=int(1.6 * k))
    shadow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw_note(ImageDraw.Draw(shadow), size / 2 + 0.6 * k, size / 2 + 1.4 * k, 30 * k, (0, 0, 0, 110))
    img = Image.alpha_composite(img, shadow.filter(ImageFilter.GaussianBlur(1.2 * k)))
    draw_note(ImageDraw.Draw(img), size / 2, size / 2 + 0.8 * k, 30 * k, (255, 255, 255, 255))
    img.resize((48, 48), Image.LANCZOS).save(ROOT / "icon.png")


def make_banner():
    k = 4
    w, h = 256 * k, 128 * k
    img = gradient(w, h, (10, 12, 18), (10, 52, 40)).convert("RGBA")
    d = ImageDraw.Draw(img)
    # equalizer strip along the bottom, kept clear of the text
    rng = np.random.default_rng(7)
    base = h - 6 * k
    for i in range(32):
        bh = int((4 + 11 * abs(math.sin(i * 0.55 + 0.8)) + 2 * rng.random()) * k)
        x0 = int((6 + i * 7.8) * k)
        shade = int(70 + 150 * (i / 31))
        d.rounded_rectangle([x0, base - bh, x0 + 5 * k, base], radius=2 * k, fill=(29, 185, 84, shade))
    # badge
    cx, cy, r = 56 * k, 50 * k, 33 * k
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([cx - r - 10 * k, cy - r - 10 * k, cx + r + 10 * k, cy + r + 10 * k], fill=(29, 185, 84, 110))
    img = Image.alpha_composite(img, glow.filter(ImageFilter.GaussianBlur(9 * k)))
    badge = gradient(2 * r, 2 * r, (40, 214, 106), DEEP).convert("RGBA")
    m = Image.new("L", (2 * r, 2 * r), 0)
    ImageDraw.Draw(m).ellipse([0, 0, 2 * r - 1, 2 * r - 1], fill=255)
    img.paste(badge, (cx - r, cy - r), m)
    d = ImageDraw.Draw(img)
    draw_note(d, cx + 0.5 * k, cy + 1.5 * k, 42 * k, (255, 255, 255, 255))
    # title
    f1, f3 = font(30 * k), font(10 * k)
    x = 104 * k
    d.text((x, 10 * k), "3D", font=f1, fill=(29, 220, 100, 255))
    x2 = x + d.textlength("3D", font=f1)
    d.text((x2, 10 * k), "Spoti", font=f1, fill=(255, 255, 255, 255))
    d.text((x, 42 * k), "Local", font=f1, fill=(255, 255, 255, 255))
    d.rounded_rectangle([x, 84 * k, x + 112 * k, 86 * k], radius=k, fill=(29, 185, 84, 255))
    d.text((x, 90 * k), "musica  video  juegos", font=f3, fill=(190, 205, 198, 255))
    img.convert("RGB").resize((256, 128), Image.LANCZOS).save(ROOT / "banner.png")


def make_jingle():
    sr = 32000
    dur = 2.7
    n = int(sr * dur)
    t = np.arange(n) / sr
    out = np.zeros(n, dtype=np.float64)

    def bell(freq, start, length, amp):
        i0 = int(start * sr)
        m = min(int(length * sr), n - i0)
        if m <= 0:
            return
        tt = np.arange(m) / sr
        env = np.minimum(tt / 0.006, 1.0) * np.exp(-tt * 3.2)
        tone = (np.sin(2 * np.pi * freq * tt) + 0.42 * np.sin(2 * np.pi * freq * 2.005 * tt) * np.exp(-tt * 4)
                + 0.18 * np.sin(2 * np.pi * freq * 3.01 * tt) * np.exp(-tt * 7))
        out[i0:i0 + m] += amp * env * tone

    # rising Cmaj9 arpeggio, then a bright resolved chord
    notes = [523.25, 659.25, 783.99, 987.77, 1174.66]
    for i, f in enumerate(notes):
        bell(f, 0.10 + i * 0.13, 1.6, 0.42)
    for f, a in ((523.25, 0.34), (659.25, 0.30), (783.99, 0.30), (1046.5, 0.30), (1318.5, 0.22)):
        bell(f, 0.92, 1.7, a)
    # warm pad under everything
    pad = (np.sin(2 * np.pi * 130.81 * t) + 0.6 * np.sin(2 * np.pi * 196.0 * t) + 0.4 * np.sin(2 * np.pi * 261.63 * t))
    out += 0.11 * pad * np.minimum(t / 0.5, 1.0) * np.exp(-np.maximum(t - 0.9, 0) * 1.5)
    # little echo
    d = int(0.19 * sr)
    echo = np.zeros(n)
    echo[d:] = out[:-d] * 0.33
    out += echo
    out *= np.minimum(1.0, (dur - t) / 0.35)           # fade out, no click at the end
    out = np.tanh(out * 1.2)                           # gentle limiter
    out = out / np.max(np.abs(out)) * 0.82
    pcm = (out * 32767).astype("<i2")
    with wave.open(str(ROOT / "banner.wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


if __name__ == "__main__":
    make_icon()
    make_banner()
    make_jingle()
    print("Generated icon.png, banner.png and banner.wav in", ROOT)
