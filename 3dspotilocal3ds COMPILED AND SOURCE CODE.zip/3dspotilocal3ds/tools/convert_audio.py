#!/usr/bin/env python3
"""Convert audio the player cannot read (m4a, aac, opus, wma, alac, ...) to .ogg or .mp3.

Natively supported by the 3DS app: .mp3  .wav  .ogg (Vorbis)  .flac

  python3 convert_audio.py cancion.m4a                 # -> cancion.ogg next to it
  python3 convert_audio.py carpeta/ --format mp3       # every audio file in a folder
"""
import argparse
import shutil
import subprocess
from pathlib import Path

NATIVE = {".mp3", ".wav", ".ogg", ".oga", ".flac"}
CONVERT = {".m4a", ".aac", ".opus", ".wma", ".mp4", ".mka", ".webm", ".ape", ".aiff", ".aif", ".alac", ".mkv"}


def convert(src: Path, fmt: str, rate: int) -> None:
    dst = src.with_suffix("." + fmt)
    if dst.exists():
        print(f"skip (exists): {dst.name}")
        return
    codec = ["-c:a", "libvorbis", "-q:a", "5"] if fmt == "ogg" else ["-c:a", "libmp3lame", "-q:a", "2"]
    cmd = ["ffmpeg", "-v", "error", "-nostdin", "-i", str(src), "-vn", "-ac", "2", "-ar", str(rate), *codec, str(dst)]
    if subprocess.run(cmd).returncode:
        dst.unlink(missing_ok=True)
        print(f"FAILED: {src.name}")
    else:
        print(f"ok: {dst.name}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=Path)
    p.add_argument("--format", choices=["ogg", "mp3"], default="ogg")
    p.add_argument("--rate", type=int, default=44100)
    args = p.parse_args()
    if not shutil.which("ffmpeg"):
        p.error("Install FFmpeg first.")
    files = sorted(args.path.rglob("*")) if args.path.is_dir() else [args.path]
    todo = [f for f in files if f.is_file() and f.suffix.lower() in CONVERT]
    if not todo:
        print("Nothing to convert (mp3/wav/ogg/flac already play natively).")
    for f in todo:
        convert(f, args.format, args.rate)


if __name__ == "__main__":
    main()
