#!/usr/bin/env python3
"""Convert local videos to 3dSpotiLocal RGB565 + stereo PCM containers."""
import argparse
import json
import math
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile

HEADER = struct.Struct("<4sHHHHIIHHIII")
MAX_FILE_SIZE = 0x7FFFFFFF


def run(cmd, out_path):
    with open(out_path, "wb") as output:
        proc = subprocess.run(cmd, stdout=output, stderr=subprocess.PIPE)
    if proc.returncode:
        raise SystemExit(proc.stderr.decode("utf-8", "replace"))


def main():
    parser = argparse.ArgumentParser(description="Convert video to 3dSpotiLocal .v3v")
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--fps", type=int, default=15)
    parser.add_argument("--width", type=int, default=400)
    parser.add_argument("--height", type=int, default=240)
    parser.add_argument("--arate", type=int, default=32000)
    args = parser.parse_args()

    if not 1 <= args.width <= 512 or not 1 <= args.height <= 256:
        parser.error("Resolution must be between 1x1 and 512x256.")
    if not 1 <= args.fps <= 30:
        parser.error("Frame rate must be between 1 and 30.")
    if not 8000 <= args.arate <= 48000:
        parser.error("Audio rate must be between 8000 and 48000 Hz.")
    if not args.input.is_file():
        parser.error("Input video does not exist.")
    if args.input.resolve() == args.output.resolve():
        parser.error("Input and output must be different files.")
    if args.output.exists():
        parser.error("Output already exists; choose a new filename.")
    if not args.output.parent.is_dir():
        parser.error("Output directory does not exist.")
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        parser.error("Install FFmpeg (ffmpeg and ffprobe must be on PATH).")

    probe = subprocess.run([
        "ffprobe", "-v", "error", "-show_entries",
        "stream=codec_type,duration:format=duration", "-of", "json",
        str(args.input.resolve()),
    ], capture_output=True, text=True)
    if probe.returncode:
        raise SystemExit(probe.stderr)
    metadata = json.loads(probe.stdout)
    streams = metadata.get("streams", [])
    video = next((stream for stream in streams if stream.get("codec_type") == "video"), None)
    if video is None:
        parser.error("Input file has no video stream.")
    has_audio = any(stream.get("codec_type") == "audio" for stream in streams)

    w, h, fps, arate = args.width, args.height, args.fps, args.arate
    frame_bytes = w * h * 2
    output_dir = args.output.parent.resolve()
    duration_estimate = None
    for value in (video.get("duration"), metadata.get("format", {}).get("duration")):
        try:
            seconds = float(value)
        except (TypeError, ValueError):
            continue
        if math.isfinite(seconds) and seconds > 0:
            duration_estimate = seconds
            break
    if duration_estimate is not None:
        estimated_frames = math.ceil(duration_estimate * fps)
        estimated_audio = math.ceil(estimated_frames * arate / fps) * 4 if has_audio else 0
        estimated_size = HEADER.size + estimated_frames * frame_bytes + estimated_audio
        if estimated_size > MAX_FILE_SIZE:
            parser.error(
                f"Estimated output is {estimated_size / 1e9:.2f} GB; player limit is 2 GiB. "
                "Reduce --width, --height or --fps, or split the video before converting.")
        # The raw streams and final container coexist while the output is copied.
        required_space = estimated_size * 2 + 64 * 1024 * 1024
        free_space = shutil.disk_usage(output_dir).free
        if required_space > free_space:
            parser.error(
                f"Conversion needs about {required_space / 1e9:.2f} GB free in {output_dir}; "
                f"only {free_space / 1e9:.2f} GB is available. Choose another output drive "
                "or reduce resolution/fps.")

    vf = (f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
          f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,fps={fps},setsar=1")

    with tempfile.TemporaryDirectory(prefix="3dspotilocal_", dir=output_dir) as tmpdir:
        vpath = os.path.join(tmpdir, "video.raw")
        apath = os.path.join(tmpdir, "audio.raw")
        print(f"[1/3] Video: {w}x{h} @ {fps} fps")
        run(["ffmpeg", "-v", "error", "-nostdin", "-i", str(args.input.resolve()),
             "-map", "0:v:0", "-an", "-vf", vf, "-pix_fmt", "rgb565le",
             "-f", "rawvideo", "pipe:1"], vpath)
        vsize = os.path.getsize(vpath)
        frame_count = vsize // frame_bytes
        if not frame_count or vsize % frame_bytes:
            raise SystemExit("No complete video frames were produced.")
        duration = frame_count / fps
        audio_estimate = math.ceil(duration * arate) * 4 if has_audio else 0
        if HEADER.size + vsize + audio_estimate > MAX_FILE_SIZE:
            raise SystemExit("Video exceeds the 2 GiB player limit; reduce resolution/fps or split it.")

        print(f"[2/3] Audio: {arate} Hz, stereo PCM")
        if has_audio:
            run(["ffmpeg", "-v", "error", "-nostdin", "-i", str(args.input.resolve()),
                 "-map", "0:a:0", "-vn", "-ac", "2", "-ar", str(arate),
                 "-af", "apad", "-t", f"{duration:.9f}", "-f", "s16le", "pipe:1"], apath)
        else:
            Path(apath).touch()

        asize = os.path.getsize(apath)
        if asize % 4 or HEADER.size + vsize + asize > MAX_FILE_SIZE:
            raise SystemExit("Invalid PCM output or container exceeds the 2 GiB player limit.")
        header = HEADER.pack(b"V3V1", w, h, fps, 0, frame_count, arate,
                             2, 0, asize // 4, vsize, asize)
        print(f"[3/3] Writing {args.output}: {duration:.1f}s, {(vsize + asize) / 1e6:.1f} MB")
        with args.output.open("xb") as output:
            output.write(header)
            for path in (vpath, apath):
                with open(path, "rb") as source:
                    shutil.copyfileobj(source, output, 1024 * 1024)
        print("Copy the .v3v to /3dSpotiLocal/Videos/ on your SD card.")


if __name__ == "__main__":
    main()
