#!/usr/bin/env python3
"""Convert any video (mp4, mkv, webm, mov, ...) to a Motion JPEG .avi for 3dSpotiLocal.

The 3DS cannot decode H.264 in real time from homebrew, but it can decode small
JPEG frames, so we re-encode to MJPEG + 16-bit PCM audio, which is what the
player's AVI reader accepts.

  python3 convert_to_avi.py peli.mp4 peli.avi                # Old 3DS friendly (320x180, 15 fps)
  python3 convert_to_avi.py peli.mp4 peli.avi --new3ds       # 400x240, 20 fps
  python3 convert_to_avi.py peli.mp4 peli.avi --quality 4    # better picture, bigger file
  python3 convert_to_avi.py peli.mp4 peli.avi --fast         # smoother on the original 3DS/2DS (256x144, 12 fps)

If the video looks choppy on your console, the JPEG decoder cannot keep up: use --fast, a smaller
size (--width 256 --height 144) or fewer frames per second (--fps 10). A smaller picture decodes much faster.
"""
import argparse
import shutil
import subprocess
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description="Convert video to 3dSpotiLocal Motion JPEG .avi")
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--new3ds", action="store_true", help="400x240 @ 20 fps (New 3DS / New 2DS XL)")
    p.add_argument("--fast", action="store_true", help="256x144 @ 12 fps: smoothest on the original 3DS/2DS")
    p.add_argument("--width", type=int)
    p.add_argument("--height", type=int)
    p.add_argument("--fps", type=int)
    p.add_argument("--quality", type=int, default=6, help="JPEG quality 2 (best) .. 15 (smallest), default 6")
    p.add_argument("--arate", type=int, default=32000, help="audio sample rate, 8000..48000")
    args = p.parse_args()

    if args.fast:
        dw, dh, dfps = 256, 144, 12
    elif args.new3ds:
        dw, dh, dfps = 400, 240, 20
    else:
        dw, dh, dfps = 320, 180, 15
    w = args.width or dw
    h = args.height or dh
    fps = args.fps or dfps
    if not (1 <= w <= 512 and 1 <= h <= 256):
        p.error("Resolution must be at most 512x256.")
    if not 1 <= fps <= 30:
        p.error("fps must be between 1 and 30.")
    if not 2 <= args.quality <= 31:
        p.error("quality must be between 2 and 31.")
    if not 8000 <= args.arate <= 48000:
        p.error("audio rate must be between 8000 and 48000.")
    if not args.input.is_file():
        p.error("Input file does not exist.")
    if args.output.exists():
        p.error("Output already exists; choose a new name.")
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        p.error("Install FFmpeg (ffmpeg and ffprobe must be on PATH).")

    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(args.input)],
        capture_output=True, text=True)
    types = probe.stdout.split()
    if probe.returncode or "video" not in types:
        raise SystemExit(probe.stderr or "Input file has no video stream.")
    has_audio = "audio" in types

    vf = (f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
          f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,fps={fps},setsar=1")
    cmd = ["ffmpeg", "-v", "error", "-nostdin", "-i", str(args.input), "-map", "0:v:0"]
    if has_audio:
        cmd += ["-map", "0:a:0"]
    # No OpenDML index, MJPEG video and plain PCM audio: the simple layout the player expects.
    cmd += ["-vf", vf, "-c:v", "mjpeg", "-pix_fmt", "yuvj420p", "-q:v", str(args.quality)]
    if has_audio:
        cmd += ["-c:a", "pcm_s16le", "-ar", str(args.arate), "-ac", "2"]
    cmd += ["-f", "avi", str(args.output)]

    print(f"Converting to {w}x{h} @ {fps} fps, quality {args.quality} ...")
    if subprocess.run(cmd).returncode:
        args.output.unlink(missing_ok=True)
        raise SystemExit("ffmpeg failed.")
    size = args.output.stat().st_size
    if size >= 0x7FFFFFFF:
        args.output.unlink()
        raise SystemExit("Result is over 2 GiB (player limit). Lower --quality / size / fps or split the video.")
    print(f"Done: {args.output} ({size / 1e6:.1f} MB). Copy it to /3dSpotiLocal/Videos/ on the SD card.")


if __name__ == "__main__":
    main()
