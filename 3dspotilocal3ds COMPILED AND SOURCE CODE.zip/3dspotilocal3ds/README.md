# 3dSpotiLocal — v4

Reproductor local de música y video para Nintendo 3DS con interfaz estilo Spotify, ajustes, letras, carátulas y minijuegos.

## Compilar
Necesitás devkitPro (devkitARM + libctru + citro2d/citro3d).

    export DEVKITPRO=/opt/devkitpro DEVKITARM=/opt/devkitpro/devkitARM
    make 3dsx        # 3dSpotiLocal.3dsx (Homebrew Launcher), ya con el ícono nuevo

Para el `.cia` además hace falta:

    tools/build_banner.sh   # crea 3dSpotiLocal.bnr (necesita bannertool: el script te dice como bajarlo)
    make cia                # necesita 'makerom' en el PATH

El diseño del ícono, el banner y el sonido del banner se redibuja con `make assets` (Pillow + numpy); ya vienen hechos.

## Tarjeta SD
    /3dSpotiLocal/Music/<Artista - Álbum>/*.mp3|wav|ogg|flac
    /3dSpotiLocal/Videos/*.avi (Motion JPEG) o *.v3v
    /3dSpotiLocal/Covers/*.jpg|png|bmp     imágenes para elegir como carátula dentro de la app
    /3dSpotiLocal/Lyrics/<canción>.txt     letras (opcional, también pueden ir junto a la canción)
    /3dSpotiLocal/settings.cfg, covers.cfg  los crea la app
Hace falta `/3ds/dspfirm.cdc` para el audio.

## Pestañas (Y cambia de una a otra, o tocá la barra de abajo)
**Música · Videos · Juegos · Ajustes**

### Idiomas
Español, English (US / UK / AU), Português (BR), Deutsch, Русский, Français e Italiano. La primera vez se elige solo según el idioma de la consola (y la región para el inglés); se cambia en **Ajustes → Idioma** (primera fila). Los textos están en `tools/translations.py`; después de editarlos corré `python3 tools/gen_i18n.py` para regenerar `source/i18n_data.h`.

### Ajustes
Idioma, volume booster (100–300 %, por software con limitador), letras automáticas, dificultad de los juegos, música de fondo en los juegos, color de acento, mezclar/repetir al iniciar, recargar la biblioteca y restaurar ajustes.

### Letras
Poné un `.txt` con el mismo nombre que la canción (`01 Tema.mp3` → `01 Tema.txt`) junto a ella, o en `/3dSpotiLocal/Lyrics/`. Si las líneas empiezan con `[mm:ss]` o `[mm:ss.xx]` (formato LRC) se sincronizan solas; si no, la letra avanza según el progreso y podés ajustarla con la cruceta arriba/abajo. En la pantalla de reproducción, **X** (o tocar "Letra") muestra u oculta la letra.

### Carátulas
- Álbum: `cover.jpg|png|bmp`, `folder.jpg`, `front.jpg`, `album.jpg`… dentro de la carpeta, **o** abrí el álbum y apretá **X** para elegir una imagen de `/3dSpotiLocal/Covers/`.
- Canción: un `.jpg|png|bmp` con el mismo nombre que la canción, **o** en el álbum seleccioná la canción y apretá **Y** para elegir una imagen.
- Lo elegido en la app se guarda en `covers.cfg`; "Automática" lo quita.

## Formatos
| Tipo  | Directo en la 3DS            | Con conversor                                  |
|-------|------------------------------|------------------------------------------------|
| Audio | mp3, wav, ogg, flac          | `tools/convert_audio.py` (m4a, aac, opus, wma) |
| Video | avi Motion JPEG, v3v         | `tools/convert_to_avi.py` (mp4, mkv, webm, mov)|

### Video: orientación y fluidez
- Si un video se ve al revés o en espejo: **Ajustes → Probar orientación del video** muestra una **F** con esquinas de colores (rojo arriba a la izquierda). Apretá **X** hasta que se vea bien; también podés apretar **X** mientras mirás cualquier video. Se guarda.
- Si se ve entrecortado, la 3DS no llega a decodificar los cuadros: convertí con `python3 tools/convert_to_avi.py in.mp4 out.avi --fast` (256x144, 12 fps) o bajá `--fps`/el tamaño. La 3DS original es la más lenta; la New 3DS aguanta `--new3ds`.

## Minijuegos (23)
- Con tu música: **Pulso de cuatro** (tipo Guitar Hero) y **Cubo y nave** (tipo Geometry Dash).
- Clásicos: **Bloques 8x8** (Block Blast), **Caída de bloques** (Tetris), **Salto verde** (Mario).
- 3D: **Mundo de cubos** (mini Minecraft) y **Laberinto robot** (tipo Doom).
- Arcade: **Serpiente**, **2048**, **Rompe ladrillos**, **Pajarito** (tipo Flappy), **Buscaminas** e **Invasores**.
- Y 10 más: **Pong**, **Topos**, **Memoria**, **Simon dice**, **Ta-Te-Ti**, **4 en línea** (contra la consola), **Asteroides**, **Dino corredor**, **Luces** y **Puzzle 15**.
Durante la partida: START pausa, X reinicia, B vuelve al menú. Los récords se guardan.
