#include "audio.h"
#include <ctype.h>
#include <limits.h>

#define MINIMP3_NO_STDIO
#include "minimp3_ex.h"

#define DR_FLAC_IMPLEMENTATION
#include "dr_flac.h"

#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

/* stb_vorbis.c is a full implementation translation unit. */
#include "stb_vorbis.c"

typedef enum { FMT_MP3, FMT_WAV, FMT_OGG, FMT_FLAC } Format;

struct AudioStream {
    Format      fmt;
    int         rate;
    int         channels;
    u64         totalFrames;
    s16        *tmp;
    mp3dec_ex_t mp3;
    mp3dec_io_t mp3io;
    FILE       *mp3file;
    drflac     *flac;
    drwav       wav;
    bool        wavReady;
    stb_vorbis *ogg;
};

static bool ext_is(const char *path, const char *ext) {
    const char *dot = strrchr(path, '.');
    if (!dot) return false;
    dot++;
    for (size_t i = 0; dot[i] && ext[i]; i++)
        if (tolower((unsigned char)dot[i]) != tolower((unsigned char)ext[i])) return false;
    return strlen(dot) == strlen(ext);
}

static void to_stereo(s16 *out, const s16 *in, int srcCh, size_t frames) {
    if (srcCh == 2) {
        memcpy(out, in, frames * 2 * sizeof(s16));
    } else if (srcCh == 1) {
        for (size_t i = 0; i < frames; i++) {
            s16 v = in[i];
            out[2 * i] = v;
            out[2 * i + 1] = v;
        }
    } else {
        for (size_t i = 0; i < frames; i++) {
            out[2 * i]     = in[i * srcCh];
            out[2 * i + 1] = in[i * srcCh + 1];
        }
    }
}

static size_t mp3_read_file(void *buffer, size_t size, void *file) {
    return fread(buffer, 1, size, file);
}

static int mp3_seek_file(uint64_t offset, void *file) {
    if (offset > LONG_MAX) return -1;
    return fseek(file, (long)offset, SEEK_SET);
}

AudioStream *audio_open(const char *path) {
    AudioStream *s = (AudioStream *)calloc(1, sizeof(AudioStream));
    if (!s) return NULL;

    if (ext_is(path, "mp3")) {
        s->fmt = FMT_MP3;
        s->mp3file = fopen(path, "rb");
        if (!s->mp3file) goto fail;
        s->mp3io = (mp3dec_io_t){mp3_read_file, s->mp3file, mp3_seek_file, s->mp3file};
        if (mp3dec_ex_open_cb(&s->mp3, &s->mp3io, MP3D_SEEK_TO_SAMPLE) != 0) goto fail;
        s->rate = s->mp3.info.hz;
        s->channels = s->mp3.info.channels;
        s->totalFrames = s->channels ? s->mp3.samples / s->channels : 0;
    } else if (ext_is(path, "wav")) {
        s->fmt = FMT_WAV;
        if (!drwav_init_file(&s->wav, path, NULL)) goto fail;
        s->wavReady = true;
        s->rate = s->wav.sampleRate;
        s->channels = s->wav.channels;
        s->totalFrames = s->wav.totalPCMFrameCount;
    } else if (ext_is(path, "ogg") || ext_is(path, "oga")) {
        s->fmt = FMT_OGG;
        int err = 0;
        s->ogg = stb_vorbis_open_filename(path, &err, NULL);
        if (!s->ogg) goto fail;
        s->rate = s->ogg->sample_rate;
        s->channels = s->ogg->channels;
        s->totalFrames = stb_vorbis_stream_length_in_samples(s->ogg);
    } else if (ext_is(path, "flac")) {
        s->fmt = FMT_FLAC;
        s->flac = drflac_open_file(path, NULL);
        if (!s->flac) goto fail;
        s->rate = s->flac->sampleRate;
        s->channels = s->flac->channels;
        s->totalFrames = s->flac->totalPCMFrameCount;
    } else {
        goto fail;
    }

    if (s->rate <= 0 || s->channels <= 0) goto fail;
    if (s->fmt != FMT_OGG) {
        s->tmp = (s16 *)malloc(AUDIO_CHUNK_FRAMES * s->channels * sizeof(s16));
        if (!s->tmp) goto fail;
    }
    return s;

fail:
    audio_close(s);
    return NULL;
}

void audio_close(AudioStream *s) {
    if (!s) return;
    switch (s->fmt) {
        case FMT_MP3:  mp3dec_ex_close(&s->mp3); break;
        case FMT_WAV:  if (s->wavReady) drwav_uninit(&s->wav); break;
        case FMT_OGG:  if (s->ogg) stb_vorbis_close(s->ogg); break;
        case FMT_FLAC: if (s->flac) drflac_close(s->flac); break;
    }
    if (s->mp3file) fclose(s->mp3file);
    free(s->tmp);
    free(s);
}

int audio_sample_rate(const AudioStream *s) { return s->rate; }
u64 audio_total_frames(const AudioStream *s) { return s->totalFrames; }

u64 audio_tell(const AudioStream *s) {
    switch (s->fmt) {
        case FMT_MP3:  return s->channels ? s->mp3.cur_sample / s->channels : 0;
        case FMT_WAV:  return s->wav.readCursorInPCMFrames;
        case FMT_OGG: {
            int offset = stb_vorbis_get_sample_offset(s->ogg);
            return offset < 0 ? 0 : (u64)offset;
        }
        case FMT_FLAC: return s->flac->currentPCMFrame;
    }
    return 0;
}

bool audio_seek(AudioStream *s, u64 frame) {
    switch (s->fmt) {
        case FMT_MP3:  return mp3dec_ex_seek(&s->mp3, frame * s->channels) == 0;
        case FMT_WAV:  return drwav_seek_to_pcm_frame(&s->wav, frame) != 0;
        case FMT_OGG:  return stb_vorbis_seek(s->ogg, (unsigned int)frame) != 0;
        case FMT_FLAC: return drflac_seek_to_pcm_frame(s->flac, frame) != 0;
    }
    return false;
}

size_t audio_read(AudioStream *s, s16 *out, size_t maxFrames) {
    if (maxFrames > AUDIO_CHUNK_FRAMES) maxFrames = AUDIO_CHUNK_FRAMES;
    size_t frames = 0;
    switch (s->fmt) {
        case FMT_MP3: {
            size_t got = mp3dec_ex_read(&s->mp3, s->tmp, maxFrames * s->channels);
            frames = s->channels ? got / s->channels : 0;
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        }
        case FMT_WAV:
            frames = (size_t)drwav_read_pcm_frames_s16(&s->wav, maxFrames, s->tmp);
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        case FMT_FLAC:
            frames = (size_t)drflac_read_pcm_frames_s16(s->flac, maxFrames, s->tmp);
            to_stereo(out, s->tmp, s->channels, frames);
            break;
        case FMT_OGG:
            frames = (size_t)stb_vorbis_get_samples_short_interleaved(s->ogg, 2, out, (int)(maxFrames * 2));
            break;
    }
    return frames;
}

/* ------------------------------------------------------------------ */
/* NDSP streaming output                                              */
/* ------------------------------------------------------------------ */

#define CHN 0

static AudioStream *dec = NULL;
static int   rate = 44100;
static s16  *pcm[AUDIO_NBUFFERS];
static ndspWaveBuf wbuf[AUDIO_NBUFFERS];
static bool  eofReached = false;
static bool  active = false;
static bool  paused = false;
static u64   baseFrame = 0;
static u64   startMs = 0;
static u64   pausedMs = 0;
static u64   pauseStartMs = 0;

bool audio_out_init(void) {
    if (R_FAILED(ndspInit())) return false;
    ndspSetMasterVol(1.0f);
    for (int i = 0; i < AUDIO_NBUFFERS; i++) {
        pcm[i] = (s16 *)linearMemAlign(AUDIO_CHUNK_FRAMES * 2 * sizeof(s16), 0x20);
        if (!pcm[i]) {
            for (int j = 0; j < i; j++) { linearFree(pcm[j]); pcm[j] = NULL; }
            ndspExit();
            return false;
        }
        memset(&wbuf[i], 0, sizeof(wbuf[i]));
    }
    return true;
}

void audio_out_exit(void) {
    audio_out_stop();
    for (int i = 0; i < AUDIO_NBUFFERS; i++)
        if (pcm[i]) linearFree(pcm[i]);
    ndspExit();
}

static float gainValue = 1.0f;

void audio_set_gain(float gain) {
    if (gain < 1.0f) gain = 1.0f;
    if (gain > 4.0f) gain = 4.0f;
    gainValue = gain;
}

void audio_apply_gain(s16 *p, size_t frames) {
    if (gainValue <= 1.001f || !p) return;
    int g = (int)(gainValue * 256.0f);
    for (size_t i = 0; i < frames * 2; i++) {
        int v = ((int)p[i] * g) >> 8;
        int a = v < 0 ? -v : v;
        if (a > 24000) {                       /* soft knee instead of harsh clipping */
            a = 24000 + (a - 24000) / 4;
            if (a > 32767) a = 32767;
            v = v < 0 ? -a : a;
        }
        p[i] = (s16)v;
    }
}

static void fill_buffer(int i) {
    size_t frames = audio_read(dec, pcm[i], AUDIO_CHUNK_FRAMES);
    if (frames == 0) {
        eofReached = true;
        wbuf[i].status = NDSP_WBUF_FREE;
        wbuf[i].nsamples = 0;
        return;
    }
    audio_apply_gain(pcm[i], frames);
    wbuf[i].data_pcm16 = pcm[i];
    wbuf[i].nsamples = (u32)frames;
    wbuf[i].looping = false;
    wbuf[i].status = NDSP_WBUF_FREE;
    DSP_FlushDataCache(pcm[i], (u32)(frames * 2 * sizeof(s16)));
    ndspChnWaveBufAdd(CHN, &wbuf[i]);
}

bool audio_out_start(AudioStream *s) {
    if (!s) return false;
    audio_out_stop();
    dec = s;
    rate = audio_sample_rate(s);

    ndspChnReset(CHN);
    ndspChnSetInterp(CHN, NDSP_INTERP_LINEAR);
    ndspChnSetRate(CHN, (float)rate);
    ndspChnSetFormat(CHN, NDSP_FORMAT_STEREO_PCM16);
    float mix[12];
    memset(mix, 0, sizeof(mix));
    mix[0] = 1.0f;
    mix[1] = 1.0f;
    ndspChnSetMix(CHN, mix);

    eofReached = false;
    active = true;
    paused = false;
    baseFrame = audio_tell(s);
    startMs = osGetTime();
    pausedMs = 0;

    for (int i = 0; i < AUDIO_NBUFFERS; i++) {
        wbuf[i].status = NDSP_WBUF_FREE;
        fill_buffer(i);
    }
    ndspChnSetPaused(CHN, false);
    return true;
}

void audio_out_stop(void) {
    if (active) {
        ndspChnWaveBufClear(CHN);
        ndspChnReset(CHN);
    }
    for (int i = 0; i < AUDIO_NBUFFERS; i++) {
        wbuf[i].status = NDSP_WBUF_FREE;
        wbuf[i].nsamples = 0;
    }
    active = false;
    paused = false;
    eofReached = false;
    dec = NULL;
}

void audio_out_pause(bool pause) {
    if (!active) return;
    if (pause && !paused) {
        paused = true;
        pauseStartMs = osGetTime();
        ndspChnSetPaused(CHN, true);
    } else if (!pause && paused) {
        pausedMs += osGetTime() - pauseStartMs;
        paused = false;
        ndspChnSetPaused(CHN, false);
    }
}

bool audio_out_is_paused(void) { return paused; }

void audio_out_update(void) {
    if (!active) return;
    for (int i = 0; i < AUDIO_NBUFFERS; i++) {
        if (wbuf[i].status == NDSP_WBUF_DONE && !eofReached)
            fill_buffer(i);
        else if (wbuf[i].status == NDSP_WBUF_DONE && eofReached)
            wbuf[i].status = NDSP_WBUF_FREE;
    }
}

bool audio_out_finished(void) {
    if (!active || !eofReached) return false;
    for (int i = 0; i < AUDIO_NBUFFERS; i++)
        if (wbuf[i].status == NDSP_WBUF_QUEUED || wbuf[i].status == NDSP_WBUF_PLAYING)
            return false;
    return true;
}

u64 audio_out_position(void) {
    if (!active || !dec) return 0;
    u64 now = paused ? pauseStartMs : osGetTime();
    u64 elapsedMs = now - startMs - pausedMs;
    u64 pos = baseFrame + elapsedMs * (u64)rate / 1000;
    u64 total = audio_total_frames(dec);
    if (pos > total) pos = total;
    return pos;
}

bool audio_out_seek(u64 frame) {
    if (!active || !dec) return false;
    if (!audio_seek(dec, frame)) return false;
    ndspChnWaveBufClear(CHN);
    eofReached = false;
    for (int i = 0; i < AUDIO_NBUFFERS; i++) {
        wbuf[i].status = NDSP_WBUF_FREE;
        wbuf[i].nsamples = 0;
    }
    for (int i = 0; i < AUDIO_NBUFFERS; i++)
        fill_buffer(i);
    baseFrame = frame;
    startMs = osGetTime();
    pausedMs = 0;
    if (paused) {
        pauseStartMs = osGetTime();
        ndspChnSetPaused(CHN, true);
    } else {
        ndspChnSetPaused(CHN, false);
    }
    return true;
}

void audio_out_set_volume(float vol) {
    if (vol < 0) vol = 0;
    if (vol > 1) vol = 1;
    ndspSetMasterVol(vol);
}