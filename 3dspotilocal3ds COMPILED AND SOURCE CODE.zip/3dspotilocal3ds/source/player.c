#include "player.h"

void player_init(Player *p, Library *lib) {
    memset(p, 0, sizeof(*p));
    p->lib = lib;
    p->album = -1;
    p->track = -1;
    p->repeat = REPEAT_OFF;
}

void player_exit(Player *p) {
    player_stop(p);
}

Track *player_current(Player *p) {
    if (!p->active || p->album < 0 || p->album >= p->lib->albumCount) return NULL;
    Album *al = &p->lib->albums[p->album];
    if (p->track < 0 || p->track >= al->trackCount) return NULL;
    return &al->tracks[p->track];
}

Album *player_current_album(Player *p) {
    if (!p->active || p->album < 0 || p->album >= p->lib->albumCount) return NULL;
    return &p->lib->albums[p->album];
}

bool player_play_track(Player *p, int album, int track) {
    if (album < 0 || album >= p->lib->albumCount) return false;
    Album *al = &p->lib->albums[album];
    if (track < 0 || track >= al->trackCount) return false;

    player_stop(p);
    p->stream = audio_open(al->tracks[track].path);
    if (!p->stream) return false;
    if (!audio_out_start(p->stream)) {
        audio_close(p->stream);
        p->stream = NULL;
        return false;
    }
    p->album = album;
    p->track = track;
    p->active = true;
    return true;
}

void player_stop(Player *p) {
    audio_out_stop();
    if (p->stream) {
        audio_close(p->stream);
        p->stream = NULL;
    }
    p->active = false;
}

void player_toggle_pause(Player *p) {
    if (p->active) audio_out_pause(!audio_out_is_paused());
}

void player_next(Player *p) {
    if (!p->active) return;
    Album *al = &p->lib->albums[p->album];
    int next;
    if (p->shuffle && al->trackCount > 1) {
        do { next = rand() % al->trackCount; } while (next == p->track);
    } else {
        next = p->track + 1;
        if (next >= al->trackCount) {
            if (p->repeat == REPEAT_ALL) next = 0;
            else { player_stop(p); return; }
        }
    }
    player_play_track(p, p->album, next);
}

void player_prev(Player *p) {
    if (!p->active) return;
    if (player_position_ms(p) > 3000) {
        player_seek_ms(p, 0);
        return;
    }
    Album *al = &p->lib->albums[p->album];
    int prev = p->track - 1;
    if (prev < 0) {
        if (p->repeat == REPEAT_ALL) prev = al->trackCount - 1;
        else prev = 0;
    }
    player_play_track(p, p->album, prev);
}

void player_update(Player *p) {
    if (!p->active) return;
    audio_out_update();
    if (audio_out_finished()) {
        if (p->repeat == REPEAT_ONE) {
            audio_out_seek(0);
        } else {
            player_next(p);
        }
    }
}

bool player_seek_ms(Player *p, u64 ms) {
    if (!p->active || !p->stream) return false;
    int rate = audio_sample_rate(p->stream);
    if (rate <= 0) return false;
    u64 frame = ms * (u64)rate / 1000;
    u64 total = audio_total_frames(p->stream);
    if (frame > total) frame = total;
    return audio_out_seek(frame);
}

u64 player_position_ms(Player *p) {
    if (!p->active || !p->stream) return 0;
    int rate = audio_sample_rate(p->stream);
    if (rate <= 0) return 0;
    return audio_out_position() * 1000 / (u64)rate;
}

u64 player_duration_ms(Player *p) {
    if (!p->active || !p->stream) return 0;
    int rate = audio_sample_rate(p->stream);
    if (rate <= 0) return 0;
    return audio_total_frames(p->stream) * 1000 / (u64)rate;
}