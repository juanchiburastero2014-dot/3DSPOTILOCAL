#ifndef VIBRA_IMAGE_H
#define VIBRA_IMAGE_H

#include "common.h"

/* Returns a cached, GPU-ready image scaled to a square texture.
 * Returns {NULL,NULL} if the file cannot be loaded. */
C2D_Image image_get(const char *path);
void image_clear_all(void);

#endif