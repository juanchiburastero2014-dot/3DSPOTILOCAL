#include "games.h"
#include "gfx_ui.h"
#include "settings.h"
#include "i18n.h"
#include <math.h>

/* Ten more quick games: Pong, Whack-a-mole, Memory, Simon, Tic-tac-toe, Connect Four,
 * Asteroids, Dino runner, Lights Out and the 15 puzzle. Only one is active at a time. */

#define C_BG    C2D_Color32(16, 22, 30, 255)
#define C_PANEL C2D_Color32(30, 40, 54, 255)
#define C_LINE  C2D_Color32(52, 66, 84, 255)
#define C_RED   C2D_Color32(240, 84, 84, 255)
#define C_GOLD  C2D_Color32(250, 204, 70, 255)
#define C_BLUE  C2D_Color32(80, 160, 240, 255)
#define C_WHITE C2D_Color32(255, 255, 255, 255)
#define C_INK   C2D_Color32(12, 16, 22, 255)

enum { D_UP, D_DOWN, D_LEFT, D_RIGHT };

static GameKind kind;
static u32 rng = 0x2545F491u;

static u32 rnd(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static int rn(int n) { return n > 0 ? (int)(rnd() % (u32)n) : 0; }
static float fclampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int diff(void) { return clampi(g_settings.difficulty, 0, 2); }
static int best(void) { return settings_best((int)kind); }
static void note(int score) { settings_note_score((int)kind, score); }
static u32 rgb(const u8 *c) { return C2D_Color32(c[0], c[1], c[2], 255); }

static int pad_dir(GameInput in) {
    if (in.down & KEY_DUP) return D_UP;
    if (in.down & KEY_DDOWN) return D_DOWN;
    if (in.down & KEY_DLEFT) return D_LEFT;
    if (in.down & KEY_DRIGHT) return D_RIGHT;
    return -1;
}

static void header(int score) {
    char line[64];
    ui_rect(0, 0, 400, 22, C_PANEL);
    ui_text(8, 4, 0.45f, C_WHITE, "%s", game_title(kind));
    snprintf(line, sizeof(line), tr("Puntos %d   Record %d"), score, best() > score ? best() : score);
    ui_text_right(392, 4, 0.45f, COL_GREEN, line);
}

static void overlay(const char *title, const char *sub) {
    ui_rounded(80, 78, 240, 84, 10, C_PANEL);
    ui_rect(80, 78, 240, 3, COL_GREEN);
    ui_text_center(200, 92, 0.65f, C_WHITE, title);
    ui_text_center(200, 128, 0.4f, COL_SUBTEXT, sub);
}

static void thick_line(float x1, float y1, float x2, float y2, float w, u32 c) {
    float dx = x2 - x1, dy = y2 - y1, len = sqrtf(dx * dx + dy * dy);
    if (len < 0.001f) return;
    float nx = -dy / len * w / 2, ny = dx / len * w / 2;
    ui_triangle(x1 + nx, y1 + ny, x1 - nx, y1 - ny, x2 + nx, y2 + ny, c);
    ui_triangle(x2 + nx, y2 + ny, x1 - nx, y1 - ny, x2 - nx, y2 - ny, c);
}

/* Bottom screen for games that are played on the top screen. */
static void hint_bottom(const char *l1, const char *l2) {
    ui_rect(0, 0, 320, 240, C_BG);
    ui_rounded(10, 40, 300, 150, 12, C_PANEL);
    ui_text_center(160, 90, 0.5f, C_WHITE, l1);
    ui_text_center(160, 124, 0.38f, COL_SUBTEXT, l2);
    ui_text_center(160, 224, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
}

static int grid_cell(int x, int y, int ox, int oy, int cw, int ch, int cols, int rows) {
    if (x < ox || y < oy) return -1;
    int c = (x - ox) / cw, r = (y - oy) / ch;
    return c < cols && r < rows ? r * cols + c : -1;
}

/* ================================= PONG ================================ */
typedef struct { float py, cy, bx, by, vx, vy, serveT; int lives, score, rally; bool over; } Pong;

static float pong_ph(void) { return diff() == 0 ? 72.0f : diff() == 1 ? 56.0f : 44.0f; }

static void pong_serve(Pong *p, float dir) {
    p->bx = 200; p->by = 120;
    p->vx = dir * (190.0f + (float)diff() * 25.0f);
    p->vy = (float)(rn(160) - 80);
    p->serveT = 0.8f;
    p->rally = 0;
}

static void pong_start(Pong *p) { p->py = p->cy = 130; p->lives = 3; pong_serve(p, 1); }

static void pong_update(Pong *p, GameInput in) {
    if (p->over) return;
    float ph = pong_ph();
    p->py -= (float)in.circleY / 156.0f * 300.0f * in.dt;
    if (in.held & KEY_DUP) p->py -= 260.0f * in.dt;
    if (in.held & KEY_DDOWN) p->py += 260.0f * in.dt;
    if (in.held & KEY_TOUCH) p->py = (float)in.touchY;
    p->py = fclampf(p->py, 24 + ph / 2, 238 - ph / 2);
    float cs = (105.0f + (float)p->rally * 7.0f) * (diff() == 0 ? 0.8f : diff() == 1 ? 1.0f : 1.2f);
    float target = p->vx > 0 ? p->by : 130.0f;
    if (fabsf(target - p->cy) > 4) p->cy += (target > p->cy ? cs : -cs) * in.dt;
    p->cy = fclampf(p->cy, 24 + ph / 2, 238 - ph / 2);
    if (p->serveT > 0) { p->serveT -= in.dt; return; }
    p->bx += p->vx * in.dt;
    p->by += p->vy * in.dt;
    if (p->by < 28) { p->by = 28; p->vy = fabsf(p->vy); }
    if (p->by > 236) { p->by = 236; p->vy = -fabsf(p->vy); }
    if (p->vx < 0 && p->bx - 4 <= 24 && p->bx > 8 && fabsf(p->by - p->py) < ph / 2 + 4) {
        p->bx = 28;
        p->vx = fminf(-p->vx * 1.05f, 430.0f);
        p->vy += (p->by - p->py) / (ph / 2) * 150.0f;
        p->score++; p->rally++;
        note(p->score);
    }
    if (p->vx > 0 && p->bx + 4 >= 376 && p->bx < 392 && fabsf(p->by - p->cy) < ph / 2 + 4) {
        p->bx = 372;
        p->vx = -fminf(p->vx * 1.04f, 430.0f);
        p->vy += (p->by - p->cy) / (ph / 2) * 150.0f;
        p->rally++;
    }
    p->vy = fclampf(p->vy, -320.0f, 320.0f);
    if (p->bx < -10) {
        p->lives--;
        if (p->lives <= 0) { p->over = true; note(p->score); } else pong_serve(p, 1);
    } else if (p->bx > 410) {
        p->score += 5;
        note(p->score);
        pong_serve(p, -1);
    }
}

static void pong_draw(Pong *p) {
    float ph = pong_ph();
    ui_rect(0, 0, 400, 240, C_BG);
    header(p->score);
    for (int y = 28; y < 236; y += 16) ui_rect(198, (float)y, 4, 8, C_LINE);
    ui_rounded(16, p->py - ph / 2, 8, ph, 3, COL_GREEN);
    ui_rounded(376, p->cy - ph / 2, 8, ph, 3, C_WHITE);
    ui_circle(p->bx, p->by, 5, C_GOLD);
    for (int i = 0; i < p->lives; i++) ui_circle(30.0f + (float)i * 14.0f, 36, 4, C_RED);
    if (p->serveT > 0 && !p->over) ui_text_center(200, 150, 0.4f, COL_SUBTEXT, "Stick o toca la pantalla para mover la pala");
    if (p->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

/* ============================== WHACK-A-MOLE =========================== */
typedef struct { float timer; int type; float hit; } Hole;       /* type: 0 empty, 1 mole, 2 bomb */
typedef struct { Hole h[9]; float timeLeft, spawn; int score, cur; bool over; } Whack;

static void whack_start(Whack *w) { w->timeLeft = 45; w->spawn = 0.5f; w->cur = 4; }

static void whack_hit(Whack *w, int i) {
    if (w->over || i < 0 || i >= 9) return;
    w->cur = i;
    Hole *h = &w->h[i];
    if (h->type == 1) { w->score += 10; h->type = 0; h->hit = 0.25f; note(w->score); }
    else if (h->type == 2) { w->score = w->score > 15 ? w->score - 15 : 0; h->type = 0; h->hit = -0.25f; }
}

static void whack_update(Whack *w, GameInput in) {
    for (int i = 0; i < 9; i++) {
        Hole *h = &w->h[i];
        if (h->hit > 0) h->hit -= in.dt; else if (h->hit < 0) h->hit += in.dt;
        if (h->type) { h->timer -= in.dt; if (h->timer <= 0) h->type = 0; }
    }
    if (w->over) return;
    w->timeLeft -= in.dt;
    if (w->timeLeft <= 0) { w->over = true; w->timeLeft = 0; note(w->score); return; }
    int d = pad_dir(in);
    if (d == D_UP && w->cur >= 3) w->cur -= 3;
    if (d == D_DOWN && w->cur < 6) w->cur += 3;
    if (d == D_LEFT && w->cur % 3 > 0) w->cur--;
    if (d == D_RIGHT && w->cur % 3 < 2) w->cur++;
    if (in.down & KEY_A) whack_hit(w, w->cur);
    w->spawn -= in.dt;
    if (w->spawn <= 0) {
        static const float gap[3] = {0.75f, 0.58f, 0.42f}, life[3] = {1.35f, 1.05f, 0.8f};
        w->spawn = gap[diff()] * (0.6f + (float)rn(80) / 100.0f);
        int i = rn(9);
        for (int tries = 0; tries < 9 && w->h[i].type; tries++) i = (i + 1) % 9;
        if (!w->h[i].type) {
            w->h[i].type = rn(100) < 18 ? 2 : 1;
            w->h[i].timer = fmaxf(0.4f, life[diff()] - (float)w->score * 0.003f);
        }
    }
}

static void whack_draw_top(Whack *w) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(w->score);
    ui_text(20, 50, 0.6f, C_WHITE, "Tiempo: %d s", (int)ceilf(w->timeLeft));
    ui_rect(20, 90, 360, 10, C_LINE);
    ui_rect(20, 90, 360.0f * w->timeLeft / 45.0f, 10, COL_GREEN);
    ui_text(20, 120, 0.42f, COL_SUBTEXT, "Toca los topos en la pantalla de abajo.");
    ui_text(20, 142, 0.42f, C_RED, "Las bombas te restan 15 puntos.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (w->over) overlay("Se acabo el tiempo", "X: jugar de nuevo   B: menu");
}

static void whack_draw_bottom(Whack *w) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 9; i++) {
        float x = 16.0f + (float)(i % 3) * 96, y = 24.0f + (float)(i / 3) * 68;
        ui_rounded(x + 6, y + 30, 84, 32, 12, C_INK);
        Hole *h = &w->h[i];
        if (h->type == 1) { ui_circle(x + 48, y + 28, 24, C2D_Color32(160, 110, 70, 255)); ui_circle(x + 40, y + 24, 3, C_INK); ui_circle(x + 56, y + 24, 3, C_INK); ui_circle(x + 48, y + 33, 4, C_RED); }
        else if (h->type == 2) { ui_circle(x + 48, y + 28, 20, C_INK); ui_rect(x + 46, y + 2, 4, 8, C_GOLD); ui_circle(x + 48, y + 28, 20 - 5, C2D_Color32(50, 50, 60, 255)); }
        if (h->hit > 0) ui_circle(x + 48, y + 28, 26, C2D_Color32(250, 204, 70, 120));
        if (h->hit < 0) ui_circle(x + 48, y + 28, 26, C2D_Color32(240, 84, 84, 140));
        if (i == w->cur) { ui_rect(x + 2, y + 2, 92, 2, COL_GREEN); ui_rect(x + 2, y + 62, 92, 2, COL_GREEN); ui_rect(x + 2, y + 2, 2, 62, COL_GREEN); ui_rect(x + 92, y + 2, 2, 62, COL_GREEN); }
    }
}

/* ================================ MEMORY =============================== */
typedef struct { u8 id[16], st[16]; int first, second, moves, matched; float lock, time; bool win; } Memory;

static void mem_start(Memory *m) {
    for (int i = 0; i < 16; i++) m->id[i] = (u8)(i / 2);
    for (int i = 15; i > 0; i--) { int j = rn(i + 1); u8 t = m->id[i]; m->id[i] = m->id[j]; m->id[j] = t; }
    m->first = m->second = -1;
}

static void mem_pick(Memory *m, int i) {
    if (m->win || m->lock > 0 || i < 0 || i >= 16 || m->st[i] != 0) return;
    m->st[i] = 1;
    if (m->first < 0) { m->first = i; return; }
    m->second = i;
    m->moves++;
    if (m->id[m->first] == m->id[i]) {
        m->st[m->first] = m->st[i] = 2;
        m->matched += 2;
        m->first = m->second = -1;
        if (m->matched >= 16) {
            m->win = true;
            note(clampi(600 - m->moves * 15 - (int)m->time, 10, 600));
        }
    } else {
        m->lock = 0.8f;
    }
}

static int mem_cursor;

static void mem_update(Memory *m, GameInput in) {
    if (!m->win) m->time += in.dt;
    if (m->lock > 0) {
        m->lock -= in.dt;
        if (m->lock <= 0) { m->st[m->first] = m->st[m->second] = 0; m->first = m->second = -1; }
    }
    int d = pad_dir(in);
    if (d == D_UP && mem_cursor >= 4) mem_cursor -= 4;
    if (d == D_DOWN && mem_cursor < 12) mem_cursor += 4;
    if (d == D_LEFT && mem_cursor % 4 > 0) mem_cursor--;
    if (d == D_RIGHT && mem_cursor % 4 < 3) mem_cursor++;
    if (in.down & KEY_A) mem_pick(m, mem_cursor);
}

static void mem_symbol(int id, float cx, float cy) {
    static const u8 col[8][3] = {{240,84,84},{80,160,240},{110,210,120},{250,204,70},{170,120,240},{240,140,70},{80,210,210},{240,110,170}};
    u32 c = rgb(col[id & 7]);
    switch (id & 7) {
        case 0: ui_circle(cx, cy, 16, c); break;
        case 1: ui_rect(cx - 14, cy - 14, 28, 28, c); break;
        case 2: ui_triangle(cx, cy - 17, cx - 17, cy + 14, cx + 17, cy + 14, c); break;
        case 3: ui_triangle(cx, cy - 18, cx - 14, cy, cx + 14, cy, c); ui_triangle(cx, cy + 18, cx - 14, cy, cx + 14, cy, c); break;
        case 4: ui_rect(cx - 5, cy - 16, 10, 32, c); ui_rect(cx - 16, cy - 5, 32, 10, c); break;
        case 5: ui_circle(cx, cy, 16, c); ui_circle(cx, cy, 8, C_PANEL); break;
        case 6: ui_rect(cx - 16, cy - 14, 32, 6, c); ui_rect(cx - 16, cy - 3, 32, 6, c); ui_rect(cx - 16, cy + 8, 32, 6, c); break;
        default: ui_circle(cx - 8, cy - 6, 9, c); ui_circle(cx + 8, cy - 6, 9, c); ui_triangle(cx - 17, cy - 1, cx + 17, cy - 1, cx, cy + 17, c); break;
    }
}

static void mem_draw_top(Memory *m) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(m->win ? clampi(600 - m->moves * 15 - (int)m->time, 10, 600) : 0);
    ui_text(20, 56, 0.55f, C_WHITE, "Movimientos: %d", m->moves);
    ui_text(20, 90, 0.55f, C_WHITE, "Tiempo: %d s", (int)m->time);
    ui_text(20, 124, 0.42f, COL_SUBTEXT, "Toca las cartas de la pantalla de abajo.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (m->win) overlay("Las encontraste todas", "X: jugar de nuevo   B: menu");
}

static void mem_draw_bottom(Memory *m) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 16; i++) {
        float x = 8.0f + (float)(i % 4) * 76, y = 8.0f + (float)(i / 4) * 58;
        if (m->st[i] == 0) { ui_rounded(x, y, 70, 52, 8, C_PANEL); ui_text_center(x + 35, y + 12, 0.7f, COL_GREEN, "?"); }
        else { ui_rounded(x, y, 70, 52, 8, m->st[i] == 2 ? C_INK : C_LINE); mem_symbol(m->id[i], x + 35, y + 26); }
        if (i == mem_cursor) { ui_rect(x - 2, y - 2, 74, 2, COL_GREEN); ui_rect(x - 2, y + 52, 74, 2, COL_GREEN); ui_rect(x - 2, y - 2, 2, 56, COL_GREEN); ui_rect(x + 70, y - 2, 2, 56, COL_GREEN); }
    }
}

/* ================================= SIMON ================================ */
typedef struct { u8 seq[64]; int len, pos, showIdx, lit, score; float timer; int phase; bool over; } Simon;   /* phase 0 wait, 1 show, 2 input */

static void simon_add(Simon *s) { if (s->len < 64) s->seq[s->len++] = (u8)rn(4); s->phase = 0; s->timer = 0.8f; s->showIdx = 0; s->lit = -1; }
static void simon_start(Simon *s) { simon_add(s); }

static void simon_press(Simon *s, int b) {
    if (s->phase != 2 || s->over || b < 0) return;
    s->lit = b;
    s->timer = 0.22f;
    if (s->seq[s->pos] != b) { s->over = true; note(s->score); return; }
    s->pos++;
    if (s->pos >= s->len) { s->score = s->len; note(s->score); s->phase = 3; s->timer = 0.7f; }
}

static void simon_update(Simon *s, GameInput in) {
    static const float litT[3] = {0.55f, 0.42f, 0.3f};
    if (s->over) { if (s->timer > 0) s->timer -= in.dt; if (s->timer <= 0) s->lit = -1; return; }
    s->timer -= in.dt;
    if (s->phase == 0 && s->timer <= 0) { s->phase = 1; s->showIdx = 0; s->lit = s->seq[0]; s->timer = litT[diff()]; }
    else if (s->phase == 1 && s->timer <= 0) {
        if (s->lit >= 0) { s->lit = -1; s->timer = 0.15f; }
        else if (++s->showIdx >= s->len) { s->phase = 2; s->pos = 0; }
        else { s->lit = s->seq[s->showIdx]; s->timer = litT[diff()]; }
    } else if (s->phase == 2) {
        if (s->lit >= 0 && s->timer <= 0) s->lit = -1;
        int d = pad_dir(in);
        if (d >= 0) simon_press(s, d == D_UP ? 0 : d == D_RIGHT ? 1 : d == D_LEFT ? 2 : 3);
    } else if (s->phase == 3 && s->timer <= 0) simon_add(s);
}

static void simon_draw_top(Simon *s) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(s->score);
    ui_text(20, 56, 0.6f, C_WHITE, "Ronda %d", s->len);
    const char *msg = s->over ? "Te equivocaste" : s->phase == 2 ? "Tu turno" : "Mira la secuencia";
    ui_text(20, 100, 0.5f, s->phase == 2 ? COL_GREEN : COL_SUBTEXT, "%s", tr(msg));
    ui_text(20, 150, 0.4f, COL_SUBTEXT, "Cruceta o toca los colores.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (s->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

static void simon_draw_bottom(Simon *s) {
    static const u8 base[4][3] = {{40,150,70},{170,50,50},{190,160,40},{50,100,190}};
    static const u8 lit[4][3]  = {{110,255,140},{255,110,110},{255,235,90},{120,180,255}};
    static const float px[4] = {8, 162, 8, 162}, py[4] = {20, 20, 124, 124};
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 4; i++) ui_rounded(px[i], py[i], 150, 96, 14, rgb(s->lit == i ? lit[i] : base[i]));
}

/* ================================ TIC-TAC-TOE ========================== */
typedef struct { u8 b[9]; int turn, wins, losses, draws, cur, winner; bool cpuStarts; float cpuT; u8 line[3]; bool over; } TicTac;   /* turn 1 human, 2 cpu */

static const u8 tt_lines[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

static int tt_winner(const u8 *b, u8 *line) {
    for (int i = 0; i < 8; i++) {
        const u8 *l = tt_lines[i];
        if (b[l[0]] && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) { if (line) memcpy(line, l, 3); return b[l[0]]; }
    }
    return 0;
}

static int tt_full(const u8 *b) { for (int i = 0; i < 9; i++) if (!b[i]) return 0; return 1; }

static int tt_minimax(u8 *b, int player) {   /* score from the CPU (2) point of view */
    int w = tt_winner(b, NULL);
    if (w == 2) return 1;
    if (w == 1) return -1;
    if (tt_full(b)) return 0;
    int bestv = player == 2 ? -2 : 2;
    for (int i = 0; i < 9; i++) {
        if (b[i]) continue;
        b[i] = (u8)player;
        int v = tt_minimax(b, 3 - player);
        b[i] = 0;
        if (player == 2 ? v > bestv : v < bestv) bestv = v;
    }
    return bestv;
}

static int tt_cpu_move(TicTac *t) {
    int free_[9], n = 0;
    for (int i = 0; i < 9; i++) if (!t->b[i]) free_[n++] = i;
    if (n == 0) return -1;
    bool smart = diff() == 2 || (diff() == 1 && rn(100) < 70);
    if (!smart) {   /* easy: still takes a win and blocks, otherwise random */
        for (int p = 2; p >= 1; p--)
            for (int k = 0; k < n; k++) { t->b[free_[k]] = (u8)p; int w = tt_winner(t->b, NULL); t->b[free_[k]] = 0; if (w == p) return free_[k]; }
        return diff() == 0 && rn(100) < 40 ? free_[rn(n)] : free_[rn(n)];
    }
    int bestMove = free_[0], bestV = -2;
    for (int k = 0; k < n; k++) {
        t->b[free_[k]] = 2;
        int v = tt_minimax(t->b, 1);
        t->b[free_[k]] = 0;
        if (v > bestV || (v == bestV && rn(3) == 0)) { bestV = v; bestMove = free_[k]; }
    }
    return bestMove;
}

static void tt_finish(TicTac *t) {
    int w = tt_winner(t->b, t->line);
    if (w || tt_full(t->b)) {
        t->over = true;
        t->winner = w;
        if (w == 1) t->wins++; else if (w == 2) t->losses++; else t->draws++;
        note(t->wins * 10 + t->draws * 3);
    }
}

static void tt_next(TicTac *t) {
    memset(t->b, 0, sizeof(t->b));
    t->over = false; t->winner = 0;
    t->cpuStarts = !t->cpuStarts;
    t->turn = t->cpuStarts ? 2 : 1;
    t->cpuT = 0.5f;
}

static void tt_start(TicTac *t) { t->turn = 1; t->cur = 4; }

static void tt_place(TicTac *t, int i) {
    if (t->over) { tt_next(t); return; }
    if (t->turn != 1 || i < 0 || i >= 9 || t->b[i]) return;
    t->b[i] = 1;
    t->cur = i;
    tt_finish(t);
    if (!t->over) { t->turn = 2; t->cpuT = 0.5f; }
}

static void tt_update(TicTac *t, GameInput in) {
    int d = pad_dir(in);
    if (d == D_UP && t->cur >= 3) t->cur -= 3;
    if (d == D_DOWN && t->cur < 6) t->cur += 3;
    if (d == D_LEFT && t->cur % 3 > 0) t->cur--;
    if (d == D_RIGHT && t->cur % 3 < 2) t->cur++;
    if (in.down & KEY_A) tt_place(t, t->cur);
    if (!t->over && t->turn == 2) {
        t->cpuT -= in.dt;
        if (t->cpuT <= 0) {
            int m = tt_cpu_move(t);
            if (m >= 0) t->b[m] = 2;
            tt_finish(t);
            t->turn = 1;
        }
    }
}

static void tt_draw_top(TicTac *t) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(t->wins * 10 + t->draws * 3);
    ui_text(20, 50, 0.55f, COL_GREEN, "Ganadas: %d", t->wins);
    ui_text(20, 82, 0.55f, C_WHITE, "Empates: %d", t->draws);
    ui_text(20, 114, 0.55f, C_RED, "Perdidas: %d", t->losses);
    ui_text(20, 160, 0.4f, COL_SUBTEXT, "Tu eres la X. Toca una casilla o usa cruceta + A.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (t->over) overlay(t->winner == 1 ? "Ganaste!" : t->winner == 2 ? "Gana la consola" : "Empate", "A o toca: siguiente partida");
}

static void tt_draw_bottom(TicTac *t) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 9; i++) {
        float x = 52.0f + (float)(i % 3) * 72, y = 12.0f + (float)(i / 3) * 72;
        ui_rounded(x + 2, y + 2, 68, 68, 8, C_PANEL);
        float cx = x + 36, cy = y + 36;
        if (t->b[i] == 1) { thick_line(cx - 20, cy - 20, cx + 20, cy + 20, 8, COL_GREEN); thick_line(cx - 20, cy + 20, cx + 20, cy - 20, 8, COL_GREEN); }
        else if (t->b[i] == 2) { ui_circle(cx, cy, 23, C_RED); ui_circle(cx, cy, 14, C_PANEL); }
        if (i == t->cur && !t->over) { ui_rect(x, y, 72, 2, C_GOLD); ui_rect(x, y + 70, 72, 2, C_GOLD); ui_rect(x, y, 2, 72, C_GOLD); ui_rect(x + 70, y, 2, 72, C_GOLD); }
    }
    if (t->over && t->winner) {
        float ax = 52.0f + (float)(t->line[0] % 3) * 72 + 36, ay = 12.0f + (float)(t->line[0] / 3) * 72 + 36;
        float bx = 52.0f + (float)(t->line[2] % 3) * 72 + 36, by = 12.0f + (float)(t->line[2] / 3) * 72 + 36;
        thick_line(ax, ay, bx, by, 6, C_GOLD);
    }
}

/* ============================== CONNECT FOUR =========================== */
typedef struct { u8 b[6][7]; int cur, wins, losses, draws, winner; bool over, cpuStarts; int turn; float cpuT; } Connect4;

static int c4_drop_row(const u8 b[6][7], int c) { for (int r = 5; r >= 0; r--) if (!b[r][c]) return r; return -1; }

static bool c4_win(const u8 b[6][7], int r, int c, u8 p) {
    static const int dr[4] = {0, 1, 1, 1}, dc[4] = {1, 0, 1, -1};
    for (int d = 0; d < 4; d++) {
        int n = 1;
        for (int s = -1; s <= 1; s += 2)
            for (int k = 1; k < 4; k++) {
                int rr = r + dr[d] * k * s, cc = c + dc[d] * k * s;
                if (rr < 0 || rr > 5 || cc < 0 || cc > 6 || b[rr][cc] != p) break;
                n++;
            }
        if (n >= 4) return true;
    }
    return false;
}

static int c4_eval(const u8 b[6][7], u8 p) {
    static const int dr[4] = {0, 1, 1, 1}, dc[4] = {1, 0, 1, -1};
    static const int wgt[5] = {0, 1, 6, 40, 0};
    int score = 0;
    for (int r = 0; r < 6; r++) if (b[r][3] == p) score += 3;
    for (int r = 0; r < 6; r++)
        for (int c = 0; c < 7; c++)
            for (int d = 0; d < 4; d++) {
                int er = r + dr[d] * 3, ec = c + dc[d] * 3;
                if (er < 0 || er > 5 || ec < 0 || ec > 6) continue;
                int mine = 0, theirs = 0;
                for (int k = 0; k < 4; k++) { u8 v = b[r + dr[d] * k][c + dc[d] * k]; if (v == p) mine++; else if (v) theirs++; }
                if (mine && theirs) continue;
                score += mine ? wgt[mine] : -wgt[theirs];
            }
    return score;
}

static int c4_negamax(u8 b[6][7], int depth, int alpha, int beta, u8 p, int filled) {
    static const int order[7] = {3, 2, 4, 1, 5, 0, 6};
    if (filled >= 42) return 0;
    if (depth == 0) return c4_eval(b, p);
    int bestv = -1000000;
    for (int i = 0; i < 7; i++) {
        int c = order[i], r = c4_drop_row(b, c);
        if (r < 0) continue;
        b[r][c] = p;
        int v;
        if (c4_win(b, r, c, p)) v = 100000 + depth;
        else v = -c4_negamax(b, depth - 1, -beta, -alpha, (u8)(3 - p), filled + 1);
        b[r][c] = 0;
        if (v > bestv) bestv = v;
        if (bestv > alpha) alpha = bestv;
        if (alpha >= beta) break;
    }
    return bestv;
}

static int c4_cpu_move(Connect4 *g) {
    static const int order[7] = {3, 2, 4, 1, 5, 0, 6};
    static const int depths[3] = {2, 4, 5};
    int filled = 0;
    for (int r = 0; r < 6; r++) for (int c = 0; c < 7; c++) if (g->b[r][c]) filled++;
    if (diff() == 0 && rn(100) < 25) { int c = rn(7); for (int k = 0; k < 7; k++) if (g->b[0][(c + k) % 7] == 0) return (c + k) % 7; }
    int bestC = -1, bestV = -2000000;
    for (int i = 0; i < 7; i++) {
        int c = order[i], r = c4_drop_row(g->b, c);
        if (r < 0) continue;
        g->b[r][c] = 2;
        int v = c4_win(g->b, r, c, 2) ? 200000 : -c4_negamax(g->b, depths[diff()] - 1, -1000000, 1000000, 1, filled + 1);
        g->b[r][c] = 0;
        if (v > bestV) { bestV = v; bestC = c; }
    }
    return bestC;
}

static void c4_start(Connect4 *g) { g->cur = 3; g->turn = 1; }

static bool c4_full(const Connect4 *g) { for (int c = 0; c < 7; c++) if (!g->b[0][c]) return false; return true; }

static void c4_end(Connect4 *g, int winner) {
    g->over = true; g->winner = winner;
    if (winner == 1) g->wins++; else if (winner == 2) g->losses++; else g->draws++;
    note(g->wins * 10 + g->draws * 3);
}

static void c4_next(Connect4 *g) {
    memset(g->b, 0, sizeof(g->b));
    g->over = false; g->winner = 0;
    g->cpuStarts = !g->cpuStarts;
    g->turn = g->cpuStarts ? 2 : 1;
    g->cpuT = 0.5f;
}

static void c4_play(Connect4 *g, int c) {
    if (g->over) { c4_next(g); return; }
    if (g->turn != 1 || c < 0 || c > 6) return;
    int r = c4_drop_row(g->b, c);
    if (r < 0) return;
    g->b[r][c] = 1;
    g->cur = c;
    if (c4_win(g->b, r, c, 1)) { c4_end(g, 1); return; }
    if (c4_full(g)) { c4_end(g, 0); return; }
    g->turn = 2; g->cpuT = 0.4f;
}

static void c4_update(Connect4 *g, GameInput in) {
    int d = pad_dir(in);
    if (d == D_LEFT && g->cur > 0) g->cur--;
    if (d == D_RIGHT && g->cur < 6) g->cur++;
    if (in.down & KEY_A) c4_play(g, g->cur);
    if (!g->over && g->turn == 2) {
        g->cpuT -= in.dt;
        if (g->cpuT <= 0) {
            int c = c4_cpu_move(g);
            if (c >= 0) {
                int r = c4_drop_row(g->b, c);
                g->b[r][c] = 2;
                if (c4_win(g->b, r, c, 2)) c4_end(g, 2);
                else if (c4_full(g)) c4_end(g, 0);
            }
            g->turn = 1;
        }
    }
}

static void c4_draw_top(Connect4 *g) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(g->wins * 10 + g->draws * 3);
    ui_rounded(86, 30, 232, 200, 10, C2D_Color32(36, 76, 160, 255));
    for (int r = 0; r < 6; r++)
        for (int c = 0; c < 7; c++) {
            u8 v = g->b[r][c];
            ui_circle(106.0f + (float)c * 31, 52.0f + (float)r * 31, 12, v == 1 ? C_RED : v == 2 ? C_GOLD : C_BG);
        }
    ui_circle(106.0f + (float)g->cur * 31, 38, 5, g->turn == 1 ? C_RED : COL_SUBTEXT);
    ui_text(8, 40, 0.42f, COL_GREEN, "Ganadas: %d", g->wins);
    ui_text(8, 62, 0.42f, C_WHITE, "Empates: %d", g->draws);
    ui_text(8, 84, 0.42f, C_RED, "Perdidas: %d", g->losses);
    if (g->over) overlay(g->winner == 1 ? "Ganaste!" : g->winner == 2 ? "Gana la consola" : "Empate", "A o toca: siguiente partida");
}

static void c4_draw_bottom(Connect4 *g) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int c = 0; c < 7; c++) {
        float x = 6.0f + (float)c * 44;
        ui_rounded(x, 24, 40, 190, 8, c == g->cur ? C_LINE : C_PANEL);
        ui_triangle(x + 20, 190, x + 8, 168, x + 32, 168, COL_GREEN);
    }
    ui_text_center(160, 4, 0.38f, COL_SUBTEXT, "Toca una columna o usa cruceta + A");
    ui_text_center(160, 222, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
}

/* =============================== ASTEROIDS ============================= */
#define AS_ROCKS 28
#define AS_BULLETS 6
typedef struct { bool on; float x, y, vx, vy; int size; } Rock;
typedef struct { bool on; float x, y, vx, vy, life; } Bullet;
typedef struct { float x, y, vx, vy, ang, cd, invuln; Rock r[AS_ROCKS]; Bullet b[AS_BULLETS]; int lives, score, wave; bool thrust, over; } Asteroids;

static float as_radius(int size) { return size == 3 ? 22.0f : size == 2 ? 13.0f : 7.0f; }

static void as_spawn(Asteroids *a, float x, float y, int size) {
    for (int i = 0; i < AS_ROCKS; i++) {
        if (a->r[i].on) continue;
        float sp = (28.0f + (float)rn(40)) * (diff() == 0 ? 0.8f : diff() == 1 ? 1.0f : 1.25f) * (size == 1 ? 1.6f : size == 2 ? 1.25f : 1.0f);
        float an = (float)rn(628) / 100.0f;
        a->r[i] = (Rock){true, x, y, cosf(an) * sp, sinf(an) * sp, size};
        return;
    }
}

static void as_wave(Asteroids *a) {
    int n = 3 + a->wave;
    for (int i = 0; i < n && i < 10; i++) {
        float x, y;
        do { x = (float)rn(400); y = 24.0f + (float)rn(216); } while (fabsf(x - a->x) < 80 && fabsf(y - a->y) < 80);
        as_spawn(a, x, y, 3);
    }
}

static void as_start(Asteroids *a) { a->x = 200; a->y = 132; a->ang = -1.5708f; a->lives = 3; a->wave = 1; a->invuln = 2; as_wave(a); }

static void as_wrap(float *x, float *y) {
    if (*x < 0) *x += 400; else if (*x >= 400) *x -= 400;
    if (*y < 24) *y += 216; else if (*y >= 240) *y -= 216;
}

static void as_update(Asteroids *a, GameInput in) {
    if (a->over) return;
    float turn = (float)in.circleX / 156.0f * 4.0f;
    if (in.held & KEY_DLEFT) turn -= 3.6f;
    if (in.held & KEY_DRIGHT) turn += 3.6f;
    a->ang += turn * in.dt;
    a->thrust = (in.held & (KEY_A | KEY_DUP)) || in.circleY > 60;
    if (a->thrust) { a->vx += cosf(a->ang) * 190.0f * in.dt; a->vy += sinf(a->ang) * 190.0f * in.dt; }
    float fr = 1.0f - 0.55f * in.dt;
    a->vx *= fr; a->vy *= fr;
    float sp = sqrtf(a->vx * a->vx + a->vy * a->vy);
    if (sp > 220) { a->vx *= 220 / sp; a->vy *= 220 / sp; }
    a->x += a->vx * in.dt; a->y += a->vy * in.dt;
    as_wrap(&a->x, &a->y);
    a->cd -= in.dt; a->invuln -= in.dt;
    if ((in.held & (KEY_R | KEY_L | KEY_Y | KEY_TOUCH)) && a->cd <= 0) {
        for (int i = 0; i < AS_BULLETS; i++)
            if (!a->b[i].on) { a->b[i] = (Bullet){true, a->x + cosf(a->ang) * 12, a->y + sinf(a->ang) * 12, cosf(a->ang) * 320 + a->vx, sinf(a->ang) * 320 + a->vy, 0.9f}; a->cd = 0.22f; break; }
    }
    int alive = 0;
    for (int i = 0; i < AS_BULLETS; i++) {
        Bullet *b = &a->b[i];
        if (!b->on) continue;
        b->x += b->vx * in.dt; b->y += b->vy * in.dt; b->life -= in.dt;
        as_wrap(&b->x, &b->y);
        if (b->life <= 0) { b->on = false; continue; }
        for (int j = 0; j < AS_ROCKS; j++) {
            Rock *r = &a->r[j];
            if (!r->on) continue;
            float dx = r->x - b->x, dy = r->y - b->y, rr = as_radius(r->size) + 2;
            if (dx * dx + dy * dy < rr * rr) {
                b->on = false; r->on = false;
                a->score += r->size == 3 ? 20 : r->size == 2 ? 50 : 100;
                note(a->score);
                if (r->size > 1) { as_spawn(a, r->x, r->y, r->size - 1); as_spawn(a, r->x, r->y, r->size - 1); }
                break;
            }
        }
    }
    for (int j = 0; j < AS_ROCKS; j++) {
        Rock *r = &a->r[j];
        if (!r->on) continue;
        alive++;
        r->x += r->vx * in.dt; r->y += r->vy * in.dt;
        as_wrap(&r->x, &r->y);
        float dx = r->x - a->x, dy = r->y - a->y, rr = as_radius(r->size) + 6;
        if (a->invuln <= 0 && dx * dx + dy * dy < rr * rr) {
            a->lives--;
            a->invuln = 2.0f; a->x = 200; a->y = 132; a->vx = a->vy = 0;
            if (a->lives <= 0) { a->over = true; note(a->score); }
        }
    }
    if (alive == 0) { a->wave++; a->score += 100; note(a->score); a->invuln = 1.5f; as_wave(a); }
}

static void as_draw(Asteroids *a) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(a->score);
    ui_text(8, 26, 0.38f, COL_SUBTEXT, "Vidas %d   Oleada %d", a->lives, a->wave);
    for (int j = 0; j < AS_ROCKS; j++) {
        Rock *r = &a->r[j];
        if (!r->on) continue;
        float rad = as_radius(r->size);
        ui_circle(r->x, r->y, rad, C2D_Color32(150, 160, 175, 255));
        ui_circle(r->x - rad * 0.2f, r->y - rad * 0.2f, rad * 0.7f, C2D_Color32(96, 106, 122, 255));
    }
    for (int i = 0; i < AS_BULLETS; i++) if (a->b[i].on) ui_circle(a->b[i].x, a->b[i].y, 2.5f, C_GOLD);
    if (a->invuln <= 0 || ((int)(a->invuln * 10) & 1)) {
        float ca = cosf(a->ang), sa = sinf(a->ang);
        ui_triangle(a->x + ca * 13, a->y + sa * 13, a->x - ca * 9 - sa * 8, a->y - sa * 9 + ca * 8, a->x - ca * 9 + sa * 8, a->y - sa * 9 - ca * 8, COL_GREEN);
        if (a->thrust) ui_triangle(a->x - ca * 9 - sa * 4, a->y - sa * 9 + ca * 4, a->x - ca * 9 + sa * 4, a->y - sa * 9 - ca * 4, a->x - ca * 20, a->y - sa * 20, C_GOLD);
    }
    if (a->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

/* ============================== DINO RUNNER ============================ */
#define DN_OBS 4
typedef struct { bool on; float x; int type; float w, h, y; } Obstacle;   /* type 0 cactus, 1 bird */
typedef struct { float y, vy, dist, speed, nextGap, anim; Obstacle o[DN_OBS]; bool duck, over; int score; } Dino;

#define DN_GROUND 196

static void dino_start(Dino *d) { d->y = DN_GROUND; d->speed = 190; d->nextGap = 240; }

static void dino_update(Dino *d, GameInput in) {
    if (d->over) return;
    bool onGround = d->y >= DN_GROUND;
    if (onGround && (in.down & (KEY_A | KEY_DUP | KEY_TOUCH))) d->vy = -470;
    d->duck = onGround && (in.held & KEY_DDOWN);
    d->vy += 1500 * in.dt;
    d->y += d->vy * in.dt;
    if (d->y >= DN_GROUND) { d->y = DN_GROUND; d->vy = 0; }
    d->speed = fminf(190.0f + (float)d->score * 0.45f, 430.0f) * (diff() == 0 ? 0.88f : diff() == 1 ? 1.0f : 1.12f);
    d->dist += d->speed * in.dt;
    d->score = (int)(d->dist / 10);
    note(d->score);
    d->anim += in.dt * 10;
    d->nextGap -= d->speed * in.dt;
    if (d->nextGap <= 0) {
        for (int i = 0; i < DN_OBS; i++) {
            if (d->o[i].on) continue;
            bool bird = d->score > 120 && rn(100) < 30;
            d->o[i].on = true; d->o[i].x = 420; d->o[i].type = bird ? 1 : 0;
            d->o[i].w = bird ? 28.0f : (float)(14 + rn(14));
            d->o[i].h = bird ? 16.0f : (float)(24 + rn(18));
            d->o[i].y = bird ? (rn(2) ? DN_GROUND - 26.0f : DN_GROUND - 52.0f) : DN_GROUND;
            break;
        }
        d->nextGap = 230.0f + (float)rn(230) + d->speed * 0.35f;
    }
    float dw = d->duck ? 30.0f : 24.0f, dh = d->duck ? 16.0f : 28.0f;
    for (int i = 0; i < DN_OBS; i++) {
        Obstacle *o = &d->o[i];
        if (!o->on) continue;
        o->x -= d->speed * in.dt;
        if (o->x < -40) { o->on = false; continue; }
        float ox0 = o->x + 3, ox1 = o->x + o->w - 3, oy0 = o->y - o->h + 3, oy1 = o->y - 3;
        if (50 + dw - 4 > ox0 && 50 + 3 < ox1 && d->y - 3 > oy0 && d->y - dh + 3 < oy1) { d->over = true; note(d->score); }
    }
}

static void dino_draw(Dino *d) {
    ui_rect(0, 0, 400, 240, C2D_Color32(235, 238, 242, 255));
    ui_rect(0, 22, 400, 218, C2D_Color32(235, 238, 242, 255));
    ui_rect(0, DN_GROUND, 400, 2, C2D_Color32(90, 96, 110, 255));
    for (int i = 0; i < 6; i++) ui_rect(fmodf((float)i * 83.0f + 400.0f - d->dist * 0.8f, 400.0f), DN_GROUND + 8.0f + (float)(i % 3) * 8.0f, 14, 2, C2D_Color32(150, 156, 170, 255));
    ui_rect(0, 0, 400, 22, C_PANEL);
    ui_text(8, 4, 0.45f, C_WHITE, "%s", game_title(kind));
    char line[48];
    snprintf(line, sizeof(line), tr("Puntos %d   Record %d"), d->score, best() > d->score ? best() : d->score);
    ui_text_right(392, 4, 0.45f, COL_GREEN, line);
    u32 ink = C2D_Color32(60, 66, 80, 255);
    for (int i = 0; i < DN_OBS; i++) {
        Obstacle *o = &d->o[i];
        if (!o->on) continue;
        if (o->type == 0) { ui_rect(o->x + o->w / 2 - 3, o->y - o->h, 6, o->h, C2D_Color32(60, 140, 80, 255)); ui_rect(o->x, o->y - o->h * 0.6f, o->w, 5, C2D_Color32(60, 140, 80, 255)); }
        else { ui_rect(o->x, o->y - o->h, o->w, o->h - 4, ink); ui_triangle(o->x, o->y - o->h, o->x + 12, o->y - o->h, o->x + 6, o->y - o->h - (((int)d->anim & 1) ? 10.0f : -2.0f), ink); }
    }
    float y = d->y;
    if (d->duck) { ui_rect(50, y - 16, 30, 16, ink); ui_rect(74, y - 20, 10, 8, ink); ui_rect(78, y - 18, 3, 3, C_WHITE); }
    else {
        ui_rect(50, y - 20, 24, 20, ink); ui_rect(62, y - 30, 18, 14, ink); ui_rect(74, y - 27, 3, 3, C_WHITE);
        float leg = d->y >= DN_GROUND ? (((int)d->anim & 1) ? 0.0f : 4.0f) : 0.0f;
        ui_rect(54, y - 2, 6, 2 + leg * 0.5f, ink); ui_rect(66, y - 2 - leg * 0.5f, 6, 2 + leg * 0.5f, ink);
    }
    if (d->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

/* ============================== LIGHTS OUT ============================= */
typedef struct { u8 g[5][5]; int level, moves, score, cur; bool solved; } Lights;

static void lt_toggle(Lights *l, int r, int c) {
    static const int dr[5] = {0, -1, 1, 0, 0}, dc[5] = {0, 0, 0, -1, 1};
    for (int k = 0; k < 5; k++) { int rr = r + dr[k], cc = c + dc[k]; if (rr >= 0 && rr < 5 && cc >= 0 && cc < 5) l->g[rr][cc] ^= 1; }
}

static void lt_level(Lights *l) {
    memset(l->g, 0, sizeof(l->g));
    int n = clampi(2 + l->level + diff(), 3, 14);
    for (int i = 0; i < n; i++) lt_toggle(l, rn(5), rn(5));
    bool any = false;
    for (int r = 0; r < 5; r++) for (int c = 0; c < 5; c++) any |= l->g[r][c] != 0;
    if (!any) lt_toggle(l, 2, 2);
    l->moves = 0; l->solved = false;
}

static void lt_start(Lights *l) { l->level = 1; l->cur = 12; lt_level(l); }

static void lt_press(Lights *l, int i) {
    if (l->solved) { l->level++; lt_level(l); return; }
    if (i < 0 || i >= 25) return;
    l->cur = i;
    lt_toggle(l, i / 5, i % 5);
    l->moves++;
    bool off = true;
    for (int r = 0; r < 5; r++) for (int c = 0; c < 5; c++) if (l->g[r][c]) off = false;
    if (off) { l->solved = true; l->score += clampi(120 - l->moves * 4, 20, 120); note(l->score); }
}

static void lt_update(Lights *l, GameInput in) {
    int d = pad_dir(in);
    if (d == D_UP && l->cur >= 5) l->cur -= 5;
    if (d == D_DOWN && l->cur < 20) l->cur += 5;
    if (d == D_LEFT && l->cur % 5 > 0) l->cur--;
    if (d == D_RIGHT && l->cur % 5 < 4) l->cur++;
    if (in.down & KEY_A) lt_press(l, l->cur);
}

static void lt_draw_top(Lights *l) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(l->score);
    ui_text(20, 56, 0.6f, C_WHITE, "Nivel %d", l->level);
    ui_text(20, 92, 0.5f, COL_SUBTEXT, "Movimientos: %d", l->moves);
    ui_text(20, 130, 0.4f, COL_SUBTEXT, "Cada toque cambia la casilla y sus vecinas.");
    ui_text(20, 152, 0.4f, COL_SUBTEXT, "Apaga todas las luces.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (l->solved) overlay("Nivel superado", "A o toca: siguiente nivel");
}

static void lt_draw_bottom(Lights *l) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 25; i++) {
        float x = 50.0f + (float)(i % 5) * 44, y = 10.0f + (float)(i / 5) * 44;
        bool on = l->g[i / 5][i % 5];
        ui_rounded(x + 2, y + 2, 40, 40, 8, on ? COL_GREEN : C_PANEL);
        if (on) ui_rounded(x + 8, y + 8, 28, 28, 6, C2D_Color32(255, 255, 255, 70));
        if (i == l->cur) { ui_rect(x, y, 44, 2, C_GOLD); ui_rect(x, y + 42, 44, 2, C_GOLD); ui_rect(x, y, 2, 44, C_GOLD); ui_rect(x + 42, y, 2, 44, C_GOLD); }
    }
}

/* ============================= 15 PUZZLE ============================== */
typedef struct { u8 t[4][4]; int moves, er, ec; float time; bool won, started; } Slide;

static bool sl_move_dir(Slide *s, int dir) {   /* the tile next to the hole slides in `dir` */
    int sr = s->er, sc = s->ec;
    if (dir == D_DOWN) sr--; else if (dir == D_UP) sr++; else if (dir == D_LEFT) sc++; else sc--;
    if (sr < 0 || sr > 3 || sc < 0 || sc > 3) return false;
    s->t[s->er][s->ec] = s->t[sr][sc];
    s->t[sr][sc] = 0;
    s->er = sr; s->ec = sc;
    return true;
}

static bool sl_sorted(const Slide *s) {
    for (int i = 0; i < 15; i++) if (s->t[i / 4][i % 4] != i + 1) return false;
    return true;
}

static void sl_start(Slide *s) {
    for (int i = 0; i < 15; i++) s->t[i / 4][i % 4] = (u8)(i + 1);
    s->t[3][3] = 0; s->er = s->ec = 3;
    int last = -1;
    for (int i = 0; i < 160 + diff() * 60; i++) {
        int d = rn(4);
        if (last >= 0 && d == (last ^ 1)) continue;
        if (sl_move_dir(s, d)) last = d;
    }
    s->moves = 0;
    if (sl_sorted(s)) sl_move_dir(s, D_DOWN);
}

static void sl_after(Slide *s) {
    s->moves++;
    s->started = true;
    if (sl_sorted(s)) { s->won = true; note(clampi(2000 - s->moves * 8 - (int)s->time * 2, 50, 2000)); }
}

static void sl_tap(Slide *s, int i) {
    if (s->won || i < 0) return;
    int r = i / 4, c = i % 4;
    if (r != s->er && c != s->ec) return;
    int dir = r < s->er ? D_DOWN : r > s->er ? D_UP : c > s->ec ? D_LEFT : D_RIGHT;
    int n = r != s->er ? abs(r - s->er) : abs(c - s->ec);
    for (int k = 0; k < n; k++) sl_move_dir(s, dir);
    if (n) sl_after(s);
}

static void sl_update(Slide *s, GameInput in) {
    if (s->started && !s->won) s->time += in.dt;
    int d = pad_dir(in);
    if (d >= 0 && !s->won && sl_move_dir(s, d)) sl_after(s);
}

static void sl_draw_top(Slide *s) {
    ui_rect(0, 0, 400, 240, C_BG);
    header(s->won ? clampi(2000 - s->moves * 8 - (int)s->time * 2, 50, 2000) : 0);
    ui_text(20, 56, 0.55f, C_WHITE, "Movimientos: %d", s->moves);
    ui_text(20, 90, 0.55f, C_WHITE, "Tiempo: %d s", (int)s->time);
    ui_text(20, 130, 0.4f, COL_SUBTEXT, "Toca una ficha en la misma fila o columna del hueco.");
    ui_text(20, 152, 0.4f, COL_SUBTEXT, "Tambien con la cruceta.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (s->won) overlay("Resuelto", "X: jugar de nuevo   B: menu");
}

static void sl_draw_bottom(Slide *s) {
    ui_rect(0, 0, 320, 240, C_BG);
    for (int i = 0; i < 16; i++) {
        int v = s->t[i / 4][i % 4];
        if (!v) continue;
        float x = 44.0f + (float)(i % 4) * 58, y = 4.0f + (float)(i / 4) * 58;
        bool ok = v == i + 1;
        ui_rounded(x, y, 54, 54, 8, ok ? C_LINE : C_PANEL);
        char n[4];
        snprintf(n, sizeof(n), "%d", v);
        ui_text_center(x + 27, y + 14, 0.75f, ok ? COL_GREEN : C_WHITE, n);
    }
}

/* ============================== dispatcher ============================= */
static union { Pong pong; Whack whack; Memory mem; Simon simon; TicTac tt; Connect4 c4; Asteroids as; Dino dino; Lights lt; Slide sl; } st;

static void reset(void) {
    memset(&st, 0, sizeof(st));
    rng ^= (u32)osGetTime() * 2654435761u;
    if (!rng) rng = 0x2545F491u;
    mem_cursor = 0;
    switch (kind) {
        case GAME_PONG: pong_start(&st.pong); break;
        case GAME_WHACK: whack_start(&st.whack); break;
        case GAME_MEMORY: mem_start(&st.mem); break;
        case GAME_SIMON: simon_start(&st.simon); break;
        case GAME_TICTAC: tt_start(&st.tt); break;
        case GAME_CONNECT4: c4_start(&st.c4); break;
        case GAME_ASTEROIDS: as_start(&st.as); break;
        case GAME_DINO: dino_start(&st.dino); break;
        case GAME_LIGHTS: lt_start(&st.lt); break;
        default: sl_start(&st.sl); break;
    }
}

void more_start(GameKind k) { kind = k; reset(); }

void more_update(GameInput in) {
    if (in.down & KEY_X) { reset(); return; }
    switch (kind) {
        case GAME_PONG: pong_update(&st.pong, in); break;
        case GAME_WHACK: whack_update(&st.whack, in); break;
        case GAME_MEMORY: mem_update(&st.mem, in); break;
        case GAME_SIMON: simon_update(&st.simon, in); break;
        case GAME_TICTAC: tt_update(&st.tt, in); break;
        case GAME_CONNECT4: c4_update(&st.c4, in); break;
        case GAME_ASTEROIDS: as_update(&st.as, in); break;
        case GAME_DINO: dino_update(&st.dino, in); break;
        case GAME_LIGHTS: lt_update(&st.lt, in); break;
        default: sl_update(&st.sl, in); break;
    }
}

void more_touch(int x, int y) {
    switch (kind) {
        case GAME_WHACK: whack_hit(&st.whack, grid_cell(x, y, 16, 24, 96, 68, 3, 3)); break;
        case GAME_MEMORY: { int i = grid_cell(x, y, 8, 8, 76, 58, 4, 4); if (i >= 0) { mem_cursor = i; mem_pick(&st.mem, i); } break; }
        case GAME_SIMON: {
            int b = x < 160 ? (y < 120 ? 0 : 2) : (y < 120 ? 1 : 3);
            if (y >= 20 && y < 220) simon_press(&st.simon, b);
            break;
        }
        case GAME_TICTAC: tt_place(&st.tt, grid_cell(x, y, 52, 12, 72, 72, 3, 3)); break;
        case GAME_CONNECT4: { int c = (x - 6) / 44; if (x >= 6 && y >= 24 && y < 214 && c < 7) c4_play(&st.c4, c); else if (st.c4.over) c4_play(&st.c4, 0); break; }
        case GAME_LIGHTS: lt_press(&st.lt, st.lt.solved ? 0 : grid_cell(x, y, 50, 10, 44, 44, 5, 5)); break;
        case GAME_SLIDE: sl_tap(&st.sl, grid_cell(x, y, 44, 4, 58, 58, 4, 4)); break;
        default: break;   /* pong, dino and asteroids read the touch from GameInput */
    }
}

void more_draw_top(void) {
    switch (kind) {
        case GAME_PONG: pong_draw(&st.pong); break;
        case GAME_WHACK: whack_draw_top(&st.whack); break;
        case GAME_MEMORY: mem_draw_top(&st.mem); break;
        case GAME_SIMON: simon_draw_top(&st.simon); break;
        case GAME_TICTAC: tt_draw_top(&st.tt); break;
        case GAME_CONNECT4: c4_draw_top(&st.c4); break;
        case GAME_ASTEROIDS: as_draw(&st.as); break;
        case GAME_DINO: dino_draw(&st.dino); break;
        case GAME_LIGHTS: lt_draw_top(&st.lt); break;
        default: sl_draw_top(&st.sl); break;
    }
}

void more_draw_bottom(void) {
    switch (kind) {
        case GAME_PONG: hint_bottom("Desliza el stylus o usa el stick", "Si la consola falla, sumas 5 puntos"); break;
        case GAME_WHACK: whack_draw_bottom(&st.whack); break;
        case GAME_MEMORY: mem_draw_bottom(&st.mem); break;
        case GAME_SIMON: simon_draw_bottom(&st.simon); break;
        case GAME_TICTAC: tt_draw_bottom(&st.tt); break;
        case GAME_CONNECT4: c4_draw_bottom(&st.c4); break;
        case GAME_ASTEROIDS: hint_bottom("Cruceta: girar   A: propulsor", "R, L o Y: disparar (tambien tocando)"); break;
        case GAME_DINO: hint_bottom("A, cruceta arriba o toca: saltar", "Cruceta abajo: agacharse"); break;
        case GAME_LIGHTS: lt_draw_bottom(&st.lt); break;
        default: sl_draw_bottom(&st.sl); break;
    }
}
