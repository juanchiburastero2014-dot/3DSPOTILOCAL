#include "games.h"
#include "gfx_ui.h"
#include "i18n.h"

/* One active game, fixed storage, and no ownership of scenes or frame lifetime. */
#define P_MINT C2D_Color32(132, 239, 172, 255)
#define P_DIM C2D_Color32(28, 48, 38, 255)
#define P_INK C2D_Color32(12, 23, 19, 255)
#define P_RED C2D_Color32(243, 133, 119, 255)
#define P_GOLD C2D_Color32(233, 212, 129, 255)
#define BLOCK_N 8
#define BLOCK_X 12
#define BLOCK_Y 32
#define BLOCK_CELL 20
#define STACK_W 10
#define STACK_H 18
#define STACK_X 112
#define STACK_Y 32
#define STACK_CELL 11
#define TILE 16
#define LEVEL_W 180
#define LEVEL_H 15
#define COIN_MAX 64
#define ENEMY_MAX 8
#define HERO_W 12.0f
#define HERO_H 18.0f
#define CHECKPOINT_X (88 * TILE)
#define FINISH_X (174 * TILE)

/* Bits are four columns wide, starting at the upper-left anchor. */
typedef struct { u16 bits; u8 w, h; } BlockShape;
static const BlockShape block_shapes[] = {
    {0x0001, 1, 1}, {0x0003, 2, 1}, {0x0011, 1, 2},
    {0x0007, 3, 1}, {0x0111, 1, 3}, {0x000f, 4, 1},
    {0x1111, 1, 4}, {0x0033, 2, 2}, {0x0031, 2, 2},
    {0x0032, 2, 2}, {0x0013, 2, 2}, {0x0023, 2, 2},
    {0x0072, 3, 2}, {0x0311, 2, 3}, {0x0777, 3, 3}
};
#define SHAPE_COUNT ((int)(sizeof(block_shapes) / sizeof(block_shapes[0])))

/* I, O, T, S, Z, J, L. Rotation is clockwise; O stays fixed. */
static const u16 tetromino[7][4] = {
    {0x00f0, 0x4444, 0x0f00, 0x2222},
    {0x0066, 0x0066, 0x0066, 0x0066},
    {0x0072, 0x0262, 0x0270, 0x0232},
    {0x0036, 0x0462, 0x0360, 0x0231},
    {0x0063, 0x0264, 0x0630, 0x0132},
    {0x0071, 0x0226, 0x0470, 0x0322},
    {0x0074, 0x0622, 0x0170, 0x0223}
};

typedef struct { int dir; float wait; } KeyRepeat;
typedef struct {
    u8 board[BLOCK_N][BLOCK_N];
    int tray[3], selected, cx, cy, score, lines, placed;
    unsigned clear_rows, clear_cols;
    float flash, invalid;
    bool over;
    KeyRepeat horizontal, vertical;
} BlocksState;
typedef struct {
    u8 board[STACK_H][STACK_W];
    int bag[7], bag_pos, piece, next, rotation, x, y;
    int score, lines, level, lock_resets, last_clear;
    float fall, lock, flash;
    bool over;
    KeyRepeat horizontal;
} StackState;
typedef struct { float x, y; bool alive; } LevelCoin;
typedef struct {
    float x, y, left, right, speed;
    int dir;
    bool alive;
} LevelEnemy;
typedef struct {
    u8 tiles[LEVEL_H][LEVEL_W];
    LevelCoin coins[COIN_MAX];
    LevelEnemy enemies[ENEMY_MAX];
    int coin_count, enemy_count, collected, lives, score, facing;
    float x, y, vx, vy, camera, coyote, jump_buffer, invulnerable;
    bool grounded, checkpoint, over, won;
} PlatformState;
static union {
    BlocksState blocks;
    StackState stack;
    PlatformState platform;
} puzzle;
static GameKind active_kind = GAME_BLOCKS;
static u32 random_state = 0x8a35d29bu;
static float animation_time;

static int add_score(int value, int amount) {
    /* Endless puzzles must not eventually overflow signed scores. */
    return value + (amount < 999999 - value ? amount : 999999 - value);
}

static u32 random_u32(void) {
    random_state ^= random_state << 13;
    random_state ^= random_state >> 17;
    random_state ^= random_state << 5;
    return random_state;
}

static float minimum(float a, float b) { return a < b ? a : b; }
static float maximum(float a, float b) { return a > b ? a : b; }
static float approach(float value, float target, float step) {
    if (value < target) return minimum(value + step, target);
    return maximum(value - step, target);
}

static int repeat_step(KeyRepeat *repeat, int dir, bool pressed, float dt) {
    if (!dir) {
        repeat->dir = 0;
        repeat->wait = 0;
        return 0;
    }
    if (repeat->dir != dir || pressed) {
        repeat->dir = dir;
        repeat->wait = 0.22f;
        return dir;
    }
    repeat->wait -= dt;
    if (repeat->wait <= 0) {
        repeat->wait += 0.075f;
        return dir;
    }
    return 0;
}

static u32 piece_color(int id) {
    switch (id % 7) {
        case 0: return P_MINT;
        case 1: return COL_GREEN;
        case 2: return C2D_Color32(78, 193, 153, 255);
        case 3: return C2D_Color32(167, 214, 115, 255);
        case 4: return C2D_Color32(70, 156, 116, 255);
        case 5: return C2D_Color32(109, 202, 188, 255);
        default: return C2D_Color32(194, 225, 150, 255);
    }
}

static void cell_draw(float x, float y, float size, u32 color) {
    ui_rect(x + 1, y + 1, size - 2, size - 2, color);
    ui_rect(x + 2, y + 2, size - 4, 2, C2D_Color32(255, 255, 255, 50));
}

static void outline(float x, float y, float w, float h, u32 color) {
    ui_rect(x, y, w, 1, color);
    ui_rect(x, y + h - 1, w, 1, color);
    ui_rect(x, y, 1, h, color);
    ui_rect(x + w - 1, y, 1, h, color);
}

static void footer(void) {
    ui_rect(0, 217, BOT_W, 23, P_INK);
    ui_text_center(160, 222, 0.37f, COL_SUBTEXT, "X reinicia  |  B menu  |  START pausa");
}

static void result_card(const char *title, const char *detail, bool success) {
    ui_rect(57, 86, 286, 81, P_INK);
    outline(57, 86, 286, 81, success ? COL_GREEN : P_RED);
    ui_text_center(200, 97, 0.64f, success ? P_MINT : P_RED, title);
    ui_text_center(200, 123, 0.43f, COL_TEXT, detail);
    ui_text_center(200, 145, 0.38f, COL_SUBTEXT, "X reinicia  /  B vuelve al menu");
}

/* -------------------------- Jardin de bloques -------------------------- */
static bool blocks_fits(int shape_id, int bx, int by) {
    const BlocksState *s = &puzzle.blocks;
    if (shape_id < 0 || shape_id >= SHAPE_COUNT) return false;
    const BlockShape *shape = &block_shapes[shape_id];
    if (bx < 0 || by < 0 || bx + shape->w > BLOCK_N || by + shape->h > BLOCK_N)
        return false;
    for (int y = 0; y < shape->h; ++y)
        for (int x = 0; x < shape->w; ++x)
            if ((shape->bits & (1u << (y * 4 + x))) && s->board[by + y][bx + x])
                return false;
    return true;
}

static bool blocks_has_move(void) {
    for (int p = 0; p < 3; ++p)
        if (puzzle.blocks.tray[p] >= 0)
            for (int y = 0; y < BLOCK_N; ++y)
                for (int x = 0; x < BLOCK_N; ++x)
                    if (blocks_fits(puzzle.blocks.tray[p], x, y)) return true;
    return false;
}

static void blocks_refill(void) {
    for (int i = 0; i < 3; ++i)
        puzzle.blocks.tray[i] = (int)(random_u32() % SHAPE_COUNT);
    puzzle.blocks.selected = 0;
}

static void blocks_select(int direction) {
    BlocksState *s = &puzzle.blocks;
    for (int n = 1; n <= 3; ++n) {
        int i = (s->selected + direction * n + 6) % 3;
        if (s->tray[i] >= 0) {
            s->selected = i;
            return;
        }
    }
}

static void blocks_place(void) {
    BlocksState *s = &puzzle.blocks;
    if (s->over) return;
    int id = s->tray[s->selected];
    if (!blocks_fits(id, s->cx, s->cy)) {
        s->invalid = 1.2f;
        return;
    }
    const BlockShape *shape = &block_shapes[id];
    int cells = 0;
    for (int y = 0; y < shape->h; ++y)
        for (int x = 0; x < shape->w; ++x)
            if (shape->bits & (1u << (y * 4 + x))) {
                s->board[s->cy + y][s->cx + x] = (u8)(id % 7 + 1);
                ++cells;
            }
    s->tray[s->selected] = -1;
    s->placed = add_score(s->placed, 1);
    s->invalid = 0;

    /* Find BOTH sets before removing anything: intersections clear together. */
    unsigned rows = 0, cols = 0;
    int lines = 0;
    for (int i = 0; i < BLOCK_N; ++i) {
        bool row = true, col = true;
        for (int j = 0; j < BLOCK_N; ++j) {
            if (!s->board[i][j]) row = false;
            if (!s->board[j][i]) col = false;
        }
        if (row) { rows |= 1u << i; ++lines; }
        if (col) { cols |= 1u << i; ++lines; }
    }
    for (int y = 0; y < BLOCK_N; ++y)
        for (int x = 0; x < BLOCK_N; ++x)
            if ((rows & (1u << y)) || (cols & (1u << x))) s->board[y][x] = 0;
    s->score = add_score(s->score, cells * 10 + lines * 100 + lines * lines * 25);
    s->lines = add_score(s->lines, lines);
    if (lines) {
        s->clear_rows = rows;
        s->clear_cols = cols;
        s->flash = 0.55f;
    }
    if (s->tray[0] < 0 && s->tray[1] < 0 && s->tray[2] < 0) blocks_refill();
    else blocks_select(1);
    s->over = !blocks_has_move();
}

static void blocks_update(GameInput input) {
    BlocksState *s = &puzzle.blocks;
    s->flash = maximum(0, s->flash - input.dt);
    s->invalid = maximum(0, s->invalid - input.dt);
    if (s->over) return;
    u32 keys = input.held | input.down;
    int dx = !!(keys & KEY_DRIGHT) - !!(keys & KEY_DLEFT);
    int dy = !!(keys & KEY_DDOWN) - !!(keys & KEY_DUP);
    dx = repeat_step(&s->horizontal, dx, (input.down & (KEY_DLEFT | KEY_DRIGHT)) != 0, input.dt);
    dy = repeat_step(&s->vertical, dy, (input.down & (KEY_DUP | KEY_DDOWN)) != 0, input.dt);
    s->cx = clampi(s->cx + dx, 0, BLOCK_N - 1);
    s->cy = clampi(s->cy + dy, 0, BLOCK_N - 1);
    if (input.down & KEY_L) blocks_select(-1);
    if (input.down & KEY_R) blocks_select(1);
    if (input.down & KEY_A) blocks_place();
}

static void blocks_draw_top(void) {
    const BlocksState *s = &puzzle.blocks;
    ui_rect(0, 0, TOP_W, TOP_H, P_INK);
    ui_rect(16, 18, 4, 29, COL_GREEN);
    ui_text(29, 14, 0.72f, COL_TEXT, "JARDIN DE BLOQUES");
    ui_text(30, 42, 0.4f, COL_SUBTEXT, "Ordena. Conecta. Deja espacio.");
    ui_rect(18, 72, 173, 77, P_DIM);
    ui_text(30, 79, 0.39f, P_MINT, "PUNTOS");
    ui_text(29, 96, 1.0f, COL_TEXT, "%d", s->score);
    ui_rect(202, 72, 180, 77, COL_SURFACE);
    ui_text(215, 84, 0.47f, COL_TEXT, "%d lineas", s->lines);
    ui_text(215, 112, 0.44f, COL_SUBTEXT, "%d piezas colocadas", s->placed);
    ui_text(22, 164, 0.45f, P_MINT, "Completa filas o columnas de 8.");
    ui_text(22, 185, 0.42f, COL_SUBTEXT, "Usa las 3 piezas para renovar la bandeja.");
    ui_text(22, 207, 0.42f, s->invalid > 0 ? P_RED : P_MINT,
            "%s", tr(s->invalid > 0 ? "No cabe: cambia de casilla o de pieza." :
            s->flash > 0 ? "Lineas conectadas! Sigue creciendo." : "La casilla marca la esquina de la pieza."));
    if (s->over) result_card("SIN ESPACIO", "Ninguna pieza de la bandeja cabe.", false);
}

static void blocks_draw_bottom(void) {
    const BlocksState *s = &puzzle.blocks;
    ui_rect(0, 0, BOT_W, BOT_H, COL_BG);
    ui_text(12, 8, 0.45f, COL_TEXT, "TU JARDIN");
    ui_text(190, 8, 0.4f, COL_SUBTEXT, "PIEZAS");
    int id = s->tray[s->selected];
    const BlockShape *shape = id >= 0 ? &block_shapes[id] : NULL;
    bool fits = blocks_fits(id, s->cx, s->cy);
    for (int y = 0; y < BLOCK_N; ++y) {
        for (int x = 0; x < BLOCK_N; ++x) {
            float px = BLOCK_X + x * BLOCK_CELL, py = BLOCK_Y + y * BLOCK_CELL;
            ui_rect(px + 1, py + 1, BLOCK_CELL - 2, BLOCK_CELL - 2, P_DIM);
            if (s->board[y][x]) cell_draw(px, py, BLOCK_CELL, piece_color(s->board[y][x] - 1));
            int sx = x - s->cx, sy = y - s->cy;
            if (!s->over && shape && sx >= 0 && sy >= 0 && sx < shape->w && sy < shape->h &&
                (shape->bits & (1u << (sy * 4 + sx))))
                outline(px + 2, py + 2, BLOCK_CELL - 4, BLOCK_CELL - 4, fits ? P_MINT : P_RED);
            if (s->flash > 0 && ((s->clear_rows & (1u << y)) || (s->clear_cols & (1u << x))))
                ui_rect(px + 3, py + 8, BLOCK_CELL - 6, 3, COL_GREEN);
        }
    }
    outline(BLOCK_X + s->cx * BLOCK_CELL, BLOCK_Y + s->cy * BLOCK_CELL,
            BLOCK_CELL, BLOCK_CELL, COL_TEXT);
    for (int i = 0; i < 3; ++i) {
        float ty = 32 + i * 54;
        ui_rect(186, ty, 122, 50, i == s->selected ? P_DIM : COL_SURFACE);
        if (i == s->selected) outline(186, ty, 122, 50, COL_GREEN);
        if (s->tray[i] < 0) {
            ui_text_center(247, ty + 15, 0.4f, COL_SUBTEXT, "Usada");
        } else {
            const BlockShape *p = &block_shapes[s->tray[i]];
            float ox = 247 - p->w * 5, oy = ty + 25 - p->h * 5;
            for (int y = 0; y < p->h; ++y)
                for (int x = 0; x < p->w; ++x)
                    if (p->bits & (1u << (y * 4 + x)))
                        cell_draw(ox + x * 10, oy + y * 10, 10, piece_color(s->tray[i]));
        }
    }
    ui_text_center(160, 199, 0.34f, COL_SUBTEXT, "Toca pieza y casilla | Dpad mueve, L/R elige, A pone");
    footer();
}

/* ----------------------------- Torre pulso ----------------------------- */
static int stack_take_bag(void) {
    StackState *s = &puzzle.stack;
    if (s->bag_pos >= 7) {
        for (int i = 0; i < 7; ++i) s->bag[i] = i;
        for (int i = 6; i > 0; --i) {
            int j = (int)(random_u32() % (u32)(i + 1));
            int swap = s->bag[i]; s->bag[i] = s->bag[j]; s->bag[j] = swap;
        }
        s->bag_pos = 0;
    }
    return s->bag[s->bag_pos++];
}

static bool stack_fits(int x, int y, int rotation) {
    const StackState *s = &puzzle.stack;
    u16 bits = tetromino[s->piece][rotation];
    for (int cy = 0; cy < 4; ++cy) {
        for (int cx = 0; cx < 4; ++cx) {
            if (!(bits & (1u << (cy * 4 + cx)))) continue;
            int bx = x + cx, by = y + cy;
            if (bx < 0 || bx >= STACK_W || by >= STACK_H || by < -4) return false;
            if (by >= 0 && s->board[by][bx]) return false;
        }
    }
    return true;
}

static void stack_spawn(void) {
    StackState *s = &puzzle.stack;
    s->piece = s->next;
    s->next = stack_take_bag();
    s->rotation = 0;
    s->x = 3;
    s->y = -1;
    s->fall = s->lock = 0;
    s->lock_resets = 0;
    if (!stack_fits(s->x, s->y, s->rotation)) s->over = true;
}

static void stack_lock(void) {
    StackState *s = &puzzle.stack;
    u16 bits = tetromino[s->piece][s->rotation];
    /* Check top-out before writing any part of a piece above the board. */
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
            if ((bits & (1u << (y * 4 + x))) && s->y + y < 0) {
                s->over = true;
                return;
            }
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
            if (bits & (1u << (y * 4 + x)))
                s->board[s->y + y][s->x + x] = (u8)(s->piece + 1);
    int cleared = 0, dest = STACK_H - 1;
    for (int y = STACK_H - 1; y >= 0; --y) {
        bool full = true;
        for (int x = 0; x < STACK_W; ++x)
            if (!s->board[y][x]) full = false;
        if (full) { ++cleared; continue; }
        if (dest != y) memcpy(s->board[dest], s->board[y], STACK_W);
        --dest;
    }
    while (dest >= 0) memset(s->board[dest--], 0, STACK_W);
    if (cleared) {
        static const int rewards[5] = {0, 100, 300, 500, 800};
        s->score = add_score(s->score, rewards[clampi(cleared, 0, 4)] * s->level);
        s->lines = add_score(s->lines, cleared);
        s->level = clampi(1 + s->lines / 10, 1, 15);
        s->last_clear = cleared;
        s->flash = 1.2f;
    }
    stack_spawn();
}

static void stack_reset_lock(bool was_grounded) {
    StackState *s = &puzzle.stack;
    if (was_grounded && s->lock_resets < 8) {
        s->lock = 0;
        ++s->lock_resets;
    }
}

static void stack_rotate(void) {
    StackState *s = &puzzle.stack;
    if (s->piece == 1) return;
    int rotation = (s->rotation + 1) % 4;
    bool grounded = !stack_fits(s->x, s->y + 1, s->rotation);
    static const int kicks[] = {0, -1, 1, -2, 2};
    /* Modest wall/floor kicks, not a claim to any particular rotation ruleset. */
    for (int up = 0; up <= 1; ++up)
        for (int i = 0; i < 5; ++i)
            if (stack_fits(s->x + kicks[i], s->y - up, rotation)) {
                s->x += kicks[i];
                s->y -= up;
                s->rotation = rotation;
                stack_reset_lock(grounded);
                return;
            }
}

static int stack_ghost_y(void) {
    const StackState *s = &puzzle.stack;
    int y = s->y;
    while (stack_fits(s->x, y + 1, s->rotation)) ++y;
    return y;
}

static void stack_update(GameInput input) {
    StackState *s = &puzzle.stack;
    s->flash = maximum(0, s->flash - input.dt);
    if (s->over) return;
    u32 keys = input.held | input.down;
    int dx = !!(keys & (KEY_DRIGHT | KEY_R)) - !!(keys & (KEY_DLEFT | KEY_L));
    dx = repeat_step(&s->horizontal, dx,
                     (input.down & (KEY_DLEFT | KEY_DRIGHT | KEY_L | KEY_R)) != 0, input.dt);
    if (dx && stack_fits(s->x + dx, s->y, s->rotation)) {
        bool grounded = !stack_fits(s->x, s->y + 1, s->rotation);
        s->x += dx;
        stack_reset_lock(grounded);
    }
    if (input.down & (KEY_A | KEY_DUP)) stack_rotate();
    if (input.down & KEY_Y) {
        int y = stack_ghost_y();
        s->score = add_score(s->score, (y - s->y) * 2);
        s->y = y;
        stack_lock();
        return;
    }
    bool soft = (keys & KEY_DDOWN) != 0;
    float interval = soft ? 0.045f : maximum(0.075f, 0.70f - (s->level - 1) * 0.045f);
    /* Switching to soft drop must not spend a whole slow-gravity interval. */
    if (soft) s->fall = minimum(s->fall, interval);
    s->fall += input.dt;
    while (s->fall >= interval) {
        s->fall -= interval;
        if (!stack_fits(s->x, s->y + 1, s->rotation)) { s->fall = 0; break; }
        ++s->y;
        if (soft) s->score = add_score(s->score, 1);
    }
    if (!stack_fits(s->x, s->y + 1, s->rotation)) {
        s->lock += input.dt;
        if (s->lock >= 0.36f) stack_lock();
    } else s->lock = 0;
}

static void stack_draw_piece(int piece, int rotation, int bx, int by, bool ghost) {
    u16 bits = tetromino[piece][rotation];
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
            if ((bits & (1u << (y * 4 + x))) && by + y >= 0 && by + y < STACK_H) {
                float px = STACK_X + (bx + x) * STACK_CELL;
                float py = STACK_Y + (by + y) * STACK_CELL;
                if (ghost) outline(px + 2, py + 2, STACK_CELL - 4, STACK_CELL - 4, P_MINT);
                else cell_draw(px, py, STACK_CELL, piece_color(piece));
            }
}

static void stack_draw_top(void) {
    const StackState *s = &puzzle.stack;
    ui_rect(0, 0, TOP_W, TOP_H, P_INK);
    ui_text(12, 6, 0.6f, COL_TEXT, "TORRE PULSO");
    ui_text_right(387, 9, 0.38f, P_MINT, "ENCUENTRA TU RITMO");
    ui_rect(STACK_X - 2, STACK_Y - 2, STACK_W * STACK_CELL + 4, STACK_H * STACK_CELL + 4, COL_BAR_BG);
    ui_rect(STACK_X, STACK_Y, STACK_W * STACK_CELL, STACK_H * STACK_CELL, COL_SURFACE);
    for (int y = 0; y < STACK_H; ++y) {
        ui_rect(STACK_X, STACK_Y + y * STACK_CELL, STACK_W * STACK_CELL, 1, P_DIM);
        for (int x = 0; x < STACK_W; ++x)
            if (s->board[y][x])
                cell_draw(STACK_X + x * STACK_CELL, STACK_Y + y * STACK_CELL,
                          STACK_CELL, piece_color(s->board[y][x] - 1));
    }
    if (!s->over) {
        stack_draw_piece(s->piece, s->rotation, s->x, stack_ghost_y(), true);
        stack_draw_piece(s->piece, s->rotation, s->x, s->y, false);
    }
    ui_text(12, 49, 0.36f, COL_SUBTEXT, "PUNTOS");
    ui_text(12, 67, 0.65f, COL_TEXT, "%d", s->score);
    ui_text(12, 108, 0.36f, COL_SUBTEXT, "LINEAS");
    ui_text(12, 126, 0.6f, P_MINT, "%d", s->lines);
    ui_text(12, 173, 0.36f, COL_SUBTEXT, "NIVEL");
    ui_text(12, 191, 0.68f, P_MINT, "%02d", s->level);
    ui_text(244, 41, 0.4f, COL_SUBTEXT, "SIGUIENTE");
    ui_rect(241, 63, 143, 65, P_DIM);
    u16 bits = tetromino[s->next][0];
    for (int y = 0; y < 4; ++y)
        for (int x = 0; x < 4; ++x)
            if (bits & (1u << (y * 4 + x)))
                cell_draw(280 + x * 15, 78 + y * 15, 15, piece_color(s->next));
    ui_text(244, 150, 0.4f, P_MINT, "Y: caida directa");
    ui_text(244, 172, 0.36f, COL_SUBTEXT, "El contorno indica");
    ui_text(244, 188, 0.36f, COL_SUBTEXT, "donde aterrizara.");
    if (s->flash > 0) ui_text(244, 214, 0.43f, P_GOLD, "+%d lineas!", s->last_clear);
    if (s->over) result_card("TORRE COMPLETA", "Las piezas alcanzaron el techo.", false);
}

static void stack_draw_bottom(void) {
    const StackState *s = &puzzle.stack;
    ui_rect(0, 0, BOT_W, BOT_H, COL_BG);
    ui_text(17, 13, 0.59f, COL_TEXT, "CADA HUECO CUENTA");
    ui_text(18, 43, 0.4f, COL_SUBTEXT, "Completa filas. Evita llegar al techo.");
    ui_rect(14, 72, 292, 100, P_DIM);
    ui_text(26, 82, 0.46f, COL_TEXT, "Dpad izq/der o L/R: mover");
    ui_text(26, 104, 0.46f, P_MINT, "A o arriba: girar");
    ui_text(26, 126, 0.46f, COL_TEXT, "Abajo: bajar  |  Y: soltar");
    ui_text(26, 149, 0.35f, COL_SUBTEXT, "Mantener direccion repite el movimiento.");
    ui_text(18, 182, 0.38f, COL_SUBTEXT, "Nivel %d  /  %d de 10 lineas", s->level, s->lines % 10);
    ui_rect(18, 204, 284, 4, P_DIM);
    ui_rect(18, 204, 284 * (s->lines % 10) / 10.0f, 4, COL_GREEN);
    footer();
}

/* ---------------------------- Ruta del brote ---------------------------- */
static int tile_coord(float position) {
    int tile = (int)(position / TILE);
    return position < tile * TILE ? tile - 1 : tile;
}

static bool platform_solid(int x, int y) {
    if (x < 0 || x >= LEVEL_W) return true;
    if (y < 0 || y >= LEVEL_H) return false;
    return puzzle.platform.tiles[y][x] != 0;
}

static void platform_coin(float x, float y) {
    PlatformState *s = &puzzle.platform;
    if (s->coin_count < COIN_MAX) s->coins[s->coin_count++] = (LevelCoin){x, y, true};
}

static void platform_camera(void) {
    PlatformState *s = &puzzle.platform;
    s->camera = minimum(maximum(s->x - 128, 0), LEVEL_W * TILE - TOP_W);
}

static void platform_respawn(void) {
    PlatformState *s = &puzzle.platform;
    s->x = s->checkpoint ? CHECKPOINT_X : 3 * TILE;
    s->y = 12 * TILE - HERO_H;
    s->vx = s->vy = 0;
    s->grounded = true;
    s->coyote = 0.09f;
    s->jump_buffer = 0;
    s->invulnerable = 1.5f;
    platform_camera();
}

static void platform_build(void) {
    PlatformState *s = &puzzle.platform;
    /* Ground gaps are only 2-3 tiles; a full jump spans over 7 tiles.
       Ledges are optional and 48 px above the ground (jump height > 60 px). */
    static const int gaps[][2] = {{18, 2}, {38, 3}, {64, 2}, {94, 3}, {122, 3}, {150, 2}};
    static const int ledges[][2] = {{8, 4}, {26, 4}, {47, 5}, {72, 4}, {83, 3},
                                  {104, 4}, {131, 4}, {141, 4}, {160, 5}};
    static const int enemy_tiles[] = {14, 32, 55, 79, 112, 137, 168};
    for (int y = 12; y < LEVEL_H; ++y)
        for (int x = 0; x < LEVEL_W; ++x) s->tiles[y][x] = 1;
    for (unsigned i = 0; i < sizeof(gaps) / sizeof(gaps[0]); ++i) {
        for (int x = gaps[i][0]; x < gaps[i][0] + gaps[i][1]; ++x)
            for (int y = 12; y < LEVEL_H; ++y) s->tiles[y][x] = 0;
        platform_coin((gaps[i][0] + gaps[i][1] * 0.5f) * TILE, 159);
    }
    for (unsigned i = 0; i < sizeof(ledges) / sizeof(ledges[0]); ++i) {
        for (int x = ledges[i][0]; x < ledges[i][0] + ledges[i][1]; ++x) s->tiles[9][x] = 2;
        for (int x = ledges[i][0]; x < ledges[i][0] + ledges[i][1]; x += 2)
            platform_coin(x * TILE + 8, 133);
    }
    for (int x = 5; x < 173; x += 7)
        if (platform_solid(x, 12) && platform_solid(x + 1, 12)) platform_coin(x * TILE + 8, 177);
    for (unsigned i = 0; i < sizeof(enemy_tiles) / sizeof(enemy_tiles[0]) && s->enemy_count < ENEMY_MAX; ++i) {
        float x = enemy_tiles[i] * TILE;
        s->enemies[s->enemy_count++] = (LevelEnemy){x, 178, x - 24, x + 24,
                                                                   27 + (i % 3) * 5, 1, true};
    }
    s->lives = 3;
    s->facing = 1;
    platform_respawn();
}

static bool overlaps(float ax, float ay, float aw, float ah,
                     float bx, float by, float bw, float bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

static void platform_move_x(float dt) {
    PlatformState *s = &puzzle.platform;
    s->x += s->vx * dt;
    int left = tile_coord(s->x), right = tile_coord(s->x + HERO_W - 0.01f);
    int top = tile_coord(s->y), bottom = tile_coord(s->y + HERO_H - 0.01f);
    for (int y = top; y <= bottom; ++y)
        for (int x = left; x <= right; ++x)
            if (platform_solid(x, y)) {
                if (s->vx > 0) s->x = x * TILE - HERO_W;
                else if (s->vx < 0) s->x = (x + 1) * TILE;
                s->vx = 0;
            }
}

static void platform_move_y(float dt) {
    PlatformState *s = &puzzle.platform;
    s->y += s->vy * dt;
    s->grounded = false;
    int left = tile_coord(s->x), right = tile_coord(s->x + HERO_W - 0.01f);
    int top = tile_coord(s->y), bottom = tile_coord(s->y + HERO_H - 0.01f);
    for (int y = top; y <= bottom; ++y)
        for (int x = left; x <= right; ++x)
            if (platform_solid(x, y)) {
                if (s->vy > 0) {
                    s->y = y * TILE - HERO_H;
                    s->grounded = true;
                } else if (s->vy < 0) s->y = (y + 1) * TILE;
                s->vy = 0;
            }
}

static void platform_hurt(void) {
    PlatformState *s = &puzzle.platform;
    --s->lives;
    if (s->lives <= 0) { s->over = true; return; }
    platform_respawn();
}

static bool platform_step(float dt, float direction, bool hold_jump) {
    PlatformState *s = &puzzle.platform;
    s->invulnerable = maximum(0, s->invulnerable - dt);
    s->jump_buffer = maximum(0, s->jump_buffer - dt);
    if (s->grounded) s->coyote = 0.09f;
    else s->coyote = maximum(0, s->coyote - dt);
    if (s->jump_buffer > 0 && s->coyote > 0) {
        s->vy = -275;
        s->grounded = false;
        s->jump_buffer = s->coyote = 0;
    }
    s->vx = approach(s->vx, direction * 145, (s->grounded ? 1100 : 650) * dt);
    if (direction != 0) s->facing = direction > 0 ? 1 : -1;
    float gravity = s->vy < 0 ? (hold_jump ? 620 : 1120) : 900;
    s->vy = minimum(s->vy + gravity * dt, 420);
    float previous_bottom = s->y + HERO_H;
    platform_move_x(dt);
    platform_move_y(dt);
    if (s->y > TOP_H + 32) { platform_hurt(); return false; }

    for (int i = 0; i < s->coin_count; ++i) {
        LevelCoin *coin = &s->coins[i];
        if (coin->alive && overlaps(s->x, s->y, HERO_W, HERO_H, coin->x - 5, coin->y - 5, 10, 10)) {
            coin->alive = false;
            ++s->collected;
            s->score = add_score(s->score, 25);
        }
    }
    for (int i = 0; i < s->enemy_count; ++i) {
        LevelEnemy *enemy = &s->enemies[i];
        if (!enemy->alive) continue;
        float nx = enemy->x + enemy->dir * enemy->speed * dt;
        int front = tile_coord(nx + (enemy->dir > 0 ? 14 : 0));
        if (nx < enemy->left || nx > enemy->right || !platform_solid(front, 12))
            enemy->dir = -enemy->dir;
        else enemy->x = nx;
        if (!overlaps(s->x, s->y, HERO_W, HERO_H, enemy->x, enemy->y, 14, 14)) continue;
        if (s->vy > 0 && previous_bottom <= enemy->y + 5) {
            enemy->alive = false;
            s->vy = -205;
            s->grounded = false;
            s->score = add_score(s->score, 100);
        } else if (s->invulnerable <= 0) {
            platform_hurt();
            return false;
        }
    }
    if (!s->checkpoint && s->x >= CHECKPOINT_X && s->grounded) s->checkpoint = true;
    if (s->x + HERO_W >= FINISH_X && s->y + HERO_H > 116) {
        s->won = true;
        s->score = add_score(s->score, 500 + s->lives * 200);
        return false;
    }
    return true;
}

static void platform_update(GameInput input) {
    PlatformState *s = &puzzle.platform;
    if (s->over || s->won) return;
    u32 keys = input.held | input.down;
    float direction = !!(keys & KEY_DRIGHT) - !!(keys & KEY_DLEFT);
    if (!(keys & (KEY_DLEFT | KEY_DRIGHT))) {
        if (input.circleX > 25) direction = minimum((input.circleX - 25) / 100.0f, 1);
        else if (input.circleX < -25) direction = maximum((input.circleX + 25) / 100.0f, -1);
    }
    if (input.down & KEY_A) s->jump_buffer = 0.12f;
    /* At most six small steps for dt <= .05, so walls and enemies cannot tunnel. */
    int steps = input.dt > 0 ? (int)(input.dt * 120) + 1 : 1;
    float step = input.dt / steps;
    for (int i = 0; i < steps; ++i)
        if (!platform_step(step, direction, (keys & KEY_A) != 0)) break;
    platform_camera();
}

static void world_rect(float world_x, float y, float w, float h, u32 color) {
    float x = world_x - puzzle.platform.camera;
    float left = maximum(0, x), right = minimum(TOP_W, x + w);
    if (right > left && y < TOP_H && y + h > 28)
        ui_rect(left, maximum(y, 28), right - left, minimum(y + h, TOP_H) - maximum(y, 28), color);
}

static void platform_draw_top(void) {
    const PlatformState *s = &puzzle.platform;
    ui_rect(0, 0, TOP_W, TOP_H, P_INK);
    /* Fixed number of parallax silhouettes, never the entire offscreen level. */
    int horizon = (int)(s->camera * 0.22f) % 96;
    for (int i = 0; i < 6; ++i) {
        float x = i * 96 - horizon;
        ui_triangle(x - 22, 191, x + 42, 74 + (i % 2) * 19, x + 111, 191, P_DIM);
        ui_rect(x + 25, 153, 20, 39, C2D_Color32(22, 59, 40, 255));
    }
    int first = clampi(tile_coord(s->camera), 0, LEVEL_W - 1);
    int last = clampi(first + TOP_W / TILE + 1, 0, LEVEL_W - 1);
    for (int y = 0; y < LEVEL_H; ++y)
        for (int x = first; x <= last; ++x) {
            int tile = s->tiles[y][x];
            if (!tile) continue;
            world_rect(x * TILE, y * TILE, TILE, TILE, tile == 2 ? COL_GREEN_DK : P_DIM);
            if (!platform_solid(x, y - 1)) world_rect(x * TILE, y * TILE, TILE, 3, COL_GREEN);
            else if ((x + y) % 3 == 0) world_rect(x * TILE + 5, y * TILE + 8, 4, 2, COL_GREEN_DK);
        }
    for (int i = 0; i < s->coin_count; ++i) {
        const LevelCoin *coin = &s->coins[i];
        float x = coin->x - s->camera;
        if (!coin->alive || x < -6 || x > TOP_W + 6) continue;
        ui_circle(x, coin->y, 4, P_GOLD);
        ui_rect(x - 1, coin->y - 2, 2, 4, P_INK);
    }
    if (CHECKPOINT_X - s->camera > -20 && CHECKPOINT_X - s->camera < TOP_W + 20) {
        world_rect(CHECKPOINT_X, 158, 2, 34, COL_SUBTEXT);
        world_rect(CHECKPOINT_X + 2, 158, 15, 10, s->checkpoint ? P_MINT : COL_BAR_BG);
    }
    float flag = FINISH_X - s->camera;
    if (flag > -30 && flag < TOP_W + 30) {
        world_rect(FINISH_X, 108, 3, 84, P_MINT);
        ui_triangle(flag + 3, 110, flag + 29, 119, flag + 3, 130, COL_GREEN);
        world_rect(FINISH_X - 5, 188, 13, 4, COL_GREEN);
    }
    for (int i = 0; i < s->enemy_count; ++i) {
        const LevelEnemy *enemy = &s->enemies[i];
        if (!enemy->alive || enemy->x + 14 < s->camera || enemy->x > s->camera + TOP_W) continue;
        world_rect(enemy->x, enemy->y + 3, 14, 11, P_RED);
        world_rect(enemy->x + 3, enemy->y, 8, 3, P_RED);
        world_rect(enemy->x + (enemy->dir > 0 ? 8 : 2), enemy->y + 5, 4, 3, P_INK);
        world_rect(enemy->x + 2, enemy->y + 12, 3, 2, P_INK);
        world_rect(enemy->x + 10, enemy->y + 12, 3, 2, P_INK);
    }
    if (!s->over && (s->invulnerable <= 0 || (int)(animation_time * 12) % 2 == 0)) {
        world_rect(s->x + 2, s->y, 8, 3, COL_GREEN);
        world_rect(s->x, s->y + 3, HERO_W, HERO_H - 3, P_MINT);
        world_rect(s->x + (s->facing > 0 ? 8 : 2), s->y + 6, 2, 3, P_INK);
        world_rect(s->x + 1, s->y + 15, 4, 3, COL_GREEN_DK);
        world_rect(s->x + 8, s->y + 15, 4, 3, COL_GREEN_DK);
    }
    ui_rect(0, 0, TOP_W, 28, P_INK);
    ui_text(10, 6, 0.44f, COL_TEXT, "RUTA DEL BROTE");
    ui_text(175, 7, 0.38f, P_MINT, "VIDAS %d", s->lives);
    ui_text(258, 7, 0.38f, P_GOLD, "%d pts  $%d", s->score, s->collected);
    if (s->over) result_card("SIN VIDAS", "Un nuevo camino te espera.", false);
    if (s->won) result_card("META ALCANZADA!", "El brote llego a su nuevo hogar.", true);
}

static void platform_draw_bottom(void) {
    const PlatformState *s = &puzzle.platform;
    ui_rect(0, 0, BOT_W, BOT_H, COL_BG);
    ui_text(17, 12, 0.61f, COL_TEXT, "UN PEQUENO VIAJE");
    ui_text(18, 41, 0.4f, COL_SUBTEXT, "Busca la bandera al final del camino.");
    ui_rect(14, 66, 292, 87, P_DIM);
    ui_text(25, 74, 0.44f, COL_TEXT, "Dpad o Circle Pad: caminar");
    ui_text(25, 97, 0.44f, P_MINT, "A: saltar; manten A para subir mas");
    ui_text(25, 122, 0.38f, COL_SUBTEXT, "Pisa rivales. Junta monedas. Evita huecos.");
    ui_text(18, 163, 0.38f, s->checkpoint ? P_MINT : COL_SUBTEXT,
            "%s", tr(s->checkpoint ? "Punto de regreso activado." : "La banderita intermedia guarda tu avance."));
    ui_rect(18, 190, 284, 5, P_DIM);
    float progress = minimum(maximum(s->x / FINISH_X, 0), 1);
    ui_rect(18, 190, progress * 284, 5, COL_GREEN);
    ui_rect(18 + 284.0f * CHECKPOINT_X / FINISH_X, 187, 2, 11, P_MINT);
    ui_text(18, 201, 0.32f, COL_SUBTEXT, "Monedas %d/%d  |  Avance %d%%", s->collected, s->coin_count, (int)(progress * 100));
    footer();
}

/* ----------------------------- Public API ------------------------------ */
void puzzle_start(GameKind kind) {
    active_kind = (kind == GAME_STACK || kind == GAME_PLATFORM) ? kind : GAME_BLOCKS;
    random_state ^= (u32)osGetTime();
    if (!random_state) random_state = 0x8a35d29bu;
    memset(&puzzle, 0, sizeof(puzzle));
    animation_time = 0;
    switch (active_kind) {
        case GAME_STACK:
            puzzle.stack.bag_pos = 7;
            puzzle.stack.level = 1;
            puzzle.stack.next = stack_take_bag();
            stack_spawn();
            break;
        case GAME_PLATFORM: platform_build(); break;
        default: blocks_refill(); break;
    }
}

void puzzle_update(GameInput input) {
    /* START/B belong to the caller, including while a result is displayed. */
    if (input.down & KEY_X) { puzzle_start(active_kind); return; }
    if (!(input.dt > 0)) input.dt = 0; /* Also handles a non-finite NaN. */
    if (input.dt > 0.05f) input.dt = 0.05f;
    animation_time += input.dt;
    if (animation_time >= 60) animation_time -= 60;
    switch (active_kind) {
        case GAME_STACK: stack_update(input); break;
        case GAME_PLATFORM: platform_update(input); break;
        default: blocks_update(input); break;
    }
}

void puzzle_touch(int x, int y) {
    if (active_kind != GAME_BLOCKS || puzzle.blocks.over) return;
    if (x >= 186 && x < 308 && y >= 32 && y < 190) {
        int slot = (y - 32) / 54;
        if (slot < 3 && (y - 32) % 54 < 50 && puzzle.blocks.tray[slot] >= 0)
            puzzle.blocks.selected = slot;
    } else if (x >= BLOCK_X && x < BLOCK_X + BLOCK_N * BLOCK_CELL &&
               y >= BLOCK_Y && y < BLOCK_Y + BLOCK_N * BLOCK_CELL) {
        puzzle.blocks.cx = (x - BLOCK_X) / BLOCK_CELL;
        puzzle.blocks.cy = (y - BLOCK_Y) / BLOCK_CELL;
        blocks_place();
    }
}

void puzzle_draw_top(void) {
    switch (active_kind) {
        case GAME_STACK: stack_draw_top(); break;
        case GAME_PLATFORM: platform_draw_top(); break;
        default: blocks_draw_top(); break;
    }
}

void puzzle_draw_bottom(void) {
    switch (active_kind) {
        case GAME_STACK: stack_draw_bottom(); break;
        case GAME_PLATFORM: platform_draw_bottom(); break;
        default: blocks_draw_bottom(); break;
    }
}
