#ifndef VIBRA_AVI_H
#define VIBRA_AVI_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Classic single-RIFF AVI only. Indexes are rebuilt from bounded movi chunks,
 * never trusted from idx1/OpenDML. All audio positions/counts are PCM frames. */
typedef struct AviFile AviFile;
typedef struct {
    uint32_t width, height, rate, scale, frameCount, maxFrameBytes;
    uint32_t audioRate, audioChannels, audioFrames;
} AviInfo;

AviFile *avi_open(const char *path);
void avi_close(AviFile *avi);
const AviInfo *avi_info(const AviFile *avi);
bool avi_read_frame(AviFile *avi, uint32_t frame, void *dst, size_t capacity,
                    size_t *bytes);
bool avi_seek_audio(AviFile *avi, uint32_t frame);
/* dst holds capacity * 2 signed samples; mono is expanded to stereo. */
bool avi_read_audio(AviFile *avi, int16_t *dst, uint32_t capacity,
                    uint32_t *frames);

#endif
