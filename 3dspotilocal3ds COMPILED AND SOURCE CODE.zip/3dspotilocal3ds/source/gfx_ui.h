#ifndef VIBRA_UI_H
#define VIBRA_UI_H

#include "common.h"

bool ui_init(void);
void ui_exit(void);

/* Call once per frame before drawing. */
void ui_frame_begin(void);
void ui_frame_end(void);

/* Select which screen subsequent draw calls target. */
void ui_scene_top(void);
void ui_scene_bottom(void);
void ui_clear(u32 color);

void ui_rect(float x, float y, float w, float h, u32 color);
void ui_rounded(float x, float y, float w, float h, float r, u32 color);
void ui_circle(float cx, float cy, float r, u32 color);
void ui_triangle(float x0, float y0, float x1, float y1, float x2, float y2, u32 color);
void ui_image(C2D_Image img, float x, float y, float w, float h);
void ui_image_tint(C2D_Image img, float x, float y, float w, float h, u32 color);

/* Text. y is the top of the line; scale ~0.5 is body text. */
void ui_text(float x, float y, float scale, u32 color, const char *fmt, ...);
/* The *_raw variants draw text exactly as given (user data such as titles and lyrics); the others translate it. */
void ui_text_center_raw(float cx, float y, float scale, u32 color, const char *str);
void ui_text_right_raw(float rightX, float y, float scale, u32 color, const char *str);
void ui_text_center(float cx, float y, float scale, u32 color, const char *str);
void ui_text_right(float rightX, float y, float scale, u32 color, const char *str);
float ui_text_width(const char *str, float scale);
void ui_text_clipped(float x, float y, float scale, u32 color, float maxWidth, const char *str);

/* Vector icons used by the transport bar. */
void ui_icon_play(float cx, float cy, float s, u32 color);
void ui_icon_pause(float cx, float cy, float s, u32 color);
void ui_icon_next(float cx, float cy, float s, u32 color);
void ui_icon_prev(float cx, float cy, float s, u32 color);

#endif