#include "i18n.h"
#include "i18n_data.h"

static Lang current = LANG_ES;

void i18n_set(Lang lang) { current = (lang >= 0 && lang < LANG_COUNT) ? lang : LANG_ES; }
Lang i18n_get(void) { return current; }

const char *i18n_lang_name(Lang lang) {
    static const char *names[LANG_COUNT] = {
        "Espa\xC3\xB1ol", "English (US)", "English (UK)", "English (AU)", "Portugu\xC3\xAAs (BR)",
        "Deutsch", "\xD0\xA0\xD1\x83\xD1\x81\xD1\x81\xD0\xBA\xD0\xB8\xD0\xB9", "Fran\xC3\xA7""ais", "Italiano"
    };
    return (lang >= 0 && lang < LANG_COUNT) ? names[lang] : names[LANG_ES];
}

static int find_key(const char *s) {
    int lo = 0, hi = I18N_COUNT - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int c = strcmp(s, I18N_KEYS[mid]);
        if (c == 0) return mid;
        if (c < 0) hi = mid - 1; else lo = mid + 1;
    }
    return -1;
}

const char *tr(const char *s) {
    if (!s || !s[0]) return s;
    const char *const *table;
    switch (current) {
        case LANG_ES:    table = I18N_ES; break;
        case LANG_EN:    table = I18N_EN; break;
        case LANG_EN_GB: table = I18N_EN_GB; break;
        case LANG_EN_AU: table = I18N_EN_AU; break;
        case LANG_PT:    table = I18N_PT; break;
        case LANG_DE:    table = I18N_DE; break;
        case LANG_RU:    table = I18N_RU; break;
        case LANG_FR:    table = I18N_FR; break;
        default:         table = I18N_IT; break;
    }
    int i = find_key(s);
    if (i < 0) return s;
    const char *r = table[i];
    if (!r && (current == LANG_EN_GB || current == LANG_EN_AU)) r = I18N_EN[i];
    return r ? r : s;
}
