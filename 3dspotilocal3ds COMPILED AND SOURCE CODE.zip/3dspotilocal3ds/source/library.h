#ifndef VIBRA_LIBRARY_H
#define VIBRA_LIBRARY_H

#include "common.h"

/* Create sdmc:/3dSpotiLocal/{Music,Videos} if they do not exist. */
void library_ensure_dirs(void);

/* Cover file shipped with the album folder (cover.jpg, folder.png, ...). Empty if none. */
void library_default_cover(const char *folder, char *out, size_t n);

/* Scan the SD card and fill lib (zero it first). */
void library_scan(Library *lib);

#endif