#ifndef SPOTILOCAL_GAMES_H
#define SPOTILOCAL_GAMES_H

#include "common.h"

typedef enum {
    GAME_RHYTHM, GAME_DASH, GAME_BLOCKS, GAME_STACK,
    GAME_PLATFORM, GAME_VOXEL, GAME_MAZE,
    GAME_SNAKE, GAME_2048, GAME_BREAKOUT, GAME_FLAPPY, GAME_MINES, GAME_INVADERS,
    GAME_PONG, GAME_WHACK, GAME_MEMORY, GAME_SIMON, GAME_TICTAC, GAME_CONNECT4, GAME_ASTEROIDS,
    GAME_DINO, GAME_LIGHTS, GAME_SLIDE, GAME_COUNT
} GameKind;

typedef struct {
    u32 down, held;
    int circleX, circleY;
    float dt;
    int touchX, touchY;      /* stylus position while KEY_TOUCH is held */
} GameInput;

const char *game_title(GameKind kind);
const char *game_description(GameKind kind);
bool game_needs_song(GameKind kind);
bool game_start(GameKind kind, const char *songPath);
void game_stop(void);
void game_update(GameInput input);
void game_touch(int x, int y);
void game_draw_top(void);
void game_draw_bottom(void);

void puzzle_start(GameKind kind);
void puzzle_update(GameInput input);
void puzzle_touch(int x, int y);
void puzzle_draw_top(void);
void puzzle_draw_bottom(void);

void world_start(GameKind kind);
void world_update(GameInput input);
void world_touch(int x, int y);
void world_draw_top(void);
void world_draw_bottom(void);

void arcade_start(GameKind kind);
void arcade_update(GameInput input);
void arcade_touch(int x, int y);
void arcade_draw_top(void);
void arcade_draw_bottom(void);

void more_start(GameKind kind);
void more_update(GameInput input);
void more_touch(int x, int y);
void more_draw_top(void);
void more_draw_bottom(void);

#endif
