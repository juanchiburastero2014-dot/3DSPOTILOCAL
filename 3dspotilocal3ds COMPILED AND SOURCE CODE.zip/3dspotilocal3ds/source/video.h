#ifndef VIBRA_VIDEO_H
#define VIBRA_VIDEO_H

#include "common.h"

/* Plays pre-converted .v3v (RGB565 + PCM) and Motion JPEG .avi (PCM audio).
 * Real-time H.264 decode is not feasible on the 3DS ARM11, so videos
 * must be converted with tools/convert_video.py first. */
typedef struct VideoPlayer VideoPlayer;

VideoPlayer *video_open(const char *path);
void         video_close(VideoPlayer *v);
void         video_play(VideoPlayer *v);
void         video_pause(VideoPlayer *v, bool pause);
bool         video_is_paused(VideoPlayer *v);
void         video_update(VideoPlayer *v);   /* call once per frame */
bool         video_finished(VideoPlayer *v);
C2D_Image    video_image(VideoPlayer *v);
u64          video_position_ms(VideoPlayer *v);
u64          video_duration_ms(VideoPlayer *v);
bool         video_seek(VideoPlayer *v, u64 ms);

/* Orientation of the picture: 0 normal, 1 flipped vertically, 2 mirrored, 3 rotated 180 degrees.
 * Applied while the frame is written to the texture, so it costs nothing extra. */
void         video_set_orientation(VideoPlayer *v, int mode);
int          video_get_orientation(VideoPlayer *v);

/* A calibration picture (asymmetric "F" with coloured corners) that goes through the same texture
 * path as a real video, to check the orientation on the console. */
VideoPlayer *video_open_test(void);

#endif