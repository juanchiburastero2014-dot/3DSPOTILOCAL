#ifndef VIBRA_PLAYER_H
#define VIBRA_PLAYER_H

#include "common.h"
#include "audio.h"

typedef struct {
    Library    *lib;
    int         album;
    int         track;
    AudioStream *stream;
    bool        active;
    bool        shuffle;
    RepeatMode  repeat;
} Player;

void   player_init(Player *p, Library *lib);
void   player_exit(Player *p);
bool   player_play_track(Player *p, int album, int track);
void   player_stop(Player *p);
void   player_toggle_pause(Player *p);
void   player_next(Player *p);
void   player_prev(Player *p);
void   player_update(Player *p);
bool   player_seek_ms(Player *p, u64 ms);
u64    player_position_ms(Player *p);
u64    player_duration_ms(Player *p);
Track *player_current(Player *p);
Album *player_current_album(Player *p);

#endif