#include "gfx_ui.h"
#include "i18n.h"
#include <stdarg.h>

#define Z 0.5f

static C3D_RenderTarget *topTarget = NULL;
static C3D_RenderTarget *botTarget = NULL;
static C3D_RenderTarget *cur = NULL;
static C2D_TextBuf frameBuf = NULL;
static C2D_TextBuf measureBuf = NULL;

bool ui_init(void) {
    if (!C3D_Init(C3D_DEFAULT_CMDBUF_SIZE)) return false;
    if (!C2D_Init(C2D_DEFAULT_MAX_OBJECTS)) { C3D_Fini(); return false; }
    C2D_Prepare();

    u32 transfer = GX_TRANSFER_FLIP_VERT(0) | GX_TRANSFER_OUT_TILED(0) |
                   GX_TRANSFER_RAW_COPY(0) |
                   GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8) |
                   GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB8);

    topTarget = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
    if (!topTarget) { ui_exit(); return false; }
    C3D_RenderTargetSetOutput(topTarget, GFX_TOP, GFX_LEFT, transfer);

    botTarget = C3D_RenderTargetCreate(240, 320, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
    if (!botTarget) { ui_exit(); return false; }
    C3D_RenderTargetSetOutput(botTarget, GFX_BOTTOM, GFX_LEFT, transfer);

    frameBuf = C2D_TextBufNew(16384);
    measureBuf = C2D_TextBufNew(4096);
    if (!frameBuf || !measureBuf) { ui_exit(); return false; }
    return true;
}

void ui_exit(void) {
    if (frameBuf) C2D_TextBufDelete(frameBuf);
    if (measureBuf) C2D_TextBufDelete(measureBuf);
    C2D_Fini();
    C3D_Fini();
}

void ui_frame_begin(void) {
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TextBufClear(frameBuf);
}

void ui_frame_end(void) {
    C3D_FrameEnd(0);
}

void ui_scene_top(void) {
    cur = topTarget;
    C2D_TargetClear(topTarget, COL_BG);
    C2D_SceneBegin(topTarget);
}

void ui_scene_bottom(void) {
    cur = botTarget;
    C2D_TargetClear(botTarget, COL_BG);
    C2D_SceneBegin(botTarget);
}

void ui_clear(u32 color) {
    if (cur) C2D_TargetClear(cur, color);
}

void ui_rect(float x, float y, float w, float h, u32 color) {
    if (w <= 0 || h <= 0) return;
    C2D_DrawRectSolid(x, y, Z, w, h, color);
}

void ui_circle(float cx, float cy, float r, u32 color) {
    C2D_DrawCircleSolid(cx, cy, Z, r, color);
}

void ui_rounded(float x, float y, float w, float h, float r, u32 color) {
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    ui_rect(x + r, y, w - 2 * r, h, color);
    ui_rect(x, y + r, w, h - 2 * r, color);
    ui_circle(x + r, y + r, r, color);
    ui_circle(x + w - r, y + r, r, color);
    ui_circle(x + r, y + h - r, r, color);
    ui_circle(x + w - r, y + h - r, r, color);
}

void ui_triangle(float x0, float y0, float x1, float y1, float x2, float y2, u32 color) {
    C2D_DrawTriangle(x0, y0, color, x1, y1, color, x2, y2, color, Z);
}

void ui_image(C2D_Image img, float x, float y, float w, float h) {
    if (!img.tex) return;
    float sx = w / img.subtex->width;
    float sy = h / img.subtex->height;
    C2D_DrawImageAt(img, x, y, Z, NULL, sx, sy);
}

void ui_image_tint(C2D_Image img, float x, float y, float w, float h, u32 color) {
    if (!img.tex) return;
    C2D_ImageTint tint;
    C2D_PlainImageTint(&tint, color, 1.0f);
    float sx = w / img.subtex->width;
    float sy = h / img.subtex->height;
    C2D_DrawImageAt(img, x, y, Z, &tint, sx, sy);
}

static void draw_text_str(float x, float y, float scale, u32 color, const char *str) {
    C2D_Text t;
    C2D_TextParse(&t, frameBuf, str);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, Z, scale, scale, color);
}

void ui_text(float x, float y, float scale, u32 color, const char *fmt, ...) {
    char buf[512];
    const char *f = tr(fmt);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    draw_text_str(x, y, scale, color, buf);
}

float ui_text_width(const char *str, float scale) {
    C2D_Text t;
    C2D_TextBufClear(measureBuf);
    C2D_TextParse(&t, measureBuf, str);
    float w = 0, h = 0;
    C2D_TextGetDimensions(&t, scale, scale, &w, &h);
    return w;
}

void ui_text_center_raw(float cx, float y, float scale, u32 color, const char *str) {
    float w = ui_text_width(str, scale);
    draw_text_str(cx - w / 2, y, scale, color, str);
}

void ui_text_center(float cx, float y, float scale, u32 color, const char *str) {
    ui_text_center_raw(cx, y, scale, color, tr(str));
}

void ui_text_right_raw(float rightX, float y, float scale, u32 color, const char *str) {
    float w = ui_text_width(str, scale);
    draw_text_str(rightX - w, y, scale, color, str);
}

void ui_text_right(float rightX, float y, float scale, u32 color, const char *str) {
    ui_text_right_raw(rightX, y, scale, color, tr(str));
}

void ui_text_clipped(float x, float y, float scale, u32 color, float maxWidth, const char *str) {
    char buf[MAX_NAME];
    snprintf(buf, sizeof(buf), "%s", str);   /* clipped text is mostly user data (titles): never translated */
    if (ui_text_width(buf, scale) <= maxWidth) {
        draw_text_str(x, y, scale, color, buf);
        return;
    }
    size_t len = strlen(buf);
    while (len > 1) {
        len--;
        if (((unsigned char)buf[len] & 0xC0) == 0x80) continue;   /* never cut a UTF-8 character in half */
        buf[len] = '\0';
        char tmp[MAX_NAME + 4];
        snprintf(tmp, sizeof(tmp), "%s...", buf);
        if (ui_text_width(tmp, scale) <= maxWidth) {
            draw_text_str(x, y, scale, color, tmp);
            return;
        }
    }
    draw_text_str(x, y, scale, color, "...");
}

void ui_icon_play(float cx, float cy, float s, u32 color) {
    ui_triangle(cx - s * 0.5f, cy - s, cx - s * 0.5f, cy + s, cx + s * 0.8f, cy, color);
}

void ui_icon_pause(float cx, float cy, float s, u32 color) {
    ui_rect(cx - s * 0.7f, cy - s, s * 0.5f, s * 2, color);
    ui_rect(cx + s * 0.2f, cy - s, s * 0.5f, s * 2, color);
}

void ui_icon_next(float cx, float cy, float s, u32 color) {
    ui_triangle(cx - s * 0.6f, cy - s, cx - s * 0.6f, cy + s, cx + s * 0.4f, cy, color);
    ui_rect(cx + s * 0.4f, cy - s, s * 0.35f, s * 2, color);
}

void ui_icon_prev(float cx, float cy, float s, u32 color) {
    ui_rect(cx - s * 0.75f, cy - s, s * 0.35f, s * 2, color);
    ui_triangle(cx + s * 0.6f, cy - s, cx + s * 0.6f, cy + s, cx - s * 0.4f, cy, color);
}