#include "image.h"

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#include "stb_image.h"

#define TEX_SIZE   256
#define CACHE_MAX  16

typedef struct {
    char      path[MAX_PATH];
    C2D_Image img;
    bool      used;
    u32       tick;
} CacheEntry;

static CacheEntry cache[CACHE_MAX];
static u32 tickCounter = 0;

static void entry_free(CacheEntry *e) {
    if (e->img.tex) {
        C3D_TexDelete(e->img.tex);
        free(e->img.tex);
    }
    if (e->img.subtex) free((void *)e->img.subtex);
    e->img.tex = NULL;
    e->img.subtex = NULL;
    e->used = false;
    e->path[0] = '\0';
}

static C2D_Image load_scaled(const char *path) {
    C2D_Image none = { NULL, NULL };
    int w = 0, h = 0, comp = 0;
    if (!stbi_info(path, &w, &h, &comp) || w <= 0 || h <= 0 || w > 2048 || h > 2048)
        return none;
    unsigned char *src = stbi_load(path, &w, &h, &comp, 4);
    if (!src) return none;

    unsigned char *dst = (unsigned char *)malloc(TEX_SIZE * TEX_SIZE * 4);
    if (!dst) { stbi_image_free(src); return none; }

    // PICA200 textures use bottom-up Morton tiles and ABGR bytes.
    for (int y = 0; y < TEX_SIZE; y++) {
        int sy = (int)((u64)y * h / TEX_SIZE);
        for (int x = 0; x < TEX_SIZE; x++) {
            int sx = (int)((u64)x * w / TEX_SIZE);
            const unsigned char *pixel = src + (sy * w + sx) * 4;
            unsigned char *dest = dst + texture_index(x, TEX_SIZE - 1 - y, TEX_SIZE) * 4;
            dest[0] = pixel[3]; dest[1] = pixel[2];
            dest[2] = pixel[1]; dest[3] = pixel[0];
        }
    }
    stbi_image_free(src);

    C3D_Tex *tex = (C3D_Tex *)malloc(sizeof(C3D_Tex));
    if (!tex || !C3D_TexInit(tex, TEX_SIZE, TEX_SIZE, GPU_RGBA8)) {
        free(tex); free(dst); return none;
    }
    C3D_TexUpload(tex, dst);
    C3D_TexSetFilter(tex, GPU_LINEAR, GPU_LINEAR);
    C3D_TexSetWrap(tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    free(dst);

    Tex3DS_SubTexture *sub = (Tex3DS_SubTexture *)malloc(sizeof(Tex3DS_SubTexture));
    if (!sub) { C3D_TexDelete(tex); free(tex); return none; }
    sub->width  = TEX_SIZE;
    sub->height = TEX_SIZE;
    sub->left   = 0.0f;
    sub->top    = 1.0f;
    sub->right  = 1.0f;
    sub->bottom = 0.0f;

    C2D_Image img = { tex, sub };
    return img;
}

C2D_Image image_get(const char *path) {
    C2D_Image none = { NULL, NULL };
    if (!path || !path[0]) return none;
    tickCounter++;

    for (int i = 0; i < CACHE_MAX; i++) {
        if (cache[i].used && strcmp(cache[i].path, path) == 0) {
            cache[i].tick = tickCounter;
            return cache[i].img;
        }
    }

    int slot = -1;
    for (int i = 0; i < CACHE_MAX; i++) {
        if (!cache[i].used) { slot = i; break; }
    }
    if (slot < 0) {
        u32 oldest = 0xFFFFFFFF;
        for (int i = 0; i < CACHE_MAX; i++) {
            if (cache[i].tick < oldest) { oldest = cache[i].tick; slot = i; }
        }
        entry_free(&cache[slot]);
    }

    C2D_Image img = load_scaled(path);
    if (!img.tex) return none;

    cache[slot].used = true;
    cache[slot].tick = tickCounter;
    snprintf(cache[slot].path, MAX_PATH, "%s", path);
    cache[slot].img = img;
    return img;
}

void image_clear_all(void) {
    for (int i = 0; i < CACHE_MAX; i++) {
        if (cache[i].used) entry_free(&cache[i]);
    }
}