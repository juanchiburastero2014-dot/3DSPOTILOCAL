#include "library.h"
#include "covers.h"
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <strings.h>

static bool is_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static bool has_ext(const char *name, const char *ext) {
    const char *dot = strrchr(name, '.');
    if (!dot) return false;
    dot++;
    for (size_t i = 0; dot[i] && ext[i]; i++) {
        if (tolower((unsigned char)dot[i]) != tolower((unsigned char)ext[i]))
            return false;
    }
    return strlen(dot) == strlen(ext);
}

static bool is_audio(const char *name) {
    return has_ext(name, "mp3") || has_ext(name, "wav") ||
           has_ext(name, "ogg") || has_ext(name, "oga") || has_ext(name, "flac");
}

static void mkdir_if_missing(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) mkdir(path, 0777);
}

void library_ensure_dirs(void) {
    mkdir_if_missing("sdmc:/3dSpotiLocal");
    mkdir_if_missing(MUSIC_DIR);
    mkdir_if_missing(VIDEO_DIR);
}

/* Extract a JSON string value for key from a small buffer. */
static void json_string(const char *buf, const char *key, char *out, size_t n) {
    out[0] = '\0';
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(buf, pat);
    if (!p) return;
    p += strlen(pat);
    while (*p && *p != ':') p++;
    if (*p != ':') return;
    p++;
    while (*p && isspace((unsigned char)*p)) p++;
    if (*p != '"') return;
    p++;
    size_t i = 0;
    while (*p && *p != '"' && i + 1 < n) {
        if (*p == '\\' && p[1]) p++;
        out[i++] = *p++;
    }
    out[i] = '\0';
}

void library_default_cover(const char *folder, char *out, size_t n) {
    static const char *names[] = {
        "cover.jpg", "cover.png", "cover.jpeg", "cover.bmp", "folder.jpg", "folder.png",
        "front.jpg", "front.png", "album.jpg", "album.png", "art.jpg", "art.png",
        "artwork.jpg", "artwork.png", NULL
    };
    char path[MAX_PATH];
    for (int i = 0; names[i]; i++) {
        path_join(path, sizeof(path), folder, names[i]);
        if (file_exists(path)) {
            snprintf(out, n, "%s", path);
            return;
        }
    }
    out[0] = '\0';
}

static void find_cover(const char *folder, char *out, size_t n) {
    library_default_cover(folder, out, n);
}

static int track_cmp(const void *a, const void *b) {
    const Track *ta = (const Track *)a;
    const Track *tb = (const Track *)b;
    return strcmp(ta->path, tb->path);
}

static int album_cmp(const void *a, const void *b) {
    const Album *aa = (const Album *)a;
    const Album *ab = (const Album *)b;
    return strcasecmp(aa->title, ab->title);
}

static void parse_folder_name(const char *folder, char *title, char *artist) {
    const char *base = path_basename(folder);
    const char *sep = strstr(base, " - ");
    if (sep) {
        size_t alen = (size_t)(sep - base);
        if (alen >= MAX_NAME) alen = MAX_NAME - 1;
        memcpy(artist, base, alen);
        artist[alen] = '\0';
        snprintf(title, MAX_NAME, "%s", sep + 3);
    } else {
        snprintf(title, MAX_NAME, "%s", base);
        snprintf(artist, MAX_NAME, "Unknown Artist");
    }
}

static void read_album_json(const char *folder, Album *al) {
    char path[MAX_PATH];
    path_join(path, sizeof(path), folder, "album.json");
    FILE *f = fopen(path, "rb");
    if (!f) return;
    char buf[2048];
    size_t got = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[got] = '\0';
    char tmp[MAX_NAME];
    json_string(buf, "title", tmp, sizeof(tmp));
    if (tmp[0]) snprintf(al->title, MAX_NAME, "%s", tmp);
    json_string(buf, "artist", tmp, sizeof(tmp));
    if (tmp[0]) snprintf(al->artist, MAX_NAME, "%s", tmp);
}

static void scan_album(const char *folder, Album *al) {
    memset(al, 0, sizeof(*al));
    snprintf(al->folder, MAX_PATH, "%s", folder);
    parse_folder_name(folder, al->title, al->artist);
    find_cover(folder, al->coverPath, MAX_PATH);
    read_album_json(folder, al);
    {   /* a cover picked inside the app wins over the files in the folder */
        char chosen[MAX_PATH];
        if (covers_album_chosen(al, chosen, sizeof(chosen))) snprintf(al->coverPath, MAX_PATH, "%s", chosen);
    }

    DIR *d = opendir(folder);
    if (!d) return;
    struct dirent *ent;
    char path[MAX_PATH];
    while ((ent = readdir(d)) != NULL && al->trackCount < MAX_TRACKS_PER_ALBUM) {
        if (ent->d_name[0] == '.') continue;
        if (!is_audio(ent->d_name)) continue;
        path_join(path, sizeof(path), folder, ent->d_name);
        Track *t = &al->tracks[al->trackCount++];
        snprintf(t->path, MAX_PATH, "%s", path);
        snprintf(t->title, MAX_NAME, "%.*s", MAX_NAME - 1, ent->d_name);
        strip_ext(t->title);
        t->trackNo = atoi(ent->d_name);
    }
    closedir(d);
    if (al->trackCount > 1)
        qsort(al->tracks, al->trackCount, sizeof(Track), track_cmp);
}

static int video_cmp(const void *a, const void *b) {
    const Video *va = (const Video *)a;
    const Video *vb = (const Video *)b;
    return strcasecmp(va->title, vb->title);
}

void library_scan(Library *lib) {
    memset(lib, 0, sizeof(*lib));

    DIR *d = opendir(MUSIC_DIR);
    if (d) {
        struct dirent *ent;
        char path[MAX_PATH];
        while ((ent = readdir(d)) != NULL && lib->albumCount < MAX_ALBUMS) {
            if (ent->d_name[0] == '.') continue;
            path_join(path, sizeof(path), MUSIC_DIR, ent->d_name);
            if (!is_dir(path)) continue;
            Album *album = &lib->albums[lib->albumCount];
            scan_album(path, album);
            if (album->trackCount > 0)
                lib->albumCount++;
        }
        closedir(d);
    }
    if (lib->albumCount > 1)
        qsort(lib->albums, lib->albumCount, sizeof(Album), album_cmp);

    d = opendir(VIDEO_DIR);
    if (d) {
        struct dirent *ent;
        char path[MAX_PATH];
        while ((ent = readdir(d)) != NULL && lib->videoCount < MAX_VIDEOS) {
            if (ent->d_name[0] == '.') continue;
            if (!has_ext(ent->d_name, "v3v") && !has_ext(ent->d_name, "avi")) continue;
            path_join(path, sizeof(path), VIDEO_DIR, ent->d_name);
            Video *v = &lib->videos[lib->videoCount++];
            snprintf(v->path, MAX_PATH, "%s", path);
            snprintf(v->title, MAX_NAME, "%.*s", MAX_NAME - 1, ent->d_name);
            strip_ext(v->title);
        }
        closedir(d);
    }
    if (lib->videoCount > 1)
        qsort(lib->videos, lib->videoCount, sizeof(Video), video_cmp);
}