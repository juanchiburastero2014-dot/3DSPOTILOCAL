#ifndef VIBRA_LYRICS_H
#define VIBRA_LYRICS_H

#include "common.h"

#define LYRIC_TEXT 100
#define LYRIC_MAX_LINES 900

typedef struct { char text[LYRIC_TEXT]; int ms; } LyricLine;   /* ms < 0: no timestamp */

/* Looks for <song>.txt or <song>.lrc next to the song, then in /3dSpotiLocal/Lyrics/.
 * Plain text works; lines starting with [mm:ss] or [mm:ss.xx] are used to sync the lyrics. */
bool lyrics_load(const char *trackPath);
void lyrics_free(void);
int  lyrics_count(void);
bool lyrics_timed(void);
const LyricLine *lyrics_line(int i);
/* Index of the line to highlight; manualOffset shifts it for unsynced lyrics. */
int  lyrics_current(u64 posMs, u64 durMs, int manualOffset);

#endif
