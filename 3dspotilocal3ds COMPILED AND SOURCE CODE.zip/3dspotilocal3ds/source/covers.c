#include "covers.h"
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <strings.h>

#define MAX_ENTRIES 256
#define MAX_IMAGES  300

typedef struct { char kind; char key[160]; char img[96]; } Entry;   /* kind: 'A' album, 'T' track */
static Entry entries[MAX_ENTRIES];
static int entryCount;
static char images[MAX_IMAGES][96];
static int imageCount;

static bool is_image_name(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot) return false;
    return !strcasecmp(dot, ".jpg") || !strcasecmp(dot, ".jpeg") || !strcasecmp(dot, ".png") || !strcasecmp(dot, ".bmp");
}

static void save(void) {
    FILE *f = fopen(COVERS_CFG, "wb");
    if (!f) return;
    for (int i = 0; i < entryCount; i++)
        fprintf(f, "%c|%s|%s\n", entries[i].kind, entries[i].key, entries[i].img);
    fclose(f);
}

void covers_init(void) {
    struct stat st;
    if (stat(COVERS_DIR, &st) != 0) mkdir(COVERS_DIR, 0777);
    entryCount = 0;
    FILE *f = fopen(COVERS_CFG, "rb");
    if (!f) return;
    char line[400];
    while (entryCount < MAX_ENTRIES && fgets(line, sizeof(line), f)) {
        size_t len = strlen(line);
        while (len && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = '\0';
        char *a = strchr(line, '|');
        char *b = a ? strrchr(line, '|') : NULL;
        if (!a || b == a || (line[0] != 'A' && line[0] != 'T')) continue;
        *a = '\0';
        *b = '\0';
        Entry *e = &entries[entryCount++];
        e->kind = line[0];
        snprintf(e->key, sizeof(e->key), "%s", a + 1);
        snprintf(e->img, sizeof(e->img), "%s", b + 1);
    }
    fclose(f);
}

static int img_cmp(const void *a, const void *b) { return strcasecmp((const char *)a, (const char *)b); }

void covers_refresh_list(void) {
    imageCount = 0;
    DIR *d = opendir(COVERS_DIR);
    if (!d) return;
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && imageCount < MAX_IMAGES) {
        if (ent->d_name[0] == '.' || !is_image_name(ent->d_name)) continue;
        snprintf(images[imageCount++], sizeof(images[0]), "%s", ent->d_name);
    }
    closedir(d);
    if (imageCount > 1) qsort(images, imageCount, sizeof(images[0]), img_cmp);
}

int covers_image_count(void) { return imageCount; }
const char *covers_image_name(int i) { return i >= 0 && i < imageCount ? images[i] : ""; }
void covers_image_path(int i, char *out, size_t n) {
    snprintf(out, n, "%s/%s", COVERS_DIR, covers_image_name(i));
}

static void album_key(const Album *al, char *out, size_t n) {
    snprintf(out, n, "%s", path_basename(al->folder));
}

static void track_key(const Album *al, const Track *t, char *out, size_t n) {
    char name[MAX_NAME];
    snprintf(name, sizeof(name), "%s", path_basename(t->path));
    snprintf(out, n, "%.60s/%.90s", path_basename(al->folder), name);
}

static Entry *find_entry(char kind, const char *key) {
    for (int i = 0; i < entryCount; i++)
        if (entries[i].kind == kind && !strcmp(entries[i].key, key)) return &entries[i];
    return NULL;
}

static void set_entry(char kind, const char *key, const char *imageName) {
    Entry *e = find_entry(kind, key);
    if (!imageName || !imageName[0]) {
        if (e) { *e = entries[--entryCount]; save(); }
        return;
    }
    if (!e) {
        if (entryCount >= MAX_ENTRIES) return;
        e = &entries[entryCount++];
        e->kind = kind;
        snprintf(e->key, sizeof(e->key), "%s", key);
    }
    snprintf(e->img, sizeof(e->img), "%s", imageName);
    save();
}

static bool entry_path(const Entry *e, char *out, size_t n) {
    snprintf(out, n, "%s/%s", COVERS_DIR, e->img);
    return file_exists(out);
}

bool covers_album_chosen(const Album *al, char *out, size_t n) {
    char key[160];
    album_key(al, key, sizeof(key));
    const Entry *e = find_entry('A', key);
    return e && entry_path(e, out, n);
}

void covers_album_set(const Album *al, const char *imageName) {
    char key[160];
    album_key(al, key, sizeof(key));
    set_entry('A', key, imageName);
}

bool covers_track_find(const Album *al, const Track *t, char *out, size_t n) {
    char key[160];
    track_key(al, t, key, sizeof(key));
    const Entry *e = find_entry('T', key);
    if (e && entry_path(e, out, n)) return true;

    static const char *exts[] = { ".jpg", ".jpeg", ".png", ".bmp", NULL };
    char base[MAX_PATH];
    snprintf(base, sizeof(base), "%s", t->path);
    char *dot = strrchr(base, '.');
    char *slash = strrchr(base, '/');
    if (!dot || (slash && dot < slash)) return false;
    for (int i = 0; exts[i]; i++) {
        snprintf(dot, sizeof(base) - (size_t)(dot - base), "%s", exts[i]);
        if (file_exists(base)) { snprintf(out, n, "%s", base); return true; }
    }
    return false;
}

void covers_track_set(const Album *al, const Track *t, const char *imageName) {
    char key[160];
    track_key(al, t, key, sizeof(key));
    set_entry('T', key, imageName);
}
