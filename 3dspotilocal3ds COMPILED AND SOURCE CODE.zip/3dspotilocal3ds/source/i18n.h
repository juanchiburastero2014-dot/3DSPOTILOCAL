#ifndef VIBRA_I18N_H
#define VIBRA_I18N_H

#include "common.h"

/* All texts in the code are written in Spanish and act as the lookup key.
 * tr() returns the text in the selected language (or the Spanish original if it has no translation).
 * The ui_text* drawing functions already call tr() on what they draw, so only text that is
 * formatted with snprintf() *before* drawing needs an explicit tr() around the format string. */
const char *tr(const char *spanish);

typedef enum {
    LANG_ES, LANG_EN, LANG_EN_GB, LANG_EN_AU, LANG_PT, LANG_DE, LANG_RU, LANG_FR, LANG_IT,
    LANG_COUNT
} Lang;

void        i18n_set(Lang lang);
Lang        i18n_get(void);
const char *i18n_lang_name(Lang lang);   /* shown in the language's own name */

#endif
