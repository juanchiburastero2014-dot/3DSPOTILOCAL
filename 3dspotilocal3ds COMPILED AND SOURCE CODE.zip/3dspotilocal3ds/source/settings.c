#include "settings.h"
#include "audio.h"
#include "i18n.h"

Settings g_settings;
u32 g_accent, g_accent_dk;
static bool dirty;

static const int boostPct[] = { 100, 125, 150, 200, 250, 300 };
#define BOOST_N ((int)(sizeof(boostPct) / sizeof(boostPct[0])))
static const char *accentNames[] = { "Verde", "Azul", "Rosa", "Naranja" };
static const char *diffNames[] = { "Facil", "Normal", "Dificil" };
static const char *repeatNames[] = { "No", "Todo", "Una cancion" };

/* First run: pick the language of the console (and the regional English variant). */
static int detect_language(void) {
    int lang = LANG_ES;
    if (R_FAILED(cfguInit())) return lang;
    u8 sys = 5, region = 1;
    if (R_SUCCEEDED(CFGU_GetSystemLanguage(&sys))) {
        switch (sys) {
            case 1: lang = LANG_EN; break;          /* English */
            case 2: lang = LANG_FR; break;
            case 3: lang = LANG_DE; break;
            case 4: lang = LANG_IT; break;
            case 5: lang = LANG_ES; break;
            case 9: lang = LANG_PT; break;
            case 10: lang = LANG_RU; break;
            default: lang = LANG_EN; break;         /* Japanese, Chinese, Korean, Dutch...: English */
        }
    }
    if (lang == LANG_EN && R_SUCCEEDED(CFGU_SecureInfoGetRegion(&region))) {
        if (region == 3) lang = LANG_EN_AU;         /* Australia */
        else if (region == 2) lang = LANG_EN_GB;    /* Europe */
    }
    cfguExit();
    return lang;
}

static void defaults(void) {
    memset(&g_settings, 0, sizeof(g_settings));
    g_settings.lyricsAuto = true;
    g_settings.difficulty = 1;
    g_settings.gameMusic = true;
    g_settings.lang = -1;                  /* -1: not chosen yet, detect it */
    g_settings.videoOrient = 1;            /* see tools: calibrate in Settings > Test video orientation */
}

void settings_reset(void) {
    int keep[MAX_GAME_SCORES], lang = g_settings.lang;
    memcpy(keep, g_settings.best, sizeof(keep));
    defaults();
    g_settings.lang = lang;
    memcpy(g_settings.best, keep, sizeof(keep));
    settings_apply();
    settings_save();
}

void settings_apply(void) {
    static const u8 rgb[4][3] = { {0x1D, 0xB9, 0x54}, {0x2E, 0x9B, 0xF0}, {0xF0, 0x5A, 0xA0}, {0xF2, 0x8C, 0x28} };
    int a = clampi(g_settings.accent, 0, 3);
    g_accent = C2D_Color32(rgb[a][0], rgb[a][1], rgb[a][2], 0xFF);
    g_accent_dk = C2D_Color32(rgb[a][0] * 8 / 10, rgb[a][1] * 8 / 10, rgb[a][2] * 8 / 10, 0xFF);
    audio_set_gain(boostPct[clampi(g_settings.boost, 0, BOOST_N - 1)] / 100.0f);
    i18n_set((Lang)clampi(g_settings.lang < 0 ? LANG_ES : g_settings.lang, 0, LANG_COUNT - 1));
}

void settings_load(void) {
    defaults();
    FILE *f = fopen(SETTINGS_PATH, "rb");
    if (f) {
        char line[96];
        while (fgets(line, sizeof(line), f)) {
            char *eq = strchr(line, '=');
            if (!eq) continue;
            *eq = '\0';
            int v = atoi(eq + 1);
            if (!strcmp(line, "lang")) g_settings.lang = clampi(v, 0, LANG_COUNT - 1);
            else if (!strcmp(line, "boost")) g_settings.boost = clampi(v, 0, BOOST_N - 1);
            else if (!strcmp(line, "lyrics")) g_settings.lyricsAuto = v != 0;
            else if (!strcmp(line, "difficulty")) g_settings.difficulty = clampi(v, 0, 2);
            else if (!strcmp(line, "gamemusic")) g_settings.gameMusic = v != 0;
            else if (!strcmp(line, "accent")) g_settings.accent = clampi(v, 0, 3);
            else if (!strcmp(line, "shuffle")) g_settings.startShuffle = v != 0;
            else if (!strcmp(line, "videorot")) g_settings.videoOrient = clampi(v, 0, 3);
            else if (!strcmp(line, "repeat")) g_settings.startRepeat = clampi(v, 0, 2);
            else if (!strncmp(line, "best", 4)) {
                int k = atoi(line + 4);
                if (k >= 0 && k < MAX_GAME_SCORES) g_settings.best[k] = v < 0 ? 0 : v;
            }
        }
        fclose(f);
    }
    if (g_settings.lang < 0) { g_settings.lang = detect_language(); settings_save(); }
    settings_apply();
}

void settings_save(void) {
    FILE *f = fopen(SETTINGS_PATH, "wb");
    if (!f) return;
    fprintf(f, "videorot=%d\nlang=%d\nboost=%d\nlyrics=%d\ndifficulty=%d\ngamemusic=%d\naccent=%d\nshuffle=%d\nrepeat=%d\n",
            g_settings.videoOrient, g_settings.lang, g_settings.boost, g_settings.lyricsAuto, g_settings.difficulty, g_settings.gameMusic,
            g_settings.accent, g_settings.startShuffle, g_settings.startRepeat);
    for (int i = 0; i < MAX_GAME_SCORES; i++)
        if (g_settings.best[i] > 0) fprintf(f, "best%d=%d\n", i, g_settings.best[i]);
    fclose(f);
    dirty = false;
}

enum { S_LANG, S_BOOST, S_LYRICS, S_DIFF, S_GAMEMUSIC, S_ACCENT, S_SHUFFLE, S_REPEAT, S_VIDEOROT, S_VIDEOTEST, S_RELOAD, S_RESET, S_COUNT };

int setting_count(void) { return S_COUNT; }

const char *setting_name(int i) {
    static const char *names[S_COUNT] = {
        "Idioma / Language", "Volume booster", "Letras automaticas", "Dificultad de juegos", "Musica en los juegos",
        "Color de acento", "Mezclar al iniciar", "Repetir al iniciar", "Orientacion del video",
        "Probar orientacion del video", "Recargar biblioteca",
        "Restaurar ajustes"
    };
    return i >= 0 && i < S_COUNT ? tr(names[i]) : "";
}

const char *setting_help(int i) {
    static const char *help[S_COUNT] = {
        "Idioma de los menus y los juegos. / Language of menus and games.",
        "Amplifica el audio por software (musica, juegos y video). Por encima de 200% puede distorsionar.",
        "Si la cancion tiene un .txt con su letra, se muestra sola en la pantalla de arriba.",
        "Cambia la velocidad y la tolerancia de los minijuegos, incluidos los ritmicos.",
        "Si esta en No, la musica se pausa al abrir un minijuego.",
        "Color principal de la interfaz.",
        "Empieza con el modo aleatorio activado.",
        "Modo de repeticion con el que arranca el reproductor.",
        "Corrige videos que se ven al reves o en espejo. Tambien se cambia con X mientras miras un video.",
        "Muestra una imagen de prueba (una F con esquinas de colores). Apreta X hasta que se vea bien: F legible y rojo arriba a la izquierda.",
        "Vuelve a leer /3dSpotiLocal (albumes, caratulas, letras) sin cerrar la app.",
        "Deja todos los ajustes como vienen de fabrica. No borra tus records."
    };
    return i >= 0 && i < S_COUNT ? tr(help[i]) : "";
}

void setting_value(int i, char *out, size_t n) {
    switch (i) {
        case S_LANG:      snprintf(out, n, "%s", i18n_lang_name((Lang)clampi(g_settings.lang, 0, LANG_COUNT - 1))); break;
        case S_BOOST:     snprintf(out, n, "%d%%", boostPct[clampi(g_settings.boost, 0, BOOST_N - 1)]); break;
        case S_LYRICS:    snprintf(out, n, "%s", tr(g_settings.lyricsAuto ? "Si" : "No")); break;
        case S_DIFF:      snprintf(out, n, "%s", tr(diffNames[clampi(g_settings.difficulty, 0, 2)])); break;
        case S_GAMEMUSIC: snprintf(out, n, "%s", tr(g_settings.gameMusic ? "Si" : "No")); break;
        case S_ACCENT:    snprintf(out, n, "%s", tr(accentNames[clampi(g_settings.accent, 0, 3)])); break;
        case S_SHUFFLE:   snprintf(out, n, "%s", tr(g_settings.startShuffle ? "Si" : "No")); break;
        case S_VIDEOROT: {
            static const char *modes[4] = { "Normal", "Volteado vertical", "Espejo horizontal", "Girado 180 grados" };
            snprintf(out, n, "%s", tr(modes[clampi(g_settings.videoOrient, 0, 3)]));
            break;
        }
        case S_REPEAT:    snprintf(out, n, "%s", tr(repeatNames[clampi(g_settings.startRepeat, 0, 2)])); break;
        default:          snprintf(out, n, "A"); break;
    }
}

SettingAction setting_action(int i) {
    return i == S_RELOAD ? ACT_RELOAD : (i == S_RESET ? ACT_RESET : (i == S_VIDEOTEST ? ACT_VIDEOTEST : ACT_NONE));
}

static int wrap(int v, int dir, int n) { return ((v + dir) % n + n) % n; }

void setting_change(int i, int dir) {
    switch (i) {
        case S_LANG:      g_settings.lang = wrap(g_settings.lang, dir, LANG_COUNT); break;
        case S_BOOST:     g_settings.boost = wrap(g_settings.boost, dir, BOOST_N); break;
        case S_LYRICS:    g_settings.lyricsAuto = !g_settings.lyricsAuto; break;
        case S_DIFF:      g_settings.difficulty = wrap(g_settings.difficulty, dir, 3); break;
        case S_GAMEMUSIC: g_settings.gameMusic = !g_settings.gameMusic; break;
        case S_ACCENT:    g_settings.accent = wrap(g_settings.accent, dir, 4); break;
        case S_SHUFFLE:   g_settings.startShuffle = !g_settings.startShuffle; break;
        case S_REPEAT:    g_settings.startRepeat = wrap(g_settings.startRepeat, dir, 3); break;
        case S_VIDEOROT:  g_settings.videoOrient = wrap(g_settings.videoOrient, dir, 4); break;
        default: return;
    }
    settings_apply();
    settings_save();
}

void settings_note_score(int kind, int score) {
    if (kind < 0 || kind >= MAX_GAME_SCORES || score <= g_settings.best[kind]) return;
    g_settings.best[kind] = score;
    dirty = true;
}

int settings_best(int kind) {
    return kind >= 0 && kind < MAX_GAME_SCORES ? g_settings.best[kind] : 0;
}

void settings_flush(void) {
    if (dirty) settings_save();
}
