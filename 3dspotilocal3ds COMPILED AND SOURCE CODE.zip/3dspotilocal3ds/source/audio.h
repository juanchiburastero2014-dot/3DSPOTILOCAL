#ifndef VIBRA_AUDIO_H
#define VIBRA_AUDIO_H

#include "common.h"

#define AUDIO_CHUNK_FRAMES 4096
#define AUDIO_NBUFFERS     4

typedef struct AudioStream AudioStream;

/* ---- Decoder (MP3 / WAV / OGG / FLAC) -> interleaved stereo s16 ---- */
AudioStream *audio_open(const char *path);
void         audio_close(AudioStream *s);
int          audio_sample_rate(const AudioStream *s);
u64          audio_total_frames(const AudioStream *s);
u64          audio_tell(const AudioStream *s);
bool         audio_seek(AudioStream *s, u64 frame);
/* Read up to maxFrames (<= AUDIO_CHUNK_FRAMES) stereo frames. Returns frames read. */
size_t       audio_read(AudioStream *s, s16 *stereoOut, size_t maxFrames);

/* ---- NDSP streaming output engine (channel 0) ---- */
bool audio_out_init(void);
void audio_out_exit(void);
bool audio_out_start(AudioStream *s);   /* does not take ownership of s */
void audio_out_stop(void);
void audio_out_pause(bool pause);
bool audio_out_is_paused(void);
void audio_out_update(void);            /* call once per frame */
bool audio_out_finished(void);          /* EOF reached and buffers drained */
u64  audio_out_position(void);          /* approximate current frame */
bool audio_out_seek(u64 frame);
void audio_out_set_volume(float vol);

/* Volume booster: software gain (1.0 = off) with a soft limiter. Applies to music, rhythm games and video audio. */
void audio_set_gain(float gain);
void audio_apply_gain(s16 *stereo, size_t frames);

#endif