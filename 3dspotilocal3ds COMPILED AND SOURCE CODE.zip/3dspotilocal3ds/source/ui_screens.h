#ifndef VIBRA_SCREENS_H
#define VIBRA_SCREENS_H

#include "app.h"

void screens_draw_top(App *app);
void screens_draw_bottom(App *app);
void screens_touch(App *app, int x, int y);   /* tap on bottom screen */
void screens_scroll(App *app, int dir);       /* -1 up, +1 down (swipe / wheel) */
void screens_key(App *app, u32 down);         /* button press */
void screens_back(App *app);

#endif