#include "app.h"
#include "gfx_ui.h"
#include "image.h"
#include "library.h"
#include "settings.h"
#include "covers.h"
#include "i18n.h"
#include "ui_screens.h"

void app_init(App *app, Library *lib) {
    memset(app, 0, sizeof(*app));
    app->lib = lib;
    player_init(&app->player, lib);
    app->screen = SCREEN_LIBRARY;
    app->videoIndex = -1;
    app->running = true;
    app->player.shuffle = g_settings.startShuffle;
    app->player.repeat = (RepeatMode)g_settings.startRepeat;
}

void app_exit(App *app) {
    game_stop();
    lyrics_free();
    settings_flush();
    app_close_video(app);
    player_exit(&app->player);
}

void app_open_video(App *app, int index) {
    app_close_video(app);
    player_stop(&app->player);
    app->video = video_open(app->lib->videos[index].path);
    if (app->video) {
        app->videoIndex = index;
        video_play(app->video);
        app->screen = SCREEN_VIDEO;
    } else {
        snprintf(app->error, sizeof(app->error), "%s", tr("No se pudo abrir el video (.avi MJPEG o .v3v)."));
    }
}

void app_open_video_test(App *app) {
    app_close_video(app);
    player_stop(&app->player);
    app->video = video_open_test();
    if (app->video) {
        app->videoTest = true;
        video_play(app->video);
        app->screen = SCREEN_VIDEO;
    } else {
        snprintf(app->error, sizeof(app->error), "%s", tr("No se pudo abrir el video (.avi MJPEG o .v3v)."));
    }
}

void app_close_video(App *app) {
    app->videoTest = false;
    if (app->video) {
        video_close(app->video);
        app->video = NULL;
    }
    app->videoIndex = -1;
}

static void show_startup_error(const char *message) {
    consoleInit(GFX_TOP, NULL);
    printf("3dSpotiLocal\n\n%s\n\nSTART: salir\n", message);
    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & (KEY_START | KEY_B)) break;
        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }
}

int main(void) {
    gfxInitDefault();
    if (!audio_out_init()) {
        show_startup_error("No se pudo iniciar el audio.\nComproba /3ds/dspfirm.cdc en tu SD\ny la memoria disponible.");
        gfxExit();
        return 1;
    }
    Library *lib = (Library *)calloc(1, sizeof(Library));
    if (!lib || !ui_init()) {
        show_startup_error("No hay memoria suficiente para iniciar.");
        free(lib);
        audio_out_exit();
        gfxExit();
        return 1;
    }
    srand((unsigned)osGetTime());
    settings_load();
    library_ensure_dirs();
    covers_init();
    library_scan(lib);

    App app;
    app_init(&app, lib);

    bool wasTouch = false, dragged = false;
    int startX = 0, startY = 0, lastY = 0, accum = 0;
    u64 lastMs = 0;

    while (app.running && aptMainLoop()) {
        ui_frame_begin();
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();

        screens_key(&app, down);

        touchPosition tp;
        hidTouchRead(&tp);
        bool touching = (held & KEY_TOUCH) != 0;
        if (app.screen == SCREEN_GAME) {
            /* Games want the press itself, not the release-tap used by the menus. */
            if (touching && !wasTouch) game_touch(tp.px, tp.py);
            dragged = false;
        } else if (touching && !wasTouch) {
            startX = tp.px; startY = tp.py; lastY = tp.py;
            accum = 0; dragged = false;
        } else if (touching && wasTouch) {
            accum += tp.py - lastY;
            lastY = tp.py;
            if (accum > 40)      { screens_scroll(&app, -1); accum = 0; dragged = true; }
            else if (accum < -40){ screens_scroll(&app, +1); accum = 0; dragged = true; }
            if (abs(tp.px - startX) > 20 || abs(tp.py - startY) > 20) dragged = true;
        } else if (!touching && wasTouch) {
            if (!dragged) screens_touch(&app, startX, startY);
        }
        wasTouch = touching;

        if (app.screen == SCREEN_GAME) {
            circlePosition cp;
            hidCircleRead(&cp);
            u64 now = osGetTime();
            float dt = lastMs ? (float)(now - lastMs) / 1000.0f : 1.0f / 60.0f;
            lastMs = now;
            GameInput gi = { down, held, cp.dx, cp.dy, dt, tp.px, tp.py };
            game_update(gi);
            player_update(&app.player);   /* background music keeps going in the quick games */
        } else {
            lastMs = 0;
            if (app.screen == SCREEN_VIDEO && app.video) video_update(app.video);
            else player_update(&app.player);
        }

        screens_draw_top(&app);
        screens_draw_bottom(&app);
        ui_frame_end();

        app.frames++;
    }

    ui_frame_begin();
    app_exit(&app);
    image_clear_all();
    ui_frame_end();
    free(lib);
    audio_out_exit();
    ui_exit();
    gfxExit();
    return 0;
}