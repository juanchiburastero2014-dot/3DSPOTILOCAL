/* Two self-contained, asset-free worlds. All storage and rendering work is bounded.
 * No scene/frame ownership and no disk I/O: the games wrapper owns pause/exit. */
#include "games.h"
#include "gfx_ui.h"
#include "i18n.h"
#include <math.h>

#define PI_F 3.14159265358979323846f
#define FOCAL 210.0f
#define VW 16
#define VH 8
#define VD 16
#define VRANGE 7.0f
#define VNEAR 0.08f
#define VREACH 4.5f
#define BODY_R 0.24f
#define BODY_H 1.70f
#define EYE_H 1.45f
/* Includes clipped triangles, not just source quads. Reserve the rest of the
 * ~1000-object frame for both minimaps, text glyphs and HUDs. Drop distant faces
 * first when a heavily edited world exhausts this explicit geometry budget. */
#define FACE_MAX 192
#define TRI_MAX 400
#define CLIP_MAX 12
#define MN 13
#define ROBOTS 6
#define RAYS 80
#define STRIP (400.0f / RAYS)

typedef struct { float x, y, z; } Vec3;
typedef struct {
    float x[CLIP_MAX], y[CLIP_MAX], depth;
    u32 color;
    int n;
} Face;
typedef struct { int x, y, z, px, py, pz; bool hit, adjacent; } Target;
typedef struct {
    unsigned char blocks[VW][VH][VD];
    float x, y, z, yaw, pitch, vy;
    bool grounded;
    int selected;
    Target target;
    const char *message;
    float messageTime;
} Voxel;
typedef struct {
    float x, z, attack, flash;
    int hp;
} Robot;
typedef struct {
    float x, z, yaw, shot, muzzle, hurt, hit;
    int health, remaining, result; /* 0 playing, 1 escaped, -1 defeated */
    Robot robots[ROBOTS];
} Maze;
typedef struct { float distance; int x, z, side, tile; } RayHit;

static bool active;
static GameKind current;
static Voxel voxel;
static Maze maze;
static Face faces[FACE_MAX];
static int faceOrder[FACE_MAX], faceCount, triangleCount;
static float wallDepth[RAYS];
static float viewSin, viewCos, pitchSin, pitchCos;

/* All rooms, the exit and robot spawn cells are connected. '2' is walkable. */
static const char mazeMap[MN][MN + 1] = {
    "1111111111111",
    "1000001000001",
    "1011101011101",
    "1010000000101",
    "1010111110101",
    "1000100010001",
    "1110101011101",
    "1000001000001",
    "1011101010101",
    "1000100010101",
    "1010111110101",
    "1000000000021",
    "1111111111111"
};
static const unsigned char blockRGB[7][3] = {
    {0, 0, 0}, {86, 184, 113}, {135, 149, 165}, {227, 116, 91},
    {236, 193, 81}, {96, 185, 223}, {61, 73, 91}
};
static const char *const blockNames[7] = {
    "Air", "Moss", "Slate", "Coral", "Amber", "Ice", "Base"
};
static const int normals[6][3] = {
    {-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}
};
static const unsigned char corners[6][4][3] = {
    {{0,0,0}, {0,0,1}, {0,1,1}, {0,1,0}},
    {{1,0,1}, {1,0,0}, {1,1,0}, {1,1,1}},
    {{0,0,0}, {1,0,0}, {1,0,1}, {0,0,1}},
    {{0,1,1}, {1,1,1}, {1,1,0}, {0,1,0}},
    {{1,0,0}, {0,0,0}, {0,1,0}, {1,1,0}},
    {{0,0,1}, {1,0,1}, {1,1,1}, {0,1,1}}
};

static float limitf(float a, float lo, float hi) {
    return a < lo ? lo : (a > hi ? hi : a);
}
static float tick(float timer, float dt) { return fmaxf(0.0f, timer - dt); }
static float wrap_angle(float a) {
    if (a > PI_F) a -= 2.0f * PI_F;
    if (a < -PI_F) a += 2.0f * PI_F;
    return a;
}
static float stick(int a) {
    a = clampi(a, -156, 156);
    if (abs(a) <= 14) return 0.0f;
    return (a > 0 ? a - 14 : a + 14) / 142.0f;
}
static void normalize_move(float *x, float *z) {
    float n = *x * *x + *z * *z;
    if (n > 1.0f) { n = 1.0f / sqrtf(n); *x *= n; *z *= n; }
}
static u32 rgb(int r, int g, int b) { return C2D_Color32(r, g, b, 255); }
static u32 block_color(int id) {
    return rgb(blockRGB[id][0], blockRGB[id][1], blockRGB[id][2]);
}
static bool voxel_inside(int x, int y, int z) {
    return x >= 0 && x < VW && y >= 0 && y < VH && z >= 0 && z < VD;
}
static int block_at(int x, int y, int z) {
    return voxel_inside(x, y, z) ? voxel.blocks[x][y][z] : 0;
}
static bool voxel_solid(int x, int y, int z) {
    if (x < 0 || x >= VW || z < 0 || z >= VD || y < 0) return true;
    return y < VH && voxel.blocks[x][y][z] != 0;
}
static bool body_hits(float x, float y, float z) {
    int x0 = (int)floorf(x - BODY_R + 0.0001f);
    int x1 = (int)floorf(x + BODY_R - 0.0001f);
    int z0 = (int)floorf(z - BODY_R + 0.0001f);
    int z1 = (int)floorf(z + BODY_R - 0.0001f);
    int y0 = (int)floorf(y + 0.0001f);
    int y1 = (int)floorf(y + BODY_H - 0.0001f);
    for (int ix = x0; ix <= x1; ++ix)
        for (int iz = z0; iz <= z1; ++iz)
            for (int iy = y0; iy <= y1; ++iy)
                if (voxel_solid(ix, iy, iz)) return true;
    return false;
}
/* Physics is substepped; binary contact resolution avoids sinking or tunnelling. */
static bool voxel_axis(int axis, float amount) {
    float *p = axis == 0 ? &voxel.x : (axis == 1 ? &voxel.y : &voxel.z);
    float start = *p;
    *p += amount;
    if (!body_hits(voxel.x, voxel.y, voxel.z)) return false;
    float lo = 0, hi = 1;
    for (int i = 0; i < 10; ++i) {
        float mid = (lo + hi) * 0.5f;
        *p = start + mid * amount;
        if (body_hits(voxel.x, voxel.y, voxel.z)) hi = mid;
        else lo = mid;
    }
    *p = start + lo * amount;
    return true;
}
static Target voxel_target(void) {
    Target t = {0};
    float cp = cosf(voxel.pitch);
    float dir[3] = {sinf(voxel.yaw) * cp, sinf(voxel.pitch), cosf(voxel.yaw) * cp};
    float pos[3] = {voxel.x, voxel.y + EYE_H, voxel.z};
    int cell[3], step[3];
    float next[3], delta[3];
    for (int a = 0; a < 3; ++a) {
        cell[a] = (int)floorf(pos[a]);
        step[a] = dir[a] >= 0 ? 1 : -1;
        delta[a] = fabsf(dir[a]) > 0.000001f ? 1.0f / fabsf(dir[a]) : 1.0e20f;
        next[a] = delta[a] * (step[a] > 0 ? cell[a] + 1 - pos[a] : pos[a] - cell[a]);
    }
    float distance = 0;
    for (int i = 0; i < 40 && distance <= VREACH; ++i) {
        if (block_at(cell[0], cell[1], cell[2])) {
            t.x = cell[0]; t.y = cell[1]; t.z = cell[2]; t.hit = true;
            return t;
        }
        t.px = cell[0]; t.py = cell[1]; t.pz = cell[2]; t.adjacent = true;
        int a = next[0] < next[1] ? 0 : 1;
        if (next[2] < next[a]) a = 2;
        distance = next[a];
        next[a] += delta[a];
        cell[a] += step[a];
    }
    t.adjacent = false;
    return t;
}
static void voxel_message(const char *text) {
    voxel.message = text; voxel.messageTime = 1.5f;
}
static void voxel_edit(bool place) {
    Target t = voxel_target();
    if (!t.hit) { voxel_message("No block within 4.5 blocks."); return; }
    if (!place) {
        if (t.y == 0) voxel_message("The base layer cannot be removed.");
        else { voxel.blocks[t.x][t.y][t.z] = 0; voxel_message("Block removed."); }
    } else if (!t.adjacent || !voxel_inside(t.px, t.py, t.pz) || t.py == 0) {
        voxel_message("World edge: cannot place here.");
    } else if (block_at(t.px, t.py, t.pz) ||
               (voxel.x + BODY_R > t.px && voxel.x - BODY_R < t.px + 1 &&
                voxel.y + BODY_H > t.py && voxel.y < t.py + 1 &&
                voxel.z + BODY_R > t.pz && voxel.z - BODY_R < t.pz + 1)) {
        voxel_message("No space: step away from the block.");
    } else {
        voxel.blocks[t.px][t.py][t.pz] = (unsigned char)voxel.selected;
        voxel_message("Block placed. RAM only.");
    }
    voxel.target = voxel_target();
}
static void voxel_reset(void) {
    memset(&voxel, 0, sizeof(voxel));
    for (int x = 0; x < VW; ++x) for (int z = 0; z < VD; ++z) {
        voxel.blocks[x][0][z] = 6;
        voxel.blocks[x][1][z] = 1;
        /* Low, stepped hills leave a broad open building area at the spawn. */
        if ((x > 10 && z > 8) || (x < 4 && z > 10)) voxel.blocks[x][2][z] = 1;
        if (x > 12 && z > 11) voxel.blocks[x][3][z] = 2;
    }
    /* Original little coral arch and an ice/amber sculpture. */
    for (int y = 2; y <= 4; ++y) {
        voxel.blocks[6][y][7] = 3; voxel.blocks[9][y][7] = 3;
    }
    for (int x = 6; x <= 9; ++x) voxel.blocks[x][5][7] = 4;
    voxel.blocks[3][2][6] = 2; voxel.blocks[3][3][6] = 5;
    voxel.blocks[12][2][4] = 4; voxel.blocks[12][3][4] = 5;
    voxel.x = 7.5f; voxel.y = 2.0f; voxel.z = 3.5f;
    voxel.pitch = -0.18f; voxel.selected = 1; voxel.grounded = true;
    voxel.target = voxel_target();
}
static void voxel_update(GameInput in, float dt) {
    voxel.messageTime = tick(voxel.messageTime, dt);
    voxel.yaw = wrap_angle(voxel.yaw +
        ((!!(in.held & KEY_DRIGHT)) - (!!(in.held & KEY_DLEFT))) * 1.9f * dt);
    voxel.pitch = limitf(voxel.pitch +
        ((!!(in.held & KEY_DUP)) - (!!(in.held & KEY_DDOWN))) * 1.5f * dt, -1.30f, 1.25f);
    if (in.down & KEY_Y) voxel.selected = voxel.selected % 5 + 1;
    if ((in.down & KEY_A) && voxel.grounded) { voxel.vy = 5.4f; voxel.grounded = false; }
    float side = stick(in.circleX), forward = stick(in.circleY);
    normalize_move(&side, &forward);
    float sn = sinf(voxel.yaw), cs = cosf(voxel.yaw);
    int steps = dt > 0 ? (int)ceilf(dt * 120.0f) : 0;
    float step = steps ? dt / steps : 0;
    for (int i = 0; i < steps; ++i) {
        voxel_axis(0, (side * cs + forward * sn) * 2.8f * step);
        voxel_axis(2, (forward * cs - side * sn) * 2.8f * step);
        voxel.vy -= 14.0f * step;
        bool contact = voxel_axis(1, voxel.vy * step);
        voxel.grounded = voxel.vy <= 0 &&
            (contact || body_hits(voxel.x, voxel.y - 0.008f, voxel.z));
        if (contact || voxel.grounded) voxel.vy = 0;
    }
    voxel.target = voxel_target();
    if (in.down & KEY_L) voxel_edit(false);
    else if (in.down & KEY_R) voxel_edit(true);
}

static Vec3 to_view(float x, float y, float z) {
    x -= voxel.x; y -= voxel.y + EYE_H; z -= voxel.z;
    float forward = x * viewSin + z * viewCos;
    Vec3 p = {x * viewCos - z * viewSin,
              y * pitchCos - forward * pitchSin,
              forward * pitchCos + y * pitchSin};
    return p;
}
/* Sutherland-Hodgman in camera space: clip BEFORE perspective division,
 * including all four screen edges and both depth planes. No huge polygons. */
static float plane_distance(Vec3 p, int plane) {
    switch (plane) {
        case 0: return p.z - VNEAR;
        case 1: return VRANGE - p.z;
        case 2: return 200.0f * p.z + FOCAL * p.x;
        case 3: return 200.0f * p.z - FOCAL * p.x;
        case 4: return 120.0f * p.z + FOCAL * p.y;
        default: return 120.0f * p.z - FOCAL * p.y;
    }
}
static int clip_face(Vec3 *poly, int count) {
    Vec3 out[CLIP_MAX];
    for (int plane = 0; plane < 6 && count; ++plane) {
        int n = 0;
        Vec3 prev = poly[count - 1];
        float dp = plane_distance(prev, plane);
        for (int i = 0; i < count; ++i) {
            Vec3 cur = poly[i];
            float dc = plane_distance(cur, plane);
            if ((dp >= 0) != (dc >= 0)) {
                float t = dp / (dp - dc);
                if (n >= CLIP_MAX) return 0;
                out[n++] = (Vec3){prev.x + (cur.x - prev.x) * t,
                                  prev.y + (cur.y - prev.y) * t,
                                  prev.z + (cur.z - prev.z) * t};
            }
            if (dc >= 0) { if (n >= CLIP_MAX) return 0; out[n++] = cur; }
            prev = cur; dp = dc;
        }
        memcpy(poly, out, (size_t)n * sizeof(Vec3));
        count = n;
    }
    return count;
}
static void voxel_face(int x, int y, int z, int side, int id) {
    const int *normal = normals[side];
    if (block_at(x + normal[0], y + normal[1], z + normal[2])) return;
    float cx = x + 0.5f + normal[0] * 0.5f;
    float cy = y + 0.5f + normal[1] * 0.5f;
    float cz = z + 0.5f + normal[2] * 0.5f;
    if ((voxel.x - cx) * normal[0] + (voxel.y + EYE_H - cy) * normal[1] +
        (voxel.z - cz) * normal[2] <= 0.001f) return;
    Vec3 poly[CLIP_MAX];
    float depth = 0;
    for (int i = 0; i < 4; ++i) {
        poly[i] = to_view(x + corners[side][i][0], y + corners[side][i][1],
                          z + corners[side][i][2]);
        depth += poly[i].z * 0.25f;
    }
    int n = clip_face(poly, 4);
    if (n < 3 || triangleCount + n - 2 > TRI_MAX || faceCount >= FACE_MAX) return;
    Face *f = &faces[faceCount];
    f->depth = depth; f->n = n;
    for (int i = 0; i < n; ++i) {
        f->x[i] = limitf(200.0f + FOCAL * poly[i].x / poly[i].z, 0, 400);
        f->y[i] = limitf(120.0f - FOCAL * poly[i].y / poly[i].z, 0, 240);
    }
    static const float light[6] = {0.69f, 0.84f, 0.50f, 1.0f, 0.77f, 0.90f};
    float shade = light[side] * (((x + z) & 1) ? 0.95f : 1.0f);
    float fog = limitf((depth - 3.0f) / 9.0f, 0, 0.5f);
    bool target = voxel.target.hit && voxel.target.x == x && voxel.target.y == y && voxel.target.z == z;
    int r = (int)(blockRGB[id][0] * shade * (1 - fog) + 131 * fog);
    int g = (int)(blockRGB[id][1] * shade * (1 - fog) + 179 * fog);
    int b = (int)(blockRGB[id][2] * shade * (1 - fog) + 186 * fog);
    if (target) { r = (r + 255) / 2; g = (g + 244) / 2; b = (b + 155) / 2; }
    f->color = rgb(r, g, b);
    /* Bounded insertion sort, far-to-near, with no heap/qsort scratch storage. */
    int at = faceCount;
    while (at > 0 && faces[faceOrder[at - 1]].depth < depth) {
        faceOrder[at] = faceOrder[at - 1]; --at;
    }
    faceOrder[at] = faceCount++;
    triangleCount += n - 2;
}
static void voxel_draw(void) {
    viewSin = sinf(voxel.yaw); viewCos = cosf(voxel.yaw);
    pitchSin = sinf(voxel.pitch); pitchCos = cosf(voxel.pitch);
    ui_rect(0, 0, 400, 240, rgb(131, 179, 196));
    float horizon = limitf(120.0f + FOCAL * tanf(voxel.pitch), 0, 240);
    ui_rect(0, horizon, 400, 240 - horizon, rgb(118, 155, 144));
    faceCount = triangleCount = 0;
    int px = (int)floorf(voxel.x), pz = (int)floorf(voxel.z);
    /* Near shells get first claim on the budget. Hidden/back-facing/frustum-
     * clipped faces consume no slots, so the normal sparse world fits easily. */
    for (int ring = 0; ring <= 7; ++ring) {
        for (int x = px - ring; x <= px + ring; ++x) {
            if (x < 0 || x >= VW) continue;
            for (int z = pz - ring; z <= pz + ring; ++z) {
                if (z < 0 || z >= VD || (abs(x - px) != ring && abs(z - pz) != ring)) continue;
                float dx = x + 0.5f - voxel.x, dz = z + 0.5f - voxel.z;
                if (dx * dx + dz * dz > VRANGE * VRANGE) continue;
                for (int y = 0; y < VH; ++y) {
                    int id = voxel.blocks[x][y][z];
                    if (id) for (int s = 0; s < 6; ++s) voxel_face(x, y, z, s, id);
                }
            }
        }
    }
    for (int i = 0; i < faceCount; ++i) {
        const Face *f = &faces[faceOrder[i]];
        for (int j = 1; j < f->n - 1; ++j)
            ui_triangle(f->x[0], f->y[0], f->x[j], f->y[j], f->x[j + 1], f->y[j + 1], f->color);
    }
    ui_rect(0, 0, 400, 23, rgb(27, 45, 49));
    ui_text(9, 3, 0.45f, COL_TEXT, "BLOCK GARDEN");
    ui_text(260, 4, 0.38f, COL_TEXT, "L break / R place");
    u32 aim = voxel.target.hit ? rgb(255, 241, 139) : COL_TEXT;
    ui_rect(193, 119, 5, 2, aim); ui_rect(202, 119, 5, 2, aim);
    ui_rect(199, 113, 2, 5, aim); ui_rect(199, 122, 2, 5, aim);
}

static int maze_tile(int x, int z) {
    return x < 0 || x >= MN || z < 0 || z >= MN ? 1 : mazeMap[z][x] - '0';
}
static bool maze_body(float x, float z, float radius) {
    return maze_tile((int)floorf(x - radius), (int)floorf(z - radius)) != 1 &&
           maze_tile((int)floorf(x + radius), (int)floorf(z - radius)) != 1 &&
           maze_tile((int)floorf(x - radius), (int)floorf(z + radius)) != 1 &&
           maze_tile((int)floorf(x + radius), (int)floorf(z + radius)) != 1;
}
static RayHit maze_cast(float x, float z, float dx, float dz, float maxDistance) {
    int ix = (int)floorf(x), iz = (int)floorf(z);
    int sx = dx >= 0 ? 1 : -1, sz = dz >= 0 ? 1 : -1;
    float tx = fabsf(dx) > 0.000001f ? 1.0f / fabsf(dx) : 1.0e20f;
    float tz = fabsf(dz) > 0.000001f ? 1.0f / fabsf(dz) : 1.0e20f;
    float nx = (sx > 0 ? ix + 1 - x : x - ix) * tx;
    float nz = (sz > 0 ? iz + 1 - z : z - iz) * tz;
    RayHit hit = {maxDistance, ix, iz, 0, 0};
    for (int i = 0; i < MN * 2 + 4; ++i) {
        float distance;
        int side;
        if (nx < nz) { distance = nx; nx += tx; ix += sx; side = 0; }
        else { distance = nz; nz += tz; iz += sz; side = 1; }
        if (distance > maxDistance) break;
        if (maze_tile(ix, iz) == 1) {
            hit = (RayHit){fmaxf(0.001f, distance), ix, iz, side, 1};
            break;
        }
    }
    return hit;
}
static bool maze_los(float x, float z, float bx, float bz) {
    float dx = bx - x, dz = bz - z, distance = sqrtf(dx * dx + dz * dz);
    if (distance < 0.001f) return true;
    RayHit h = maze_cast(x, z, dx / distance, dz / distance, distance);
    return !h.tile;
}
static void maze_reset(void) {
    static const float spawns[ROBOTS][2] = {
        {5.5f, 1.5f}, {9.5f, 1.5f}, {5.5f, 5.5f},
        {3.5f, 7.5f}, {7.5f, 9.5f}, {11.5f, 9.5f}
    };
    memset(&maze, 0, sizeof(maze));
    maze.x = 1.5f; maze.z = 1.5f; maze.yaw = PI_F * 0.5f;
    maze.health = 100; maze.remaining = ROBOTS;
    for (int i = 0; i < ROBOTS; ++i) {
        maze.robots[i].x = spawns[i][0]; maze.robots[i].z = spawns[i][1];
        maze.robots[i].hp = 2; maze.robots[i].attack = 1.2f + i * 0.15f;
    }
}
static void maze_shoot(void) {
    if (maze.result || maze.shot > 0) return;
    maze.shot = 0.24f; maze.muzzle = 0.07f;
    float dx = sinf(maze.yaw), dz = cosf(maze.yaw);
    float nearest = maze_cast(maze.x, maze.z, dx, dz, 9.0f).distance;
    int target = -1;
    for (int i = 0; i < ROBOTS; ++i) {
        Robot *r = &maze.robots[i];
        if (r->hp <= 0) continue;
        float rx = r->x - maze.x, rz = r->z - maze.z;
        float along = rx * dx + rz * dz, across = rx * dz - rz * dx;
        if (along <= 0 || fabsf(across) > 0.30f) continue;
        float entry = along - sqrtf(fmaxf(0, 0.09f - across * across));
        /* Also require centre LOS: a robot behind a corner cannot be hit via
         * its radius protruding through a wall. Same LOS governs enemy fire. */
        if (entry < nearest && maze_los(maze.x, maze.z, r->x, r->z)) {
            nearest = entry; target = i;
        }
    }
    if (target >= 0) {
        Robot *r = &maze.robots[target];
        r->flash = 0.15f; maze.hit = 0.16f;
        if (--r->hp == 0) --maze.remaining;
    }
}
static bool robot_space(int index, float x, float z) {
    if (!maze_body(x, z, 0.23f)) return false;
    for (int j = 0; j < ROBOTS; ++j) {
        if (j == index || maze.robots[j].hp <= 0) continue;
        float dx = x - maze.robots[j].x, dz = z - maze.robots[j].z;
        if (dx * dx + dz * dz < 0.24f) return false;
    }
    return true;
}
static void maze_update(GameInput in, float dt) {
    if (maze.result) return;
    maze.shot = tick(maze.shot, dt); maze.muzzle = tick(maze.muzzle, dt);
    maze.hurt = tick(maze.hurt, dt); maze.hit = tick(maze.hit, dt);
    float turn = (!!(in.held & (KEY_R | KEY_DRIGHT))) - (!!(in.held & (KEY_L | KEY_DLEFT)));
    maze.yaw = wrap_angle(maze.yaw + turn * 2.05f * dt);
    float side = stick(in.circleX);
    float forward = stick(in.circleY) + (!!(in.held & KEY_DUP)) - (!!(in.held & KEY_DDOWN));
    normalize_move(&side, &forward);
    float sn = sinf(maze.yaw), cs = cosf(maze.yaw);
    int steps = dt > 0 ? (int)ceilf(dt * 120.0f) : 0;
    float step = steps ? dt / steps : 0;
    for (int i = 0; i < steps; ++i) {
        float nx = maze.x + (side * cs + forward * sn) * 2.25f * step;
        if (maze_body(nx, maze.z, BODY_R)) maze.x = nx;
        float nz = maze.z + (forward * cs - side * sn) * 2.25f * step;
        if (maze_body(maze.x, nz, BODY_R)) maze.z = nz;
    }
    if ((in.down | in.held) & KEY_A) maze_shoot();
    for (int i = 0; i < ROBOTS; ++i) {
        Robot *r = &maze.robots[i];
        r->flash = tick(r->flash, dt);
        if (r->hp <= 0) continue;
        float dx = maze.x - r->x, dz = maze.z - r->z;
        float distance = sqrtf(dx * dx + dz * dz);
        bool sees = distance < 7.0f && maze_los(r->x, r->z, maze.x, maze.z);
        if (!sees) { r->attack = fmaxf(0.45f, r->attack - dt); continue; }
        if (distance > 1.8f) {
            float nx = r->x + dx / distance * 0.55f * dt;
            if (robot_space(i, nx, r->z)) r->x = nx;
            float nz = r->z + dz / distance * 0.55f * dt;
            if (robot_space(i, r->x, nz)) r->z = nz;
        }
        r->attack = tick(r->attack, dt);
        if (r->attack <= 0 && dt > 0 && distance < 6.0f && maze_los(r->x, r->z, maze.x, maze.z)) {
            maze.health = clampi(maze.health - 10, 0, 100);
            maze.hurt = 0.22f; r->attack = 1.55f;
        }
    }
    if (maze.health <= 0) maze.result = -1;
    else if (maze.remaining == 0 && maze_tile((int)maze.x, (int)maze.z) == 2) maze.result = 1;
}

static void screen_strip(float x, float y, float w, float h, u32 color) {
    float top = limitf(y, 0, 240), bottom = limitf(y + h, 0, 240);
    if (bottom > top) ui_rect(x, top, w, bottom - top, color);
}
static void maze_draw(void) {
    float sn = sinf(maze.yaw), cs = cosf(maze.yaw);
    ui_rect(0, 0, 400, 120, rgb(20, 26, 44));
    ui_rect(0, 120, 400, 120, rgb(37, 41, 53));
    for (int col = 0; col < RAYS; ++col) {
        float cameraX = ((col + 0.5f) * STRIP - 200) / FOCAL;
        RayHit h = maze_cast(maze.x, maze.z, sn + cs * cameraX, cs - sn * cameraX, 18);
        wallDepth[col] = h.distance;
        float height = FOCAL / h.distance, top = 120 - height * 0.5f;
        float shade = (h.side ? 1.0f : 0.72f) / (1 + h.distance * 0.12f);
        int pattern = (h.x + h.z) & 1;
        u32 wall = rgb((int)((pattern ? 73 : 83) * shade),
                       (int)((pattern ? 119 : 105) * shade), (int)(158 * shade));
        screen_strip(col * STRIP, top, STRIP, height, wall);
        screen_strip(col * STRIP, top + height * 0.72f, STRIP, height * 0.045f,
                     rgb((int)(68 * shade), (int)(202 * shade), (int)(192 * shade)));
    }
    /* Pick the nearest billboard per screen column. Wall depth clips enemies
     * and the exit even when only part of a sprite is visible around a corner.
     * At most four rectangles per column, independent of enemy overlap. */
    float depths[ROBOTS + 1], centers[ROBOTS + 1], widths[ROBOTS + 1];
    for (int i = 0; i <= ROBOTS; ++i) {
        float x = (i == ROBOTS ? 11.5f : maze.robots[i].x) - maze.x;
        float z = (i == ROBOTS ? 11.5f : maze.robots[i].z) - maze.z;
        depths[i] = x * sn + z * cs;
        if (depths[i] > 0.1f) {
            centers[i] = 200 + FOCAL * (x * cs - z * sn) / depths[i];
            widths[i] = FOCAL * 0.64f / depths[i];
        } else { centers[i] = -10000; widths[i] = 0; }
    }
    for (int col = 0; col < RAYS; ++col) {
        float nearest = wallDepth[col], screenX = (col + 0.5f) * STRIP;
        int selected = -1;
        for (int i = 0; i <= ROBOTS; ++i) {
            if (i < ROBOTS && maze.robots[i].hp <= 0) continue;
            if (depths[i] <= 0.1f || depths[i] >= nearest || depths[i] > 12) continue;
            if (fabsf(screenX - centers[i]) > widths[i] * 0.5f) continue;
            nearest = depths[i]; selected = i;
        }
        if (selected < 0) continue;
        float scale = FOCAL / nearest, height = scale * 0.92f;
        float top = 120 + scale * 0.5f - height;
        float u = (screenX - centers[selected]) / widths[selected] + 0.5f;
        float x = col * STRIP;
        if (selected == ROBOTS) {
            u32 color = maze.remaining ? rgb(175, 100, 56) : rgb(78, 239, 161);
            if (u < 0.17f || u > 0.83f) screen_strip(x, top, STRIP, height, color);
            else {
                screen_strip(x, top, STRIP, height * 0.12f, color);
                screen_strip(x, top + height * 0.88f, STRIP, height * 0.12f, color);
            }
            continue;
        }
        const Robot *r = &maze.robots[selected];
        u32 body = r->flash > 0 ? rgb(250, 249, 206) :
                   (r->hp == 1 ? rgb(178, 100, 192) : rgb(204, 112, 72));
        u32 eye = r->attack < 0.4f ? rgb(255, 61, 61) : rgb(123, 249, 229);
        if (u > 0.20f && u < 0.80f) screen_strip(x, top, STRIP, height * 0.27f, body);
        if (u > 0.12f && u < 0.88f) screen_strip(x, top + height * 0.32f, STRIP, height * 0.41f, body);
        if ((u > 0.19f && u < 0.43f) || (u > 0.57f && u < 0.81f))
            screen_strip(x, top + height * 0.76f, STRIP, height * 0.24f, rgb(113, 127, 153));
        if (u > 0.30f && u < 0.70f) screen_strip(x, top + height * 0.10f, STRIP, height * 0.09f, eye);
    }
    /* Original geometric pulse tool, not a borrowed weapon sprite. */
    ui_rect(175, 214, 50, 26, rgb(48, 61, 81));
    ui_rect(184, 194, 32, 39, rgb(92, 107, 131));
    ui_rect(191, 184, 18, 35, rgb(33, 41, 57));
    ui_rect(195, 188, 10, 17, rgb(89, 228, 215));
    if (maze.muzzle > 0) {
        ui_rect(190, 169, 20, 13, rgb(151, 255, 239));
        ui_rect(197, 160, 6, 25, COL_TEXT);
    }
    u32 aim = maze.hit > 0 ? rgb(255, 225, 124) : COL_TEXT;
    ui_rect(193, 119, 5, 2, aim); ui_rect(202, 119, 5, 2, aim);
    ui_rect(199, 113, 2, 5, aim); ui_rect(199, 122, 2, 5, aim);
    ui_rect(0, 0, 400, 24, rgb(16, 22, 35));
    ui_text(9, 3, 0.44f, COL_TEXT, "NEON CIRCUIT");
    ui_text(259, 4, 0.40f, COL_TEXT, "HP %d  Bots %d", maze.health, maze.remaining);
    if (maze.hurt > 0) {
        ui_rect(0, 24, 5, 216, rgb(207, 60, 74)); ui_rect(395, 24, 5, 216, rgb(207, 60, 74));
    }
    if (maze.result) {
        ui_rect(55, 74, 290, 78, rgb(21, 29, 46));
        ui_text_center(200, 85, 0.62f, maze.result > 0 ? COL_GREEN : rgb(255, 130, 118),
                       maze.result > 0 ? "CIRCUIT CLEARED" : "ROBOT SHUTDOWN");
        ui_text_center(200, 118, 0.42f, COL_TEXT, "X: restart   B: exit");
    }
}

static void map_player(float ox, float oy, float cell, float x, float z, float yaw) {
    float px = ox + x * cell, py = oy + z * cell;
    float sn = sinf(yaw), cs = cosf(yaw);
    ui_triangle(px + sn * 4, py + cs * 4, px - sn * 3 - cs * 3,
                py - cs * 3 + sn * 3, px - sn * 3 + cs * 3,
                py - cs * 3 - sn * 3, COL_TEXT);
}
static int voxel_map_id(int x, int z) {
    for (int y = VH - 1; y >= 0; --y) if (voxel.blocks[x][y][z]) return voxel.blocks[x][y][z];
    return 0;
}
static void voxel_bottom(void) {
    ui_rect(0, 0, 320, 240, rgb(20, 32, 37));
    ui_text(10, 5, 0.50f, COL_TEXT, "BLOCK GARDEN");
    for (int z = 0; z < VD; ++z) {
        for (int x = 0; x < VW;) {
            int id = voxel_map_id(x, z), end = x + 1;
            while (end < VW && voxel_map_id(end, z) == id) ++end;
            ui_rect(10 + x * 6, 33 + z * 6, (end - x) * 6, 6, block_color(id));
            x = end;
        }
    }
    map_player(10, 33, 6, voxel.x, voxel.z, voxel.yaw);
    ui_text(120, 33, 0.43f, COL_TEXT, "Block: %s", tr(blockNames[voxel.selected]));
    for (int i = 1; i <= 5; ++i) {
        float x = 120 + (i - 1) * 36;
        if (voxel.selected == i) ui_rect(x - 2, 61, 32, 30, COL_TEXT);
        ui_rect(x, 63, 28, 26, block_color(i));
    }
    ui_text(120, 99, 0.36f, COL_TEXT, "RAM only - no disk save");
    ui_text(120, 116, 0.36f, COL_SUBTEXT, "X resets every block");
    ui_text(10, 143, 0.40f, COL_TEXT, "Pad: move/strafe  D-pad: look");
    ui_text(10, 161, 0.40f, COL_TEXT, "A: jump  L: break  R: place");
    ui_text(10, 179, 0.40f, COL_TEXT, "Y / tap color: choose block");
    ui_text(10, 197, 0.40f, COL_TEXT, "START: pause  B: exit  X: reset");
    ui_text(10, 220, 0.36f, rgb(177, 218, 184), "%s", tr(voxel.messageTime > 0 ?
            voxel.message : "Reach: 4.5 blocks. Base layer is fixed."));
}
static void maze_bottom(void) {
    ui_rect(0, 0, 320, 240, rgb(20, 25, 40));
    ui_text(10, 5, 0.50f, COL_TEXT, "NEON CIRCUIT");
    for (int z = 0; z < MN; ++z) {
        for (int x = 0; x < MN;) {
            int tile = maze_tile(x, z), end = x + 1;
            while (end < MN && maze_tile(end, z) == tile) ++end;
            u32 color = tile == 1 ? rgb(73, 95, 124) : (tile == 2 ? COL_GREEN : rgb(31, 39, 56));
            ui_rect(10 + x * 8, 32 + z * 8, (end - x) * 8, 8, color);
            x = end;
        }
    }
    for (int i = 0; i < ROBOTS; ++i) if (maze.robots[i].hp > 0)
        ui_rect(8 + maze.robots[i].x * 8, 30 + maze.robots[i].z * 8, 4, 4, rgb(255, 144, 96));
    map_player(10, 32, 8, maze.x, maze.z, maze.yaw);
    ui_text(126, 33, 0.44f, COL_TEXT, "Health: %d", maze.health);
    ui_rect(127, 56, 172, 6, rgb(61, 66, 83));
    ui_rect(127, 56, 172 * maze.health / 100.0f, 6, maze.health > 30 ? COL_GREEN : rgb(235, 85, 94));
    ui_text(126, 68, 0.42f, COL_TEXT, "Robots: %d / %d", ROBOTS - maze.remaining, ROBOTS);
    ui_text(126, 89, 0.40f, maze.remaining ? COL_SUBTEXT : COL_GREEN,
            "Exit: %s", tr(maze.remaining ? "locked" : "OPEN"));
    ui_rect(126, 113, 182, 27, rgb(44, 63, 83));
    ui_text(141, 117, 0.42f, COL_TEXT, "Tap here: shoot");
    ui_text(10, 151, 0.39f, COL_TEXT, "Pad: move/strafe  D-pad: move/turn");
    ui_text(10, 169, 0.40f, COL_TEXT, "L/R: turn  A: shoot  X: restart");
    ui_text(10, 187, 0.40f, COL_TEXT, "START: pause  B: exit");
    ui_text(10, 211, 0.38f, rgb(137, 225, 202), "Clear robots; reach green exit.");
    ui_text(10, 226, 0.34f, COL_SUBTEXT, "2 hits per robot. Unlimited pulses.");
}

void world_start(GameKind kind) {
    active = kind == GAME_VOXEL || kind == GAME_MAZE;
    if (!active) return;
    current = kind;
    if (kind == GAME_VOXEL) voxel_reset(); else maze_reset();
}
void world_update(GameInput input) {
    if (!active) return;
    if (input.down & KEY_X) { world_start(current); return; }
    /* Do not invent elapsed time for short/zero frames or catch up after pause. */
    float dt = isfinite(input.dt) ? limitf(input.dt, 0, 0.05f) : 0;
    if (current == GAME_VOXEL) voxel_update(input, dt); else maze_update(input, dt);
}
void world_touch(int x, int y) {
    if (!active || x < 0 || x >= 320 || y < 0 || y >= 240) return;
    if (current == GAME_VOXEL) {
        if (y >= 61 && y <= 91 && x >= 118 && x < 296) {
            int i = (x - 118) / 36;
            if ((x - 118) % 36 < 32) voxel.selected = i + 1;
        }
    } else if (x >= 126 && x < 308 && y >= 113 && y < 140) maze_shoot();
}
void world_draw_top(void) {
    if (!active) return;
    if (current == GAME_VOXEL) voxel_draw(); else maze_draw();
}
void world_draw_bottom(void) {
    if (!active) return;
    if (current == GAME_VOXEL) voxel_bottom(); else maze_bottom();
}
