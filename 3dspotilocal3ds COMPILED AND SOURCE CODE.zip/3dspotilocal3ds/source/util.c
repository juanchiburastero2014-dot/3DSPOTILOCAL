#include "common.h"
#include <sys/stat.h>

void path_join(char *out, size_t n, const char *a, const char *b) {
    snprintf(out, n, "%s/%s", a, b);
}

void strip_ext(char *s) {
    char *dot = strrchr(s, '.');
    char *slash = strrchr(s, '/');
    if (dot && (!slash || dot > slash)) *dot = '\0';
}

const char *path_basename(const char *p) {
    const char *slash = strrchr(p, '/');
    return slash ? slash + 1 : p;
}

bool file_exists(const char *p) {
    struct stat st;
    return stat(p, &st) == 0;
}