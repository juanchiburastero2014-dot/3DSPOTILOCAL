#ifndef VIBRA_COVERS_H
#define VIBRA_COVERS_H

#include "common.h"

#define COVERS_DIR "sdmc:/3dSpotiLocal/Covers"
#define COVERS_CFG "sdmc:/3dSpotiLocal/covers.cfg"

/* Create the Covers folder and load covers.cfg. */
void covers_init(void);

/* Image files found in /3dSpotiLocal/Covers (jpg, jpeg, png, bmp), sorted. */
void covers_refresh_list(void);
int  covers_image_count(void);
const char *covers_image_name(int i);
void covers_image_path(int i, char *out, size_t n);

/* Album cover chosen by the user (empty if none). */
bool covers_album_chosen(const Album *al, char *out, size_t n);
void covers_album_set(const Album *al, const char *imageName);    /* NULL = automatic */

/* Song cover: chosen in the app, or an image named like the song next to it. false = none. */
bool covers_track_find(const Album *al, const Track *t, char *out, size_t n);
void covers_track_set(const Album *al, const Track *t, const char *imageName);   /* NULL = automatic */

#endif
