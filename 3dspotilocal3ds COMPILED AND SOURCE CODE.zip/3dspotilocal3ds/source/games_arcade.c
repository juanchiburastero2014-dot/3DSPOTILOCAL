#include "games.h"
#include "gfx_ui.h"
#include "settings.h"
#include "i18n.h"
#include <math.h>

/* Quick arcade games: Snake, 2048, Breakout, Flappy, Minesweeper, Invaders.
 * One game is active at a time and lives in one fixed block of static memory. */

#define C_BG    C2D_Color32(16, 22, 30, 255)
#define C_PANEL C2D_Color32(30, 40, 54, 255)
#define C_LINE  C2D_Color32(52, 66, 84, 255)
#define C_RED   C2D_Color32(240, 84, 84, 255)
#define C_GOLD  C2D_Color32(250, 204, 70, 255)
#define C_BLUE  C2D_Color32(80, 160, 240, 255)
#define C_WHITE C2D_Color32(255, 255, 255, 255)
#define C_INK   C2D_Color32(12, 16, 22, 255)

enum { D_UP, D_DOWN, D_LEFT, D_RIGHT };

static GameKind kind;
static u32 rng = 0x9e3779b9u;

static u32 rnd(void) {
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return rng;
}
static int rn(int n) { return n > 0 ? (int)(rnd() % (u32)n) : 0; }
static float fclampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static u32 rgb(const u8 *c) { return C2D_Color32(c[0], c[1], c[2], 255); }
static int diff(void) { return clampi(g_settings.difficulty, 0, 2); }
static int best(void) { return settings_best((int)kind); }
static void note(int score) { settings_note_score((int)kind, score); }

/* ---- shared input helpers ---- */
static int pad_dir(GameInput in) {
    if (in.down & KEY_DUP) return D_UP;
    if (in.down & KEY_DDOWN) return D_DOWN;
    if (in.down & KEY_DLEFT) return D_LEFT;
    if (in.down & KEY_DRIGHT) return D_RIGHT;
    return -1;
}

static int stick_dir(GameInput in) {
    int ax = abs(in.circleX), ay = abs(in.circleY);
    if (ax < 70 && ay < 70) return -1;
    if (ax >= ay) return in.circleX > 0 ? D_RIGHT : D_LEFT;
    return in.circleY > 0 ? D_UP : D_DOWN;
}

static int pad_touch(int x, int y) {
    if (x >= 110 && x < 210 && y >= 36 && y < 96) return D_UP;
    if (x >= 110 && x < 210 && y >= 156 && y < 216) return D_DOWN;
    if (x >= 14 && x < 104 && y >= 96 && y < 156) return D_LEFT;
    if (x >= 216 && x < 306 && y >= 96 && y < 156) return D_RIGHT;
    return -1;
}

static void draw_pad(const char *hint) {
    ui_text_center(160, 10, 0.4f, COL_SUBTEXT, hint);
    ui_rounded(110, 36, 100, 60, 10, C_PANEL);
    ui_triangle(160, 46, 138, 82, 182, 82, COL_GREEN);
    ui_rounded(110, 156, 100, 60, 10, C_PANEL);
    ui_triangle(160, 206, 138, 170, 182, 170, COL_GREEN);
    ui_rounded(14, 96, 90, 60, 10, C_PANEL);
    ui_triangle(26, 126, 80, 106, 80, 146, COL_GREEN);
    ui_rounded(216, 96, 90, 60, 10, C_PANEL);
    ui_triangle(294, 126, 240, 106, 240, 146, COL_GREEN);
    ui_text_center(160, 224, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
}

static void overlay(const char *title, const char *sub) {
    ui_rounded(80, 78, 240, 84, 10, C_PANEL);
    ui_rect(80, 78, 240, 3, COL_GREEN);
    ui_text_center(200, 92, 0.65f, C_WHITE, title);
    ui_text_center(200, 128, 0.4f, COL_SUBTEXT, sub);
}

static void hud(int score) {
    ui_rect(0, 0, 400, 22, C_PANEL);
    ui_text(8, 4, 0.45f, C_WHITE, "%s", game_title(kind));
    char line[48];
    snprintf(line, sizeof(line), tr("Puntos %d   Record %d"), score, best() > score ? best() : score);
    ui_text_right(392, 4, 0.45f, COL_GREEN, line);
}

/* ================================ SNAKE ================================ */
#define SN_W 30
#define SN_H 17
#define SN_CELL 12
#define SN_OX 20
#define SN_OY 30
#define SN_MAX (SN_W * SN_H)
typedef struct { u8 x[SN_MAX], y[SN_MAX]; int len, dir, pending, fx, fy, score; float timer; bool over; } Snake;

static void snake_food(Snake *s) {
    for (int tries = 0; tries < 400; tries++) {
        int x = rn(SN_W), y = rn(SN_H);
        bool free_ = true;
        for (int i = 0; i < s->len && free_; i++) free_ = !(s->x[i] == x && s->y[i] == y);
        if (free_) { s->fx = x; s->fy = y; return; }
    }
    s->fx = s->fy = -1;
}

static void snake_start(Snake *s) {
    s->len = 3; s->dir = D_RIGHT; s->pending = -1;
    for (int i = 0; i < 3; i++) { s->x[i] = (u8)(SN_W / 2 - i); s->y[i] = SN_H / 2; }
    snake_food(s);
}

static void snake_turn(Snake *s, int d) {
    if (d >= 0 && (d ^ 1) != s->dir) s->pending = d;
}

static void snake_update(Snake *s, GameInput in) {
    if (s->over) return;
    int d = pad_dir(in);
    if (d < 0) d = stick_dir(in);
    snake_turn(s, d);
    float interval = (diff() == 0 ? 0.17f : diff() == 1 ? 0.13f : 0.095f) - (float)s->len * 0.0012f;
    if (interval < 0.05f) interval = 0.05f;
    s->timer += in.dt;
    if (s->timer < interval) return;
    s->timer -= interval;
    if (s->pending >= 0) { s->dir = s->pending; s->pending = -1; }
    int nx = s->x[0], ny = s->y[0];
    if (s->dir == D_UP) ny--; else if (s->dir == D_DOWN) ny++;
    else if (s->dir == D_LEFT) nx--; else nx++;
    if (nx < 0 || nx >= SN_W || ny < 0 || ny >= SN_H) {
        if (diff() == 0) { nx = (nx + SN_W) % SN_W; ny = (ny + SN_H) % SN_H; }   /* easy: walls wrap */
        else { s->over = true; note(s->score); return; }
    }
    bool eat = nx == s->fx && ny == s->fy;
    int check = eat ? s->len : s->len - 1;
    for (int i = 0; i < check; i++)
        if (s->x[i] == nx && s->y[i] == ny) { s->over = true; note(s->score); return; }
    int last = eat ? s->len : s->len - 1;
    if (eat && s->len >= SN_MAX) last = s->len - 1;
    for (int i = last; i > 0; i--) { s->x[i] = s->x[i - 1]; s->y[i] = s->y[i - 1]; }
    s->x[0] = (u8)nx; s->y[0] = (u8)ny;
    if (eat) {
        if (s->len < SN_MAX) s->len++;
        s->score += 10;
        note(s->score);
        snake_food(s);
        if (s->fx < 0) { s->over = true; }   /* board full: you win, the game ends */
    }
}

static void snake_draw(Snake *s) {
    ui_rect(0, 0, 400, 240, C_BG);
    hud(s->score);
    ui_rect(SN_OX - 3, SN_OY - 3, SN_W * SN_CELL + 6, SN_H * SN_CELL + 6, C_LINE);
    ui_rect(SN_OX, SN_OY, SN_W * SN_CELL, SN_H * SN_CELL, C_INK);
    if (s->fx >= 0) ui_circle(SN_OX + s->fx * SN_CELL + 6, SN_OY + s->fy * SN_CELL + 6, 4.5f, C_RED);
    for (int i = s->len - 1; i >= 0; i--)
        ui_rounded(SN_OX + s->x[i] * SN_CELL + 1, SN_OY + s->y[i] * SN_CELL + 1, SN_CELL - 2, SN_CELL - 2, 3,
                   i == 0 ? C_GOLD : COL_GREEN);
    if (s->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

/* ================================ 2048 ================================= */
typedef struct { u8 t[4][4]; int score, prevStick; bool over, won; } G2048;

static bool g_spawn(G2048 *g) {
    int empty[16], n = 0;
    for (int i = 0; i < 16; i++) if (!g->t[i / 4][i % 4]) empty[n++] = i;
    if (!n) return false;
    int c = empty[rn(n)];
    g->t[c / 4][c % 4] = rn(10) == 0 ? 2 : 1;
    return true;
}

static bool g_can_move(const G2048 *g) {
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++) {
            if (!g->t[r][c]) return true;
            if (c < 3 && g->t[r][c] == g->t[r][c + 1]) return true;
            if (r < 3 && g->t[r][c] == g->t[r + 1][c]) return true;
        }
    return false;
}

static void g_start(G2048 *g) { g_spawn(g); g_spawn(g); }

static void g_cell(int dir, int line, int k, int *r, int *c) {
    switch (dir) {
        case D_LEFT:  *r = line; *c = k; break;
        case D_RIGHT: *r = line; *c = 3 - k; break;
        case D_UP:    *r = k; *c = line; break;
        default:      *r = 3 - k; *c = line; break;
    }
}

static void g_move(G2048 *g, int dir) {
    if (g->over) return;
    bool moved = false;
    for (int line = 0; line < 4; line++) {
        u8 out[4] = {0, 0, 0, 0};
        int n = 0;
        bool mergedLast = false;
        for (int k = 0; k < 4; k++) {
            int r, c;
            g_cell(dir, line, k, &r, &c);
            u8 v = g->t[r][c];
            if (!v) continue;
            if (n > 0 && out[n - 1] == v && !mergedLast) {
                out[n - 1]++;
                g->score += 1 << out[n - 1];
                mergedLast = true;
            } else {
                out[n++] = v;
                mergedLast = false;
            }
        }
        for (int k = 0; k < 4; k++) {
            int r, c;
            g_cell(dir, line, k, &r, &c);
            if (g->t[r][c] != out[k]) moved = true;
            g->t[r][c] = out[k];
            if (out[k] >= 11) g->won = true;
        }
    }
    if (!moved) return;
    g_spawn(g);
    note(g->score);
    if (!g_can_move(g)) g->over = true;
}

static void g_update(G2048 *g, GameInput in) {
    int d = pad_dir(in);
    int s = stick_dir(in);
    if (d < 0 && s >= 0 && s != g->prevStick) d = s;
    g->prevStick = s;
    if (d >= 0) g_move(g, d);
}

static u32 tile_color(int e) {
    static const u8 colors[12][3] = {{60,74,92},{238,228,218},{237,224,200},{242,177,121},{245,149,99},{246,124,95},{246,94,59},{237,207,114},{237,204,97},{237,200,80},{237,197,63},{237,194,46}};
    return rgb(colors[clampi(e, 0, 11)]);
}

static void g_draw(G2048 *g) {
    ui_rect(0, 0, 400, 240, C_BG);
    ui_rounded(90, 10, 220, 220, 8, C_LINE);
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++) {
            int e = g->t[r][c];
            float x = 94 + c * 54, y = 14 + r * 54;
            ui_rounded(x, y, 50, 50, 6, tile_color(e));
            if (e) {
                char num[12];
                snprintf(num, sizeof(num), "%d", 1 << e);
                ui_text_center(x + 25, y + (e < 7 ? 12 : e < 10 ? 15 : 17), e < 7 ? 0.8f : e < 10 ? 0.62f : 0.5f,
                               e < 3 ? C_INK : C_WHITE, num);
            }
        }
    ui_text(8, 10, 0.45f, C_WHITE, "2048");
    ui_text(8, 34, 0.42f, COL_GREEN, "Puntos %d", g->score);
    ui_text(8, 56, 0.38f, COL_SUBTEXT, "Record %d", best() > g->score ? best() : g->score);
    if (g->won && !g->over) ui_text(8, 90, 0.4f, C_GOLD, "Llegaste a 2048!");
    if (g->over) overlay("Sin movimientos", "X: jugar de nuevo   B: menu");
}

/* ============================== BREAKOUT =============================== */
#define BR_COLS 12
#define BR_ROWS 6
#define BR_PY 224
typedef struct {
    bool bricks[BR_ROWS][BR_COLS];
    float px, bx, by, vx, vy, pw;
    int alive, lives, score, level;
    bool stuck, over;
} Breakout;

static void br_bricks(Breakout *b) {
    for (int r = 0; r < BR_ROWS; r++) for (int c = 0; c < BR_COLS; c++) b->bricks[r][c] = true;
    b->alive = BR_ROWS * BR_COLS;
    b->stuck = true;
}

static float br_speed(const Breakout *b) {
    return (190.0f + (float)b->level * 16.0f) * (diff() == 0 ? 0.88f : diff() == 1 ? 1.0f : 1.18f);
}

static void br_start(Breakout *b) {
    b->pw = diff() == 0 ? 84.0f : diff() == 1 ? 64.0f : 48.0f;
    b->px = 200; b->lives = 3; b->level = 1;
    br_bricks(b);
}

static void br_step(Breakout *b, float h) {
    float px0 = b->bx, py0 = b->by;
    b->bx += b->vx * h;
    b->by += b->vy * h;
    if (b->bx < 4) { b->bx = 4; b->vx = fabsf(b->vx); }
    if (b->bx > 396) { b->bx = 396; b->vx = -fabsf(b->vx); }
    if (b->by < 26) { b->by = 26; b->vy = fabsf(b->vy); }
    if (b->vy > 0 && b->by + 4 >= BR_PY && b->by - 4 <= BR_PY + 8 &&
        b->bx >= b->px - b->pw / 2 - 4 && b->bx <= b->px + b->pw / 2 + 4) {
        float off = fclampf((b->bx - b->px) / (b->pw / 2), -1.0f, 1.0f);
        float ang = off * 1.0f, sp = sqrtf(b->vx * b->vx + b->vy * b->vy);
        b->by = BR_PY - 4;
        b->vx = sp * sinf(ang);
        b->vy = -sp * cosf(ang);
    }
    int c0 = clampi((int)((b->bx - 8) / 32), 0, BR_COLS - 1), r0 = clampi((int)((b->by - 40) / 14), 0, BR_ROWS - 1);
    for (int r = r0 - 1; r <= r0 + 1; r++)
        for (int c = c0 - 1; c <= c0 + 1; c++) {
            if (r < 0 || c < 0 || r >= BR_ROWS || c >= BR_COLS || !b->bricks[r][c]) continue;
            float x0 = 8 + c * 32, y0 = 40 + r * 14;
            if (b->bx + 4 < x0 || b->bx - 4 > x0 + 30 || b->by + 4 < y0 || b->by - 4 > y0 + 12) continue;
            b->bricks[r][c] = false;
            b->alive--;
            b->score += 10 * (BR_ROWS - r);
            note(b->score);
            if (py0 + 4 <= y0 || py0 - 4 >= y0 + 12) b->vy = -b->vy; else b->vx = -b->vx;
            (void)px0;
            return;
        }
}

static void br_update(Breakout *b, GameInput in) {
    if (b->over) return;
    b->px += (float)in.circleX / 156.0f * 330.0f * in.dt;
    if (in.held & KEY_DLEFT) b->px -= 300.0f * in.dt;
    if (in.held & KEY_DRIGHT) b->px += 300.0f * in.dt;
    if (in.held & KEY_TOUCH) b->px = (float)in.touchX * 400.0f / 320.0f;
    b->px = fclampf(b->px, b->pw / 2, 400 - b->pw / 2);
    if (b->stuck) {
        b->bx = b->px; b->by = BR_PY - 6;
        if (in.down & (KEY_A | KEY_TOUCH | KEY_DUP)) {
            float sp = br_speed(b);
            b->vx = sp * 0.35f; b->vy = -sp * 0.94f;
            b->stuck = false;
        }
        return;
    }
    float sp = sqrtf(b->vx * b->vx + b->vy * b->vy);
    int steps = (int)ceilf(sp * in.dt / 3.0f);
    if (steps < 1) steps = 1;
    if (steps > 40) steps = 40;
    for (int i = 0; i < steps && !b->stuck; i++) {
        br_step(b, in.dt / (float)steps);
        if (b->by > 244) {
            b->lives--;
            b->stuck = true;
            if (b->lives <= 0) b->over = true;
        }
        if (b->alive <= 0) {
            b->level++;
            b->score += 50;
            note(b->score);
            br_bricks(b);
        }
    }
}

static void br_draw(Breakout *b) {
    static const u8 rows[BR_ROWS][3] = {{240,84,84},{244,140,70},{250,204,70},{110,210,120},{80,160,240},{170,120,240}};
    ui_rect(0, 0, 400, 240, C_BG);
    hud(b->score);
    ui_text(8, 4, 0.45f, C_WHITE, "Rompe ladrillos   Vidas %d   Nivel %d", b->lives, b->level);
    ui_rect(0, 22, 400, 3, COL_GREEN);
    for (int r = 0; r < BR_ROWS; r++)
        for (int c = 0; c < BR_COLS; c++)
            if (b->bricks[r][c]) ui_rounded(8 + c * 32, 40 + r * 14, 30, 12, 2, rgb(rows[r]));
    ui_rounded(b->px - b->pw / 2, BR_PY, b->pw, 8, 3, C_WHITE);
    ui_circle(b->bx, b->by, 4, COL_GREEN);
    if (b->stuck && !b->over) ui_text_center(200, 150, 0.42f, COL_SUBTEXT, "A o toca la pantalla para lanzar");
    if (b->over) overlay("Fin del juego", "X: jugar de nuevo   B: menu");
}

/* ================================ FLAPPY =============================== */
#define FL_PIPES 4
#define FL_SPACING 150
#define FL_W 36
#define FL_BX 90
typedef struct { float y, vy, px[FL_PIPES], gap[FL_PIPES]; bool passed[FL_PIPES]; int score; bool over, started; float dead, t; } Flappy;

static float fl_gap_h(void) { return diff() == 0 ? 104.0f : diff() == 1 ? 90.0f : 78.0f; }

static void fl_start(Flappy *f) {
    f->y = 110;
    for (int i = 0; i < FL_PIPES; i++) {
        f->px[i] = 420.0f + (float)i * FL_SPACING;
        f->gap[i] = 60.0f + (float)rn(80);
    }
}

static void fl_update(Flappy *f, GameInput in) {
    f->t += in.dt;
    bool flap = (in.down & (KEY_A | KEY_DUP | KEY_L | KEY_R | KEY_TOUCH)) != 0;
    if (f->over) {
        f->dead += in.dt;
        if (flap && f->dead > 0.6f) { memset(f, 0, sizeof(*f)); fl_start(f); }
        return;
    }
    if (!f->started) {
        f->y = 110 + sinf(f->t * 4) * 6;
        if (flap) { f->started = true; f->vy = -250; }
        return;
    }
    if (flap) f->vy = -250;
    f->vy += 780 * in.dt;
    f->y += f->vy * in.dt;
    float speed = fminf(105.0f + (float)f->score * 2.5f, 165.0f) * (diff() == 0 ? 0.92f : diff() == 1 ? 1.0f : 1.1f);
    float gapH = fl_gap_h();
    for (int i = 0; i < FL_PIPES; i++) {
        f->px[i] -= speed * in.dt;
        if (f->px[i] < -FL_W - 4) {
            float far = f->px[0];
            for (int j = 1; j < FL_PIPES; j++) if (f->px[j] > far) far = f->px[j];
            f->px[i] = far + FL_SPACING;
            f->gap[i] = 50.0f + (float)rn(100);
            f->passed[i] = false;
        }
        if (!f->passed[i] && f->px[i] + FL_W < FL_BX) {
            f->passed[i] = true;
            f->score++;
            note(f->score);
        }
        if (FL_BX + 9 > f->px[i] && FL_BX - 9 < f->px[i] + FL_W && (f->y - 9 < f->gap[i] || f->y + 9 > f->gap[i] + gapH))
            f->over = true;
    }
    if (f->y < 9 || f->y > 211) f->over = true;
}

static void fl_draw(Flappy *f) {
    ui_rect(0, 0, 400, 240, C2D_Color32(88, 190, 230, 255));
    ui_rect(0, 150, 400, 70, C2D_Color32(120, 208, 236, 255));
    float gapH = fl_gap_h();
    for (int i = 0; i < FL_PIPES; i++) {
        float x = f->px[i], g = f->gap[i];
        ui_rect(x, 0, FL_W, g, C2D_Color32(80, 190, 90, 255));
        ui_rect(x - 3, g - 12, FL_W + 6, 12, C2D_Color32(60, 160, 70, 255));
        ui_rect(x, g + gapH, FL_W, 220 - g - gapH, C2D_Color32(80, 190, 90, 255));
        ui_rect(x - 3, g + gapH, FL_W + 6, 12, C2D_Color32(60, 160, 70, 255));
    }
    ui_rect(0, 220, 400, 20, C2D_Color32(222, 200, 130, 255));
    ui_rect(0, 220, 400, 3, C2D_Color32(110, 170, 70, 255));
    ui_circle(FL_BX, f->y, 9, C_GOLD);
    ui_circle(FL_BX + 4, f->y - 3, 2.5f, C_WHITE);
    ui_triangle(FL_BX + 8, f->y, FL_BX + 15, f->y + 2, FL_BX + 8, f->y + 5, C2D_Color32(240, 120, 50, 255));
    char s[16];
    snprintf(s, sizeof(s), "%d", f->score);
    ui_text_center(200, 10, 1.0f, C_WHITE, s);
    ui_text(8, 6, 0.4f, C_WHITE, "Record %d", best() > f->score ? best() : f->score);
    if (!f->started) ui_text_center(200, 150, 0.45f, C_WHITE, "A o toca la pantalla para aletear");
    if (f->over) overlay("Te chocaste", "A / toca: reintentar   B: menu");
}

/* ============================== MINESWEEPER ============================ */
#define MS_W 13
#define MS_H 9
#define MS_CELL 24
#define MS_OX 4
#define MS_OY 12
typedef struct {
    u8 mine[MS_H][MS_W], cnt[MS_H][MS_W], st[MS_H][MS_W];   /* st: 0 hidden, 1 open, 2 flag */
    int cx, cy, mines, flags, opened;
    bool placed, over, won, flagMode;
    float time;
} Mines;

static int ms_mines(void) { return diff() == 0 ? 14 : diff() == 1 ? 20 : 28; }

static void ms_start(Mines *m) { m->mines = ms_mines(); m->cx = MS_W / 2; m->cy = MS_H / 2; }

static void ms_place(Mines *m, int sx, int sy) {
    int left = m->mines;
    while (left > 0) {
        int x = rn(MS_W), y = rn(MS_H);
        if (m->mine[y][x] || (abs(x - sx) <= 1 && abs(y - sy) <= 1)) continue;
        m->mine[y][x] = 1;
        left--;
    }
    for (int y = 0; y < MS_H; y++)
        for (int x = 0; x < MS_W; x++) {
            int n = 0;
            for (int dy = -1; dy <= 1; dy++)
                for (int dx = -1; dx <= 1; dx++) {
                    int nx = x + dx, ny = y + dy;
                    if ((dx || dy) && nx >= 0 && ny >= 0 && nx < MS_W && ny < MS_H) n += m->mine[ny][nx];
                }
            m->cnt[y][x] = (u8)n;
        }
    m->placed = true;
}

static void ms_reveal(Mines *m, int x, int y) {
    if (m->over || m->won || m->st[y][x] != 0) return;
    if (!m->placed) ms_place(m, x, y);
    if (m->mine[y][x]) { m->over = true; return; }
    int stack[MS_W * MS_H + 8], top = 0;
    stack[top++] = y * MS_W + x;
    while (top > 0) {
        int p = stack[--top], cx = p % MS_W, cy = p / MS_W;
        if (m->st[cy][cx] == 1) continue;
        if (m->st[cy][cx] == 2) m->flags--;
        m->st[cy][cx] = 1;
        m->opened++;
        if (m->cnt[cy][cx] != 0) continue;
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++) {
                int nx = cx + dx, ny = cy + dy;
                if ((dx || dy) && nx >= 0 && ny >= 0 && nx < MS_W && ny < MS_H && m->st[ny][nx] != 1 && top < MS_W * MS_H)
                    stack[top++] = ny * MS_W + nx;
            }
    }
    if (m->opened >= MS_W * MS_H - m->mines) {
        m->won = true;
        note(1000 - (int)fminf(m->time, 999.0f) + 100 * diff());
    }
}

static void ms_flag(Mines *m, int x, int y) {
    if (m->over || m->won || m->st[y][x] == 1) return;
    m->st[y][x] = m->st[y][x] == 2 ? 0 : 2;
    m->flags += m->st[y][x] == 2 ? 1 : -1;
}

static void ms_act(Mines *m, int x, int y, bool flag) { if (flag) ms_flag(m, x, y); else ms_reveal(m, x, y); }

static void ms_update(Mines *m, GameInput in) {
    if (m->placed && !m->over && !m->won) m->time += in.dt;
    int d = pad_dir(in);
    if (d == D_UP) m->cy = clampi(m->cy - 1, 0, MS_H - 1);
    if (d == D_DOWN) m->cy = clampi(m->cy + 1, 0, MS_H - 1);
    if (d == D_LEFT) m->cx = clampi(m->cx - 1, 0, MS_W - 1);
    if (d == D_RIGHT) m->cx = clampi(m->cx + 1, 0, MS_W - 1);
    if (in.down & KEY_Y) m->flagMode = !m->flagMode;
    if (in.down & KEY_A) ms_act(m, m->cx, m->cy, m->flagMode);
    if (in.down & (KEY_L | KEY_R)) ms_flag(m, m->cx, m->cy);
}

static void ms_touch(Mines *m, int x, int y) {
    int cx = (x - MS_OX) / MS_CELL, cy = (y - MS_OY) / MS_CELL;
    if (x < MS_OX || y < MS_OY || cx >= MS_W || cy >= MS_H) return;
    m->cx = cx; m->cy = cy;
    ms_act(m, cx, cy, m->flagMode);
}

static void ms_draw_top(Mines *m) {
    ui_rect(0, 0, 400, 240, C_BG);
    ui_text(20, 16, 0.6f, COL_GREEN, "Buscaminas");
    ui_text(20, 60, 0.5f, C_WHITE, "Minas: %d", m->mines - m->flags);
    ui_text(20, 90, 0.5f, C_WHITE, "Tiempo: %d s", (int)m->time);
    ui_text(20, 120, 0.45f, m->flagMode ? C_GOLD : COL_SUBTEXT, "Modo: %s (Y cambia)", tr(m->flagMode ? "BANDERA" : "DESCUBRIR"));
    ui_text(20, 160, 0.38f, COL_SUBTEXT, "Toca una casilla para actuar. Cruceta + A tambien.");
    ui_text(20, 180, 0.38f, COL_SUBTEXT, "L / R: poner o quitar bandera en el cursor.");
    ui_text(20, 214, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
    if (m->won) overlay("Ganaste!", "X: jugar de nuevo   B: menu");
    else if (m->over) overlay("Boom!", "X: jugar de nuevo   B: menu");
}

static void ms_draw_bottom(Mines *m) {
    static const u8 nums[9][3] = {{0,0,0},{80,160,240},{110,210,120},{240,84,84},{170,120,240},{220,120,60},{80,210,210},{240,240,240},{160,160,160}};
    ui_rect(0, 0, 320, 240, C_BG);
    for (int y = 0; y < MS_H; y++)
        for (int x = 0; x < MS_W; x++) {
            float px = MS_OX + x * MS_CELL, py = MS_OY + y * MS_CELL;
            bool open = m->st[y][x] == 1;
            ui_rect(px + 1, py + 1, MS_CELL - 2, MS_CELL - 2, open ? C_INK : C_LINE);
            if (open && m->cnt[y][x] > 0) {
                char n[4];
                snprintf(n, sizeof(n), "%d", m->cnt[y][x]);
                ui_text_center(px + 12, py + 4, 0.5f, rgb(nums[m->cnt[y][x]]), n);
            }
            if (m->st[y][x] == 2) {
                ui_rect(px + 11, py + 5, 2, 14, C_WHITE);
                ui_triangle(px + 12, py + 4, px + 12, py + 12, px + 20, py + 8, C_RED);
            }
            if ((m->over || m->won) && m->mine[y][x] && m->st[y][x] != 2) ui_circle(px + 12, py + 12, 6, m->won ? COL_GREEN : C_RED);
        }
    float px = MS_OX + m->cx * MS_CELL, py = MS_OY + m->cy * MS_CELL;
    ui_rect(px, py, MS_CELL, 2, COL_GREEN); ui_rect(px, py + MS_CELL - 2, MS_CELL, 2, COL_GREEN);
    ui_rect(px, py, 2, MS_CELL, COL_GREEN); ui_rect(px + MS_CELL - 2, py, 2, MS_CELL, COL_GREEN);
}

/* ================================ INVADERS ============================= */
#define IV_COLS 8
#define IV_ROWS 4
#define IV_ABMAX 3
typedef struct { bool on; float x, y; } Shot;
typedef struct {
    bool alive[IV_ROWS][IV_COLS];
    float ox, oy, dir, sx, fireCd, enemyCd, invuln;
    Shot mine, ab[IV_ABMAX];
    int lives, score, wave, left;
    bool over;
} Invaders;

static void iv_wave(Invaders *v) {
    for (int r = 0; r < IV_ROWS; r++) for (int c = 0; c < IV_COLS; c++) v->alive[r][c] = true;
    v->left = IV_ROWS * IV_COLS;
    v->ox = 30; v->oy = 34; v->dir = 1;
    v->mine.on = false;
    for (int i = 0; i < IV_ABMAX; i++) v->ab[i].on = false;
    v->enemyCd = 1.0f;
}

static void iv_start(Invaders *v) { v->lives = 3; v->wave = 1; v->sx = 200; iv_wave(v); }

static void iv_update(Invaders *v, GameInput in) {
    if (v->over) return;
    v->sx += (float)in.circleX / 156.0f * 280.0f * in.dt;
    if (in.held & KEY_DLEFT) v->sx -= 220.0f * in.dt;
    if (in.held & KEY_DRIGHT) v->sx += 220.0f * in.dt;
    if (in.held & KEY_TOUCH) v->sx = (float)in.touchX * 400.0f / 320.0f;
    v->sx = fclampf(v->sx, 18, 382);
    v->fireCd -= in.dt;
    v->invuln -= in.dt;
    if ((in.held & (KEY_A | KEY_TOUCH)) && v->fireCd <= 0 && !v->mine.on) {
        v->mine = (Shot){true, v->sx, 208};
        v->fireCd = 0.35f;
    }
    if (v->mine.on) {
        v->mine.y -= 340 * in.dt;
        if (v->mine.y < 22) v->mine.on = false;
    }
    float mul = diff() == 0 ? 0.8f : diff() == 1 ? 1.0f : 1.25f;
    float speed = (20.0f + (float)(IV_ROWS * IV_COLS - v->left) * 2.4f + (float)v->wave * 7.0f) * mul;
    v->ox += v->dir * speed * in.dt;
    int minC = IV_COLS, maxC = -1, low = -1;
    for (int r = 0; r < IV_ROWS; r++)
        for (int c = 0; c < IV_COLS; c++)
            if (v->alive[r][c]) { if (c < minC) minC = c; if (c > maxC) maxC = c; if (r > low) low = r; }
    if (maxC >= 0) {
        float left = v->ox + minC * 38, right = v->ox + maxC * 38 + 26;
        if ((v->dir > 0 && right > 394) || (v->dir < 0 && left < 6)) { v->dir = -v->dir; v->oy += 12; }
        if (v->oy + low * 26 + 18 >= 204) { v->over = true; note(v->score); return; }
    }
    if (v->mine.on) {
        for (int r = 0; r < IV_ROWS && v->mine.on; r++)
            for (int c = 0; c < IV_COLS; c++) {
                if (!v->alive[r][c]) continue;
                float x = v->ox + c * 38, y = v->oy + r * 26;
                if (v->mine.x > x && v->mine.x < x + 26 && v->mine.y > y && v->mine.y < y + 18) {
                    v->alive[r][c] = false; v->left--; v->mine.on = false;
                    v->score += 10 * (IV_ROWS - r);
                    note(v->score);
                    break;
                }
            }
    }
    v->enemyCd -= in.dt;
    if (v->enemyCd <= 0 && v->left > 0) {
        v->enemyCd = (1.5f - (float)v->wave * 0.08f) / mul * (0.6f + (float)rn(80) / 100.0f);
        if (v->enemyCd < 0.35f) v->enemyCd = 0.35f;
        for (int i = 0; i < IV_ABMAX; i++) {
            if (v->ab[i].on) continue;
            int c = rn(IV_COLS), r = -1;
            for (int rr = IV_ROWS - 1; rr >= 0 && r < 0; rr--) if (v->alive[rr][c]) r = rr;
            if (r >= 0) v->ab[i] = (Shot){true, v->ox + c * 38 + 13, v->oy + r * 26 + 18};
            break;
        }
    }
    for (int i = 0; i < IV_ABMAX; i++) {
        if (!v->ab[i].on) continue;
        v->ab[i].y += (120.0f + (float)v->wave * 10.0f) * mul * in.dt;
        if (v->ab[i].y > 240) v->ab[i].on = false;
        else if (v->invuln <= 0 && v->ab[i].y > 208 && v->ab[i].y < 224 && fabsf(v->ab[i].x - v->sx) < 16) {
            v->ab[i].on = false;
            v->lives--;
            v->invuln = 1.2f;
            if (v->lives <= 0) { v->over = true; note(v->score); }
        }
    }
    if (v->left <= 0) {
        v->wave++;
        v->score += 50;
        note(v->score);
        iv_wave(v);
    }
}

static void iv_draw(Invaders *v) {
    static const u8 rowc[IV_ROWS][3] = {{240,84,84},{244,140,70},{110,210,120},{80,160,240}};
    ui_rect(0, 0, 400, 240, C_BG);
    hud(v->score);
    ui_text(8, 4, 0.45f, C_WHITE, "Invasores   Vidas %d   Oleada %d", v->lives, v->wave);
    for (int r = 0; r < IV_ROWS; r++)
        for (int c = 0; c < IV_COLS; c++) {
            if (!v->alive[r][c]) continue;
            float x = v->ox + c * 38, y = v->oy + r * 26;
            u32 rc = rgb(rowc[r]);
            ui_rounded(x, y, 26, 14, 4, rc);
            ui_rect(x + 5, y + 4, 4, 4, C_INK);
            ui_rect(x + 17, y + 4, 4, 4, C_INK);
            ui_rect(x + 3, y + 14, 4, 4, rc);
            ui_rect(x + 19, y + 14, 4, 4, rc);
        }
    if (v->mine.on) ui_rect(v->mine.x - 1, v->mine.y, 3, 9, C_WHITE);
    for (int i = 0; i < IV_ABMAX; i++) if (v->ab[i].on) ui_rect(v->ab[i].x - 1, v->ab[i].y, 3, 9, C_RED);
    if (v->invuln <= 0 || ((int)(v->invuln * 10) & 1)) {
        ui_rect(v->sx - 14, 218, 28, 8, COL_GREEN);
        ui_triangle(v->sx - 6, 218, v->sx, 208, v->sx + 6, 218, COL_GREEN);
    }
    ui_rect(0, 230, 400, 2, C_LINE);
    if (v->over) overlay("Invadieron la Tierra", "X: jugar de nuevo   B: menu");
}

/* ============================== dispatcher ============================= */
static union { Snake snake; G2048 g; Breakout br; Flappy fl; Mines ms; Invaders iv; } st;

static void reset(void) {
    memset(&st, 0, sizeof(st));
    rng ^= (u32)osGetTime() * 2654435761u;
    if (!rng) rng = 0x9e3779b9u;
    switch (kind) {
        case GAME_SNAKE: snake_start(&st.snake); break;
        case GAME_2048: g_start(&st.g); break;
        case GAME_BREAKOUT: br_start(&st.br); break;
        case GAME_FLAPPY: fl_start(&st.fl); break;
        case GAME_MINES: ms_start(&st.ms); break;
        default: iv_start(&st.iv); break;
    }
}

void arcade_start(GameKind k) { kind = k; reset(); }

void arcade_update(GameInput in) {
    if (in.down & KEY_X) { reset(); return; }
    switch (kind) {
        case GAME_SNAKE: snake_update(&st.snake, in); break;
        case GAME_2048: g_update(&st.g, in); break;
        case GAME_BREAKOUT: br_update(&st.br, in); break;
        case GAME_FLAPPY: fl_update(&st.fl, in); break;
        case GAME_MINES: ms_update(&st.ms, in); break;
        default: iv_update(&st.iv, in); break;
    }
}

void arcade_touch(int x, int y) {
    switch (kind) {
        case GAME_SNAKE: snake_turn(&st.snake, pad_touch(x, y)); break;
        case GAME_2048: { int d = pad_touch(x, y); if (d >= 0) g_move(&st.g, d); break; }
        case GAME_MINES: ms_touch(&st.ms, x, y); break;
        default: break;   /* breakout, flappy and invaders read the touch from GameInput */
    }
}

void arcade_draw_top(void) {
    switch (kind) {
        case GAME_SNAKE: snake_draw(&st.snake); break;
        case GAME_2048: g_draw(&st.g); break;
        case GAME_BREAKOUT: br_draw(&st.br); break;
        case GAME_FLAPPY: fl_draw(&st.fl); break;
        case GAME_MINES: ms_draw_top(&st.ms); break;
        default: iv_draw(&st.iv); break;
    }
}

void arcade_draw_bottom(void) {
    switch (kind) {
        case GAME_SNAKE: draw_pad("Cruceta, stick o estos botones"); break;
        case GAME_2048: draw_pad("Desliza con la cruceta, el stick o estos botones"); break;
        case GAME_MINES: ms_draw_bottom(&st.ms); break;
        default: {
            ui_rect(0, 0, 320, 240, C_BG);
            const char *msg = kind == GAME_FLAPPY ? "Toca para aletear" :
                              kind == GAME_BREAKOUT ? "Desliza el stylus para mover la pala" : "Desliza para mover, mantene para disparar";
            ui_rounded(10, 40, 300, 150, 12, C_PANEL);
            ui_text_center(160, 100, 0.5f, C_WHITE, msg);
            ui_text_center(160, 130, 0.38f, COL_SUBTEXT, kind == GAME_FLAPPY ? "o usa A / cruceta arriba" : "o stick / cruceta + A");
            ui_text_center(160, 224, 0.34f, COL_SUBTEXT, "X: reiniciar   B: menu   START: pausa");
            break;
        }
    }
}
