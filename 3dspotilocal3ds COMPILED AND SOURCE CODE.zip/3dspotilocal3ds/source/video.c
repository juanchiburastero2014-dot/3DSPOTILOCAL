#include "video.h"
#include "avi.h"
#include "audio.h"
#include "stb_image.h"
#include "settings.h"

#define VID_CHUNK    4096
#define VID_NBUFFERS 4
#define MAX_TEXW     512
#define MAX_TEXH     256
#define VCHN         1

typedef struct __attribute__((packed)) {
    char magic[4];
    u16  width, height, fps, flags;
    u32  frameCount;
    u32  audioRate;
    u16  audioChannels;
    u16  reserved;
    u32  audioFrames;
    u32  videoSize;
    u32  audioSize;
} V3VHeader;

struct VideoPlayer {
    FILE *fV, *fA;
    AviFile *avi;               /* non-NULL when the source is an MJPEG .avi */
    unsigned char *jpeg;
    u32   fpsNum, fpsDen;
    u16   width, height, fps;
    u32   frameCount;
    u32   audioRate;
    u32   audioFrames;
    long  videoOffset, audioOffset;
    u32   frameBytes;
    int   texW, texH, orient;
    bool  test;

    C3D_Tex            tex;
    bool               textureReady;
    Tex3DS_SubTexture  sub;
    C2D_Image          img;
    u16               *stage;
    u16               *frameBuf;
    int                currentFrame;

    s16        *apcm[VID_NBUFFERS];
    ndspWaveBuf awbuf[VID_NBUFFERS];
    u32         audioReadPos;
    bool        audioEof;

    bool playing, paused, finished;
    u64  startMs, pausedMs, pauseStartMs;
};

/* ---- texture upload -------------------------------------------------------------------
 * The GPU wants 8x8 tiles in Morton order, rows counted from the bottom. Frames are converted
 * straight into that layout (no intermediate copy) with the requested orientation. */
static u8 mortonTable[64];
static bool mortonReady;

static void morton_init(void) {
    for (int y = 0; y < 8; y++)
        for (int x = 0; x < 8; x++)
            mortonTable[y * 8 + x] = (u8)((x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3));
    mortonReady = true;
}

static inline u16 pack565(const unsigned char *p) {
    return (u16)(((p[0] >> 3) << 11) | ((p[1] >> 2) << 5) | (p[2] >> 3));
}

static void blit(VideoPlayer *v, const unsigned char *rgb888, const u16 *rgb565) {
    if (!mortonReady) morton_init();
    const int w = v->width, h = v->height, tilesPerRow = v->texW >> 3;
    const bool flipV = (v->orient & 1) != 0, flipH = (v->orient & 2) != 0;
    for (int y = 0; y < h; y++) {
        const int sy = flipV ? h - 1 - y : y;
        const int m = v->texH - 1 - y;                         /* memory row, counted from the bottom */
        u16 *rowBase = v->stage + (size_t)(m >> 3) * tilesPerRow * 64;
        const u8 *mr = mortonTable + ((m & 7) << 3);
        if (rgb888) {
            const unsigned char *src = rgb888 + (size_t)sy * w * 3;
            for (int x = 0; x < w; x++) {
                const int sx = flipH ? w - 1 - x : x;
                rowBase[((x >> 3) << 6) + mr[x & 7]] = pack565(src + sx * 3);
            }
        } else {
            const u16 *src = rgb565 + (size_t)sy * w;
            for (int x = 0; x < w; x++)
                rowBase[((x >> 3) << 6) + mr[x & 7]] = src[flipH ? w - 1 - x : x];
        }
    }
    C3D_TexUpload(&v->tex, v->stage);
}

static bool upload_v3v(VideoPlayer *v, int frame) {
    fseek(v->fV, v->videoOffset + (long)frame * v->frameBytes, SEEK_SET);
    size_t got = fread(v->frameBuf, 1, v->frameBytes, v->fV);
    if (got < v->frameBytes) memset((unsigned char *)v->frameBuf + got, 0, v->frameBytes - got);
    blit(v, NULL, v->frameBuf);
    return true;
}

/* Decode one Motion JPEG frame. On a decode error the previous picture stays on screen. */
static bool upload_avi(VideoPlayer *v, int frame) {
    size_t n = 0;
    if (!avi_read_frame(v->avi, (uint32_t)frame, v->jpeg, avi_info(v->avi)->maxFrameBytes, &n))
        return false;
    int w = 0, h = 0, comp = 0;
    unsigned char *rgb = stbi_load_from_memory(v->jpeg, (int)n, &w, &h, &comp, 3);
    if (!rgb) return false;
    if (w != v->width || h != v->height) { stbi_image_free(rgb); return false; }
    blit(v, rgb, NULL);
    stbi_image_free(rgb);
    return true;
}

static void upload_frame(VideoPlayer *v, int frame) {
    if (frame < 0) frame = 0;
    if (frame >= (int)v->frameCount) frame = v->frameCount - 1;
    v->currentFrame = frame;   /* even on error, so we do not retry the same bad frame every tick */
    if (v->test) blit(v, NULL, v->frameBuf);
    else if (v->avi) upload_avi(v, frame);
    else upload_v3v(v, frame);
}

void video_set_orientation(VideoPlayer *v, int mode) {
    if (!v) return;
    v->orient = mode & 3;
    upload_frame(v, v->currentFrame < 0 ? 0 : v->currentFrame);   /* redraw the current picture */
}

int video_get_orientation(VideoPlayer *v) { return v ? v->orient : 0; }

static void audio_fill(VideoPlayer *v, int i) {
    size_t count = v->audioFrames - v->audioReadPos;
    if (count > VID_CHUNK) count = VID_CHUNK;
    size_t frames = 0;
    if (v->avi) {
        u32 got = 0;
        if (count && avi_read_audio(v->avi, v->apcm[i], (u32)count, &got)) frames = got;
    } else {
        if (count && v->fA) frames = fread(v->apcm[i], 2 * sizeof(s16), count, v->fA);
    }
    audio_apply_gain(v->apcm[i], frames);
    v->audioReadPos += (u32)frames;
    if (frames == 0) {
        v->audioEof = true;
        v->awbuf[i].status = NDSP_WBUF_FREE;
        v->awbuf[i].nsamples = 0;
        return;
    }
    v->awbuf[i].data_pcm16 = v->apcm[i];
    v->awbuf[i].nsamples = (u32)frames;
    v->awbuf[i].looping = false;
    v->awbuf[i].status = NDSP_WBUF_FREE;
    DSP_FlushDataCache(v->apcm[i], (u32)(frames * 2 * sizeof(s16)));
    ndspChnWaveBufAdd(VCHN, &v->awbuf[i]);
}

/* Allocate texture, staging buffers and audio buffers once width/height are known. */
static bool video_setup(VideoPlayer *v) {
    v->frameBytes = v->width * v->height * 2;
    v->texW = 8; while (v->texW < v->width && v->texW < MAX_TEXW) v->texW <<= 1;
    v->texH = 8; while (v->texH < v->height && v->texH < MAX_TEXH) v->texH <<= 1;
    v->orient = clampi(g_settings.videoOrient, 0, 3);
    v->stage = (u16 *)calloc((size_t)v->texW * v->texH, 2);
    v->frameBuf = (u16 *)malloc(v->frameBytes);
    if (!v->stage || !v->frameBuf) return false;

    if (!C3D_TexInit(&v->tex, v->texW, v->texH, GPU_RGB565)) return false;
    v->textureReady = true;
    C3D_TexSetFilter(&v->tex, GPU_LINEAR, GPU_LINEAR);
    C3D_TexSetWrap(&v->tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    v->sub.width  = v->width;
    v->sub.height = v->height;
    v->sub.left   = 0.0f;
    v->sub.top    = 1.0f;
    v->sub.right  = (float)v->width / (float)v->texW;
    v->sub.bottom = 1.0f - (float)v->height / (float)v->texH;
    v->img.tex = &v->tex;
    v->img.subtex = &v->sub;

    for (int i = 0; i < VID_NBUFFERS; i++) {
        v->apcm[i] = (s16 *)linearMemAlign(VID_CHUNK * 2 * sizeof(s16), 0x20);
        if (!v->apcm[i]) return false;
        memset(&v->awbuf[i], 0, sizeof(v->awbuf[i]));
    }
    v->currentFrame = -1;
    upload_frame(v, 0);
    return true;
}

static VideoPlayer *video_open_avi(const char *path) {
    AviFile *avi = avi_open(path);
    if (!avi) return NULL;
    const AviInfo *info = avi_info(avi);
    if (info->width > MAX_TEXW || info->height > MAX_TEXH || !info->frameCount) { avi_close(avi); return NULL; }

    VideoPlayer *v = (VideoPlayer *)calloc(1, sizeof(VideoPlayer));
    if (!v) { avi_close(avi); return NULL; }
    v->avi = avi;
    v->jpeg = (unsigned char *)malloc(info->maxFrameBytes);
    v->width = (u16)info->width; v->height = (u16)info->height;
    v->fpsNum = info->rate; v->fpsDen = info->scale;
    v->fps = (u16)((info->rate + info->scale / 2) / info->scale);
    v->frameCount = info->frameCount;
    v->audioRate = info->audioRate ? info->audioRate : 32000;   /* silent video: any valid rate */
    v->audioFrames = info->audioFrames;
    if (!v->jpeg || !video_setup(v)) { video_close(v); return NULL; }
    avi_seek_audio(avi, 0);
    return v;
}

VideoPlayer *video_open(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    V3VHeader h;
    size_t got = fread(&h, 1, sizeof(h), f);
    if (got >= 12 && memcmp(h.magic, "RIFF", 4) == 0) {   /* .avi (Motion JPEG) */
        fclose(f);
        return video_open_avi(path);
    }
    if (got != sizeof(h) || memcmp(h.magic, "V3V1", 4) != 0) {
        fclose(f); return NULL;
    }
    u64 expectedVideo = (u64)h.width * h.height * 2 * h.frameCount;
    u64 expectedAudio = (u64)h.audioFrames * 4;
    u64 expectedSize = sizeof(h) + expectedVideo + expectedAudio;
    if (h.width == 0 || h.height == 0 || h.width > MAX_TEXW || h.height > MAX_TEXH ||
        h.fps == 0 || h.fps > 30 || h.frameCount == 0 || h.audioChannels != 2 ||
        h.audioRate < 8000 || h.audioRate > 48000 || h.flags != 0 || h.reserved != 0 ||
        expectedVideo != h.videoSize || expectedAudio != h.audioSize ||
        expectedSize > 0x7FFFFFFF || fseek(f, 0, SEEK_END) != 0 ||
        ftell(f) != (long)expectedSize) {
        fclose(f); return NULL;
    }
    fclose(f);

    VideoPlayer *v = (VideoPlayer *)calloc(1, sizeof(VideoPlayer));
    if (!v) return NULL;
    v->fV = fopen(path, "rb");
    v->fA = fopen(path, "rb");
    if (!v->fV || !v->fA) { video_close(v); return NULL; }

    v->width = h.width; v->height = h.height; v->fps = h.fps;
    v->fpsNum = h.fps; v->fpsDen = 1;
    v->frameCount = h.frameCount;
    v->audioRate = h.audioRate;
    v->audioFrames = h.audioFrames;
    v->videoOffset = sizeof(V3VHeader);
    v->audioOffset = sizeof(V3VHeader) + h.videoSize;
    fseek(v->fA, v->audioOffset, SEEK_SET);

    if (!video_setup(v)) { video_close(v); return NULL; }
    return v;
}

VideoPlayer *video_open_test(void) {
    VideoPlayer *v = (VideoPlayer *)calloc(1, sizeof(VideoPlayer));
    if (!v) return NULL;
    v->test = true;
    v->width = 320; v->height = 180;
    v->fps = 1; v->fpsNum = 1; v->fpsDen = 1;
    v->frameCount = 3600;                       /* an hour of "video": it just stays on screen */
    v->audioRate = 32000;
    if (!video_setup(v)) { video_close(v); return NULL; }
    /* Dark background, a coloured square in each corner and a big "F" (it has no symmetry). */
    for (int y = 0; y < 180; y++)
        for (int x = 0; x < 320; x++) {
            u16 c = 0x2104;
            if (x < 40 && y < 40) c = 0xF800;                       /* top-left: red */
            else if (x >= 280 && y < 40) c = 0x07E0;                /* top-right: green */
            else if (x < 40 && y >= 140) c = 0x001F;                /* bottom-left: blue */
            else if (x >= 280 && y >= 140) c = 0xFFE0;              /* bottom-right: yellow */
            else if (x >= 130 && x < 160 && y >= 30 && y < 150) c = 0xFFFF;   /* stem of the F */
            else if (x >= 130 && x < 200 && y >= 30 && y < 55) c = 0xFFFF;    /* top arm */
            else if (x >= 130 && x < 185 && y >= 80 && y < 102) c = 0xFFFF;   /* middle arm */
            v->frameBuf[y * 320 + x] = c;
        }
    upload_frame(v, 0);
    return v;
}

void video_close(VideoPlayer *v) {
    if (!v) return;
    if (v->playing) {
        ndspChnWaveBufClear(VCHN);
        ndspChnReset(VCHN);
    }
    if (v->fV) fclose(v->fV);
    if (v->fA) fclose(v->fA);
    if (v->avi) avi_close(v->avi);
    free(v->jpeg);
    free(v->stage);
    free(v->frameBuf);
    if (v->textureReady) C3D_TexDelete(&v->tex);
    for (int i = 0; i < VID_NBUFFERS; i++)
        if (v->apcm[i]) linearFree(v->apcm[i]);
    free(v);
}

void video_play(VideoPlayer *v) {
    if (!v) return;
    if (v->test) {                       /* calibration picture: no audio at all */
        v->playing = true; v->paused = false; v->finished = false;
        v->startMs = osGetTime(); v->pausedMs = 0;
        return;
    }
    ndspChnReset(VCHN);
    ndspChnSetInterp(VCHN, NDSP_INTERP_LINEAR);
    ndspChnSetRate(VCHN, (float)v->audioRate);
    ndspChnSetFormat(VCHN, NDSP_FORMAT_STEREO_PCM16);
    float mix[12];
    memset(mix, 0, sizeof(mix));
    mix[0] = 1.0f; mix[1] = 1.0f;
    ndspChnSetMix(VCHN, mix);

    v->audioEof = false;
    v->audioReadPos = 0;
    if (v->avi) avi_seek_audio(v->avi, 0);
    else if (v->fA) fseek(v->fA, v->audioOffset, SEEK_SET);
    for (int i = 0; i < VID_NBUFFERS; i++) {
        v->awbuf[i].status = NDSP_WBUF_FREE;
        audio_fill(v, i);
    }
    ndspChnSetPaused(VCHN, false);

    v->playing = true;
    v->paused = false;
    v->finished = false;
    v->startMs = osGetTime();
    v->pausedMs = 0;
    upload_frame(v, 0);
}

void video_pause(VideoPlayer *v, bool pause) {
    if (!v || !v->playing) return;
    if (v->test) { v->paused = pause; return; }
    if (v->finished && !pause) video_seek(v, 0);
    if (pause && !v->paused) {
        v->paused = true;
        v->pauseStartMs = osGetTime();
        ndspChnSetPaused(VCHN, true);
    } else if (!pause && v->paused) {
        v->pausedMs += osGetTime() - v->pauseStartMs;
        v->paused = false;
        ndspChnSetPaused(VCHN, false);
    }
}

bool video_is_paused(VideoPlayer *v) { return v && v->paused; }

static u64 elapsed_ms(VideoPlayer *v) {
    u64 now = v->paused ? v->pauseStartMs : osGetTime();
    return now - v->startMs - v->pausedMs;
}

void video_update(VideoPlayer *v) {
    if (!v || !v->playing || v->finished || v->test) return;
    u64 ms = elapsed_ms(v);
    int frame = (int)(ms * v->fpsNum / ((u64)v->fpsDen * 1000));
    if (frame >= (int)v->frameCount) frame = v->frameCount - 1;
    if (frame != v->currentFrame)
        upload_frame(v, frame);

    for (int i = 0; i < VID_NBUFFERS; i++) {
        if (v->awbuf[i].status == NDSP_WBUF_DONE && !v->audioEof)
            audio_fill(v, i);
        else if (v->awbuf[i].status == NDSP_WBUF_DONE && v->audioEof)
            v->awbuf[i].status = NDSP_WBUF_FREE;
    }

    if (ms >= video_duration_ms(v) && v->audioEof) {
        bool drained = true;
        for (int i = 0; i < VID_NBUFFERS; i++)
            if (v->awbuf[i].status == NDSP_WBUF_QUEUED || v->awbuf[i].status == NDSP_WBUF_PLAYING)
                drained = false;
        if (drained) {
            v->finished = true;
            v->paused = true;
            v->pauseStartMs = osGetTime();
            ndspChnSetPaused(VCHN, true);
        }
    }
}

bool video_finished(VideoPlayer *v) { return v && v->finished; }
C2D_Image video_image(VideoPlayer *v) { return v->img; }

u64 video_position_ms(VideoPlayer *v) {
    if (!v) return 0;
    u64 ms = elapsed_ms(v);
    u64 dur = video_duration_ms(v);
    return ms > dur ? dur : ms;
}

u64 video_duration_ms(VideoPlayer *v) {
    if (!v || v->fpsNum == 0) return 0;
    return (u64)v->frameCount * 1000 * v->fpsDen / v->fpsNum;
}

bool video_seek(VideoPlayer *v, u64 ms) {
    if (!v || !v->playing || v->test) return false;
    u64 dur = video_duration_ms(v);
    if (ms > dur) ms = dur;
    int frame = (int)(ms * v->fpsNum / ((u64)v->fpsDen * 1000));
    upload_frame(v, frame);

    ndspChnWaveBufClear(VCHN);
    v->audioEof = false;
    v->audioReadPos = (u32)(ms * v->audioRate / 1000);
    if (v->audioReadPos > v->audioFrames) v->audioReadPos = v->audioFrames;
    ndspChnSetPaused(VCHN, true);
    if (v->avi) avi_seek_audio(v->avi, v->audioReadPos);
    else if (v->fA) fseek(v->fA, v->audioOffset + (long)v->audioReadPos * 4, SEEK_SET);
    for (int i = 0; i < VID_NBUFFERS; i++) {
        v->awbuf[i].status = NDSP_WBUF_FREE;
        v->awbuf[i].nsamples = 0;
    }
    for (int i = 0; i < VID_NBUFFERS; i++)
        audio_fill(v, i);

    v->startMs = osGetTime() - ms;
    v->pausedMs = 0;
    v->finished = false;
    if (v->paused) {
        v->pauseStartMs = osGetTime();
        ndspChnSetPaused(VCHN, true);
    } else {
        ndspChnSetPaused(VCHN, false);
    }
    return true;
}