#include "ui_screens.h"
#include "gfx_ui.h"
#include "image.h"
#include "settings.h"
#include "covers.h"
#include "i18n.h"
#include "library.h"

/* ---- layout constants ---- */
#define GX 10
#define GY 32
#define CW 100
#define CH 88
#define COLS 3
#define COVER 64
#define GRID_BOTTOM 208
#define TAB_Y 212

#define TY 32
#define RH 30
#define ALBUM_ROWS 6

#define VY 32
#define VRH 34
#define VIDEO_ROWS 5

#define PLAY_CX 160
#define PLAY_CY 120
#define PLAY_R  26
#define PREV_CX 70
#define NEXT_CX 250
#define PROG_X 12
#define PROG_W 296
#define PROG_Y 58

#define VPLAY_CY 110
#define VPROG_Y 44

static void fmt_time(u64 ms, char *out, size_t n) {
    u64 s = ms / 1000;
    snprintf(out, n, "%u:%02u", (unsigned)(s / 60), (unsigned)(s % 60));
}

static int dist2(int x, int y, int cx, int cy) {
    int dx = x - cx, dy = y - cy;
    return dx * dx + dy * dy;
}

static void draw_cover(C2D_Image img, float x, float y, float w, float h) {
    if (img.tex) {
        ui_image(img, x, y, w, h);
    } else {
        ui_rounded(x, y, w, h, 6, COL_SURFACE2);
        ui_circle(x + w / 2, y + h / 2, w * 0.18f, COL_GREEN);
    }
}

static void draw_progress(float x, float y, float w, u64 pos, u64 dur) {
    ui_rect(x, y + 3, w, 4, COL_BAR_BG);
    if (dur > 0) {
        float frac = (float)pos / (float)dur;
        if (frac > 1) frac = 1;
        float fw = w * frac;
        ui_rect(x, y + 3, fw, 4, COL_GREEN);
        ui_circle(x + fw, y + 5, 6, COL_GREEN);
    }
}

static void draw_tab_bar(int active) {
    static const char *names[4] = { "Musica", "Videos", "Juegos", "Ajustes" };
    ui_rect(0, TAB_Y, BOT_W, 28, COL_SURFACE);
    for (int i = 0; i < 4; i++)
        ui_text_center(40 + i * 80, TAB_Y + 7, 0.42f, i == active ? COL_GREEN : COL_SUBTEXT, names[i]);
    ui_rect(10 + active * 80, TAB_Y + 25, 60, 2, COL_GREEN);
}

static Screen tab_screen(int x) {
    int t = clampi(x / 80, 0, 3);
    return t == 0 ? SCREEN_LIBRARY : (t == 1 ? SCREEN_VIDEOS : (t == 2 ? SCREEN_GAMES : SCREEN_SETTINGS));
}

/* Greedy word wrap for help texts; returns the y after the last line. */
static float draw_wrapped(float x, float y, float scale, u32 color, float maxW, const char *text) {
    char line[160];
    size_t n = strlen(text), start = 0;
    while (start < n) {
        size_t end = n, lastSpace = 0;
        for (size_t i = start; i < n && i - start < sizeof(line) - 2; i++) {
            if (text[i] == ' ') lastSpace = i;
            memcpy(line, text + start, i + 1 - start);
            line[i + 1 - start] = '\0';
            if (ui_text_width(line, scale) > maxW) { end = lastSpace > start ? lastSpace : i; break; }
        }
        if (end - start > sizeof(line) - 2) end = start + sizeof(line) - 2;
        memcpy(line, text + start, end - start);
        line[end - start] = '\0';
        ui_text(x, y, scale, color, "%s", line);
        y += scale * 38.0f;
        start = end;
        while (start < n && text[start] == ' ') start++;
    }
    return y;
}

/* ---- track covers of the album being viewed (resolved once, when it is opened) ---- */
static char trackCoverPath[MAX_TRACKS_PER_ALBUM][MAX_PATH];
static const Track *playCoverFor;
static char playCoverPath[MAX_PATH];

static void refresh_track_covers(App *app) {
    Album *al = &app->lib->albums[app->albumViewIdx];
    for (int i = 0; i < al->trackCount; i++) {
        trackCoverPath[i][0] = '\0';
        covers_track_find(al, &al->tracks[i], trackCoverPath[i], MAX_PATH);
    }
    playCoverFor = NULL;
}

/* Cover for the song that is playing: its own picture, else the album's. */
static const char *playing_cover(App *app) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) return "";
    if (playCoverFor != t) {
        playCoverFor = t;
        if (!covers_track_find(al, t, playCoverPath, sizeof(playCoverPath)))
            snprintf(playCoverPath, sizeof(playCoverPath), "%s", al->coverPath);
    }
    return playCoverPath;
}

static void sync_lyrics(App *app) {
    Track *t = player_current(&app->player);
    if (t == app->lyricsFor) return;
    app->lyricsFor = t;
    app->lyricsOffset = 0;
    app->showLyrics = false;
    lyrics_free();
    if (t && lyrics_load(t->path)) app->showLyrics = g_settings.lyricsAuto;
}

/* ---- games: flat list of every track in the library, used to pick a song ---- */
static int song_count(App *app) {
    int n = 0;
    for (int i = 0; i < app->lib->albumCount; i++) n += app->lib->albums[i].trackCount;
    return n;
}

static bool song_at(App *app, int idx, int *album, int *track) {
    if (idx < 0) return false;
    for (int i = 0; i < app->lib->albumCount; i++) {
        int n = app->lib->albums[i].trackCount;
        if (idx < n) { *album = i; *track = idx; return true; }
        idx -= n;
    }
    return false;
}

static void start_game(App *app, GameKind kind, const char *song) {
    if (game_needs_song(kind) || !g_settings.gameMusic) player_stop(&app->player);   /* rhythm games own the audio engine */
    if (game_start(kind, song)) {
        app->gameKind = kind;
        app->screen = SCREEN_GAME;
    } else {
        snprintf(app->error, sizeof(app->error), "%s",
                 tr(game_needs_song(kind) ? "No se pudo abrir la cancion (o dura mas de 45 min)."
                                          : "No se pudo iniciar el juego."));
    }
}

static void pick_game(App *app, int idx) {
    if (idx < 0 || idx >= GAME_COUNT) return;
    app->gameCursor = idx;
    GameKind kind = (GameKind)idx;
    if (!game_needs_song(kind)) { start_game(app, kind, NULL); return; }
    if (song_count(app) == 0) {
        snprintf(app->error, sizeof(app->error), "%s", tr("Primero pone musica en /3dSpotiLocal/Music."));
        return;
    }
    app->gameKind = kind;
    app->songCursor = 0;
    app->songScroll = 0;
    app->screen = SCREEN_GAME_SONGS;
}

static void pick_song(App *app, int idx) {
    int al, tr;
    if (!song_at(app, idx, &al, &tr)) return;
    app->songCursor = idx;
    start_game(app, app->gameKind, app->lib->albums[al].tracks[tr].path);
}

/* ============================ TOP SCREEN ============================ */

static void top_library(App *app) {
    ui_text(20, 16, 0.8f, COL_GREEN, "3dSpotiLocal");
    ui_text(20, 56, 0.45f, COL_SUBTEXT, "Tu musica y tus videos, sin conexion");
    ui_text(20, 84, 0.5f, COL_TEXT, "%d albumes   %d videos",
            app->lib->albumCount, app->lib->videoCount);

    for (int i = 0; i < 18; i++) {
        int h = 8 + ((app->frames * 3 + i * 37) % 20);
        if (!app->player.active || audio_out_is_paused()) h = 8 + (i % 4) * 4;
        ui_rect(20 + i * 12, 230 - h, 8, h, COL_GREEN);
    }

    if (app->player.active) {
        Track *t = player_current(&app->player);
        Album *al = player_current_album(&app->player);
        if (t && al) {
            draw_cover(image_get(playing_cover(app)), 250, 120, 110, 110);
            ui_text(250, 100, 0.4f, COL_SUBTEXT, "NOW PLAYING");
            ui_text_clipped(20, 150, 0.45f, COL_TEXT, 220, t->title);
            ui_text_clipped(20, 174, 0.4f, COL_SUBTEXT, 220, al->artist);
        }
    } else {
        ui_text(20, 140, 0.4f, COL_SUBTEXT, "Elegi un album en la pantalla tactil");
        ui_text(20, 162, 0.36f, COL_SUBTEXT, "Y: cambiar pestana   SELECT: salir");
    }
}

static void top_album(App *app) {
    Album *al = &app->lib->albums[app->albumViewIdx];
    draw_cover(image_get(al->coverPath), 20, 20, 200, 200);
    ui_text_clipped(240, 40, 0.6f, COL_TEXT, 150, al->title);
    ui_text_clipped(240, 84, 0.5f, COL_SUBTEXT, 150, al->artist);
    ui_text(240, 116, 0.45f, COL_SUBTEXT, "%d tracks", al->trackCount);
    ui_text(240, 160, 0.4f, COL_GREEN, "Toca una cancion");
    ui_text(240, 190, 0.34f, COL_SUBTEXT, "X: caratula del album");
    ui_text(240, 208, 0.34f, COL_SUBTEXT, "Y: caratula de la cancion");
}

static void draw_lyrics(App *app, Track *t) {
    int cnt = lyrics_count();
    u64 pos = player_position_ms(&app->player), dur = player_duration_ms(&app->player);
    int cur = lyrics_current(pos, dur, app->lyricsOffset);
    ui_text_clipped(12, 4, 0.38f, COL_SUBTEXT, 376, t->title);
    for (int k = -4; k <= 4; k++) {
        int idx = cur + k;
        if (idx < 0 || idx >= cnt) continue;
        const LyricLine *l = lyrics_line(idx);
        u32 col = k == 0 ? COL_GREEN : (abs(k) == 1 ? COL_TEXT : COL_SUBTEXT);
        ui_text_center_raw(200, 24 + (k + 4) * 23, 0.5f, col, l->text);
    }
    if (!lyrics_timed()) ui_text_center(200, 226, 0.3f, COL_SUBTEXT, "Letra sin tiempos: cruceta arriba/abajo para ajustar");
}

static void top_playing(App *app) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) return;
    sync_lyrics(app);
    if (app->showLyrics && lyrics_count() > 0) { draw_lyrics(app, t); return; }
    draw_cover(image_get(playing_cover(app)), 20, 20, 200, 200);
    ui_text_clipped(240, 50, 0.55f, COL_TEXT, 150, t->title);
    ui_text_clipped(240, 92, 0.5f, COL_SUBTEXT, 150, al->artist);
    ui_text_clipped(240, 124, 0.45f, COL_SUBTEXT, 150, al->title);
    ui_text(240, 168, 0.4f, audio_out_is_paused() ? COL_SUBTEXT : COL_GREEN,
            audio_out_is_paused() ? "Pausa" : "Reproduciendo");
    if (lyrics_count() > 0) ui_text(240, 196, 0.36f, COL_GREEN, "X: ver la letra");
}

static void top_videos(App *app) {
    ui_text(20, 16, 0.7f, COL_GREEN, "Videos");
    ui_text(20, 58, 0.5f, COL_TEXT, "%d videos", app->lib->videoCount);
    ui_text(20, 94, 0.4f, COL_SUBTEXT, "Formatos: .avi (Motion JPEG) y .v3v");
    ui_text(20, 116, 0.4f, COL_SUBTEXT, "Converti mp4/mkv/etc con tools/convert_to_avi.py");
    ui_text(20, 138, 0.4f, COL_SUBTEXT, "SD: /3dSpotiLocal/Videos/");
    ui_text(20, 172, 0.36f, COL_SUBTEXT, "Y: cambiar pestana   A: reproducir   SELECT: salir");
}

static void top_video(App *app) {
    if (app->video) ui_image(video_image(app->video), 0, 0, TOP_W, TOP_H);
    if (app->videoTest) {
        ui_rect(0, 206, TOP_W, 34, COL_SURFACE2);
        ui_text_center(200, 211, 0.4f, COL_TEXT, "Si la F se ve al reves o en espejo, apreta X hasta verla bien.");
    }
}

static void top_games(App *app) {
    GameKind k = (GameKind)clampi(app->gameCursor, 0, GAME_COUNT - 1);
    ui_text(20, 16, 0.7f, COL_GREEN, "Minijuegos");
    ui_text_clipped(20, 66, 0.6f, COL_TEXT, 360, game_title(k));
    ui_text_clipped(20, 104, 0.42f, COL_SUBTEXT, 360, game_description(k));
    if (game_needs_song(k))
        ui_text(20, 146, 0.4f, COL_GREEN, "El nivel se genera con una cancion de tu biblioteca");
    else
        ui_text(20, 146, 0.4f, COL_SUBTEXT, "Si hay musica sonando, sigue de fondo");
    if (settings_best((int)k) > 0) ui_text(20, 172, 0.42f, C2D_Color32(250, 204, 70, 255), "Tu record: %d", settings_best((int)k));
    ui_text(20, 200, 0.36f, COL_SUBTEXT, "Y: cambiar pestana   A: jugar   SELECT: salir");
}

static void top_game_songs(App *app) {
    ui_text(20, 16, 0.7f, COL_GREEN, "%s", game_title(app->gameKind));
    ui_text(20, 70, 0.55f, COL_TEXT, "Elegi una cancion");
    ui_text(20, 108, 0.4f, COL_SUBTEXT, "El nivel sale de analizar el audio:");
    ui_text(20, 128, 0.4f, COL_SUBTEXT, "cada pulso fuerte se convierte en una nota");
    ui_text(20, 200, 0.36f, COL_SUBTEXT, "A: jugar   B: volver   L/R: saltar 5");
}

static void top_settings(App *app) {
    int i = clampi(app->settingCursor, 0, setting_count() - 1);
    char val[40];
    setting_value(i, val, sizeof(val));
    ui_text(20, 16, 0.7f, COL_GREEN, "Ajustes");
    ui_text_clipped(20, 66, 0.6f, COL_TEXT, 360, setting_name(i));
    if (setting_action(i) == ACT_NONE) ui_text(20, 100, 0.55f, COL_GREEN, "%s", val);
    draw_wrapped(20, 134, 0.42f, COL_SUBTEXT, 360, setting_help(i));
    ui_text(20, 206, 0.36f, COL_SUBTEXT, "Cruceta: elegir y cambiar   A: cambiar   Y: pestana");
}

static void top_cover_pick(App *app) {
    Album *al = &app->lib->albums[app->coverAlbum];
    const char *target = al->title;
    if (app->coverForTrack && app->coverTrack >= 0 && app->coverTrack < al->trackCount) target = al->tracks[app->coverTrack].title;
    char path[MAX_PATH] = "";
    if (app->coverCursor > 0) covers_image_path(app->coverCursor - 1, path, sizeof(path));
    else if (app->coverForTrack) snprintf(path, sizeof(path), "%s", al->coverPath);
    else library_default_cover(al->folder, path, sizeof(path));
    draw_cover(image_get(path), 20, 20, 200, 200);
    ui_text(236, 20, 0.5f, COL_GREEN, app->coverForTrack ? "Caratula de la cancion" : "Caratula del album");
    ui_text_clipped(236, 52, 0.45f, COL_TEXT, 156, target);
    if (covers_image_count() == 0) {
        draw_wrapped(236, 96, 0.36f, COL_SUBTEXT, 156, "No hay imagenes. Copia .jpg, .png o .bmp a /3dSpotiLocal/Covers/ y volve a abrir esta pantalla.");
    } else {
        ui_text(236, 100, 0.36f, COL_SUBTEXT, "%d imagenes disponibles", covers_image_count());
        draw_wrapped(236, 124, 0.34f, COL_SUBTEXT, 156, "Tambien funciona poner cover.jpg en la carpeta del album, o cancion.jpg junto a cada cancion.");
    }
    ui_text(236, 206, 0.34f, COL_SUBTEXT, "A: elegir   B: cancelar");
}

void screens_draw_top(App *app) {
    ui_scene_top();
    switch (app->screen) {
        case SCREEN_LIBRARY: top_library(app); break;
        case SCREEN_ALBUM:   top_album(app); break;
        case SCREEN_PLAYING: top_playing(app); break;
        case SCREEN_VIDEOS:  top_videos(app); break;
        case SCREEN_VIDEO:   top_video(app); break;
        case SCREEN_GAMES:   top_games(app); break;
        case SCREEN_GAME_SONGS: top_game_songs(app); break;
        case SCREEN_GAME:    game_draw_top(); break;
        case SCREEN_SETTINGS: top_settings(app); break;
        case SCREEN_COVER_PICK: top_cover_pick(app); break;
    }
    if (app->error[0]) {
        ui_rect(0, 212, TOP_W, 28, COL_SURFACE2);
        ui_text_clipped(8, 219, 0.4f, COL_TEXT, TOP_W - 16, app->error);
    }
}

/* =========================== BOTTOM SCREEN =========================== */

static void bottom_library(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(12, 8, 0.5f, COL_TEXT, "Tu biblioteca");
    if (app->player.active)
        ui_text_right(310, 9, 0.36f, COL_GREEN, "Reproduciendo >");

    int rows = (app->lib->albumCount + COLS - 1) / COLS;
    int maxScroll = rows > 2 ? rows - 2 : 0;
    app->libScroll = clampi(app->libScroll, 0, maxScroll);

    for (int r = 0; r < 2; r++) {
        for (int c = 0; c < COLS; c++) {
            int idx = (app->libScroll + r) * COLS + c;
            if (idx >= app->lib->albumCount) continue;
            float x = GX + c * CW, y = GY + r * CH;
            Album *al = &app->lib->albums[idx];
            if (idx == app->libCursor)
                ui_rounded(x + 14, y - 2, COVER + 8, COVER + 8, 6, COL_GREEN);
            draw_cover(image_get(al->coverPath), x + 18, y + 2, COVER, COVER);
            ui_text_clipped(x + 4, y + 70, 0.4f, COL_TEXT, 92, al->title);
        }
    }
    if (app->lib->albumCount == 0) {
        ui_text_center(160, 100, 0.45f, COL_TEXT, "Todavia no hay albumes");
        ui_text_center(160, 126, 0.36f, COL_SUBTEXT, "SD: /3dSpotiLocal/Music/");
    }
    draw_tab_bar(0);
}

static void bottom_album(App *app) {
    Album *al = &app->lib->albums[app->albumViewIdx];
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(8, 8, 0.5f, COL_GREEN, "<");
    ui_text_clipped(28, 8, 0.5f, COL_TEXT, 280, al->title);

    int maxScroll = al->trackCount > ALBUM_ROWS ? al->trackCount - ALBUM_ROWS : 0;
    app->albumScroll = clampi(app->albumScroll, 0, maxScroll);

    for (int i = 0; i < ALBUM_ROWS; i++) {
        int idx = app->albumScroll + i;
        if (idx >= al->trackCount) break;
        float y = TY + i * RH;
        bool cur = app->player.active && app->player.album == app->albumViewIdx && app->player.track == idx;
        if (idx == app->albumCursor) ui_rect(0, y, BOT_W, RH, COL_SURFACE2);
        ui_text(12, y + 8, 0.45f, cur ? COL_GREEN : COL_SUBTEXT, "%d", idx + 1);
        bool hasCover = trackCoverPath[idx][0] != '\0';
        if (hasCover) draw_cover(image_get(trackCoverPath[idx]), 38, y + 3, 24, 24);
        ui_text_clipped(hasCover ? 68 : 40, y + 8, 0.45f, cur ? COL_GREEN : COL_TEXT, hasCover ? 240 : 268, al->tracks[idx].title);
    }
    ui_rect(0, 212, BOT_W, 28, COL_SURFACE);
    ui_text_center(80, 220, 0.4f, COL_GREEN, "X: caratula album");
    ui_text_center(240, 220, 0.4f, COL_GREEN, "Y: caratula cancion");
}

static void bottom_playing(App *app) {
    Track *t = player_current(&app->player);
    Album *al = player_current_album(&app->player);
    if (!t || !al) { app->screen = SCREEN_LIBRARY; return; }

    ui_text_clipped(12, 8, 0.5f, COL_TEXT, 296, t->title);
    ui_text_clipped(12, 30, 0.4f, COL_SUBTEXT, 296, al->artist);

    u64 pos = player_position_ms(&app->player);
    u64 dur = player_duration_ms(&app->player);
    draw_progress(PROG_X, PROG_Y, PROG_W, pos, dur);
    char tb[16];
    fmt_time(pos, tb, sizeof(tb));
    ui_text(12, 74, 0.35f, COL_SUBTEXT, "%s", tb);
    fmt_time(dur, tb, sizeof(tb));
    ui_text_right(308, 74, 0.35f, COL_SUBTEXT, tb);

    ui_icon_prev(PREV_CX, PLAY_CY, 12, COL_TEXT);
    ui_circle(PLAY_CX, PLAY_CY, PLAY_R, COL_GREEN);
    if (audio_out_is_paused()) ui_icon_play(PLAY_CX, PLAY_CY, 12, COL_BLACK);
    else ui_icon_pause(PLAY_CX, PLAY_CY, 12, COL_BLACK);
    ui_icon_next(NEXT_CX, PLAY_CY, 12, COL_TEXT);

    ui_text_center(40, 176, 0.4f, app->player.shuffle ? COL_GREEN : COL_SUBTEXT, "SHUFFLE");
    const char *rep = app->player.repeat == REPEAT_ONE ? "REPEAT 1" :
                      app->player.repeat == REPEAT_ALL ? "REPEAT" : "REPEAT";
    ui_text_center(280, 176, 0.4f, app->player.repeat != REPEAT_OFF ? COL_GREEN : COL_SUBTEXT, rep);

    ui_text(12, 214, 0.45f, COL_GREEN, "< Biblioteca");
    if (lyrics_count() > 0)
        ui_text_right(308, 214, 0.45f, app->showLyrics ? COL_GREEN : COL_SUBTEXT, "Letra");
}

static void bottom_videos(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(12, 8, 0.5f, COL_TEXT, "Videos");

    int maxScroll = app->lib->videoCount > VIDEO_ROWS ? app->lib->videoCount - VIDEO_ROWS : 0;
    app->videoScroll = clampi(app->videoScroll, 0, maxScroll);

    for (int i = 0; i < VIDEO_ROWS; i++) {
        int idx = app->videoScroll + i;
        if (idx >= app->lib->videoCount) break;
        float y = VY + i * VRH;
        if (idx == app->videoCursor) ui_rect(0, y, BOT_W, VRH, COL_SURFACE2);
        ui_text_clipped(12, y + 9, 0.45f, COL_TEXT, 296, app->lib->videos[idx].title);
    }
    if (app->lib->videoCount == 0)
        ui_text_center(160, 110, 0.42f, COL_SUBTEXT, "No hay videos .avi ni .v3v");
    draw_tab_bar(1);
}

static void bottom_video(App *app) {
    if (!app->video) { app->screen = SCREEN_VIDEOS; return; }
    const char *title = app->videoTest ? tr("Prueba de orientacion")
                                       : app->lib->videos[clampi(app->videoIndex, 0, app->lib->videoCount - 1)].title;
    ui_text_clipped(12, 8, 0.5f, COL_TEXT, 296, title);

    u64 pos = video_position_ms(app->video);
    u64 dur = video_duration_ms(app->video);
    draw_progress(PROG_X, VPROG_Y, PROG_W, pos, dur);
    char tb[16];
    fmt_time(pos, tb, sizeof(tb));
    ui_text(12, 60, 0.35f, COL_SUBTEXT, "%s", tb);
    fmt_time(dur, tb, sizeof(tb));
    ui_text_right(308, 60, 0.35f, COL_SUBTEXT, tb);

    ui_circle(PLAY_CX, VPLAY_CY, PLAY_R, COL_GREEN);
    if (video_is_paused(app->video) || video_finished(app->video)) ui_icon_play(PLAY_CX, VPLAY_CY, 12, COL_BLACK);
    else ui_icon_pause(PLAY_CX, VPLAY_CY, 12, COL_BLACK);

    {
        static const char *modes[4] = { "Normal", "Volteado vertical", "Espejo horizontal", "Girado 180 grados" };
        ui_text(12, 160, 0.4f, COL_SUBTEXT, "Orientacion: %s", tr(modes[video_get_orientation(app->video) & 3]));
    }
    ui_text(12, 214, 0.45f, COL_GREEN, "< Videos");
    ui_text_right(308, 214, 0.4f, COL_GREEN, "X: girar imagen");
}

static void bottom_games(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(12, 8, 0.5f, COL_TEXT, "Minijuegos");

    int maxScroll = GAME_COUNT > VIDEO_ROWS ? GAME_COUNT - VIDEO_ROWS : 0;
    app->gameScroll = clampi(app->gameScroll, 0, maxScroll);
    for (int i = 0; i < VIDEO_ROWS; i++) {
        int idx = app->gameScroll + i;
        if (idx >= GAME_COUNT) break;
        float y = VY + i * VRH;
        if (idx == app->gameCursor) ui_rect(0, y, BOT_W, VRH, COL_SURFACE2);
        ui_text_clipped(12, y + 3, 0.45f, COL_TEXT, 296, game_title((GameKind)idx));
        ui_text_clipped(12, y + 19, 0.32f, game_needs_song((GameKind)idx) ? COL_GREEN : COL_SUBTEXT, 296,
                        game_needs_song((GameKind)idx) ? "Con una cancion tuya" : game_description((GameKind)idx));
    }
    draw_tab_bar(2);
}

static void bottom_game_songs(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(8, 8, 0.5f, COL_GREEN, "<");
    ui_text(28, 8, 0.5f, COL_TEXT, "Elegi una cancion");

    int total = song_count(app);
    int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
    app->songScroll = clampi(app->songScroll, 0, maxScroll);
    for (int i = 0; i < VIDEO_ROWS; i++) {
        int idx = app->songScroll + i, al, tr;
        if (!song_at(app, idx, &al, &tr)) break;
        float y = VY + i * VRH;
        if (idx == app->songCursor) ui_rect(0, y, BOT_W, VRH, COL_SURFACE2);
        ui_text_clipped(12, y + 3, 0.45f, COL_TEXT, 296, app->lib->albums[al].tracks[tr].title);
        ui_text_clipped(12, y + 19, 0.32f, COL_SUBTEXT, 296, app->lib->albums[al].title);
    }
}

static void bottom_settings(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(12, 8, 0.5f, COL_TEXT, "Ajustes");
    int total = setting_count();
    int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
    app->settingScroll = clampi(app->settingScroll, 0, maxScroll);
    for (int i = 0; i < VIDEO_ROWS; i++) {
        int idx = app->settingScroll + i;
        if (idx >= total) break;
        float y = VY + i * VRH;
        char val[40];
        setting_value(idx, val, sizeof(val));
        if (idx == app->settingCursor) ui_rect(0, y, BOT_W, VRH, COL_SURFACE2);
        ui_text_clipped(12, y + 9, 0.45f, COL_TEXT, 190, setting_name(idx));
        if (setting_action(idx) == ACT_NONE) ui_text_right(308, y + 9, 0.45f, COL_GREEN, val);
        else ui_text_right(308, y + 9, 0.4f, COL_SUBTEXT, ">");
    }
    draw_tab_bar(3);
}

static void bottom_cover_pick(App *app) {
    ui_rect(0, 0, BOT_W, 28, COL_SURFACE);
    ui_text(8, 8, 0.5f, COL_GREEN, "<");
    ui_text(28, 8, 0.5f, COL_TEXT, "Elegir caratula");
    int total = covers_image_count() + 1;
    int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
    app->coverScroll = clampi(app->coverScroll, 0, maxScroll);
    for (int i = 0; i < VIDEO_ROWS; i++) {
        int idx = app->coverScroll + i;
        if (idx >= total) break;
        float y = VY + i * VRH;
        if (idx == app->coverCursor) ui_rect(0, y, BOT_W, VRH, COL_SURFACE2);
        if (idx == 0) ui_text_clipped(12, y + 9, 0.45f, COL_GREEN, 296, tr("Automatica (quitar la elegida)"));
        else ui_text_clipped(12, y + 9, 0.45f, COL_TEXT, 296, covers_image_name(idx - 1));
    }
}

void screens_draw_bottom(App *app) {
    ui_scene_bottom();
    switch (app->screen) {
        case SCREEN_LIBRARY: bottom_library(app); break;
        case SCREEN_ALBUM:   bottom_album(app); break;
        case SCREEN_PLAYING: bottom_playing(app); break;
        case SCREEN_VIDEOS:  bottom_videos(app); break;
        case SCREEN_VIDEO:   bottom_video(app); break;
        case SCREEN_GAMES:   bottom_games(app); break;
        case SCREEN_GAME_SONGS: bottom_game_songs(app); break;
        case SCREEN_GAME:    game_draw_bottom(); break;
        case SCREEN_SETTINGS: bottom_settings(app); break;
        case SCREEN_COVER_PICK: bottom_cover_pick(app); break;
    }
}

/* ============================== INPUT ============================== */

static void open_album(App *app, int idx) {
    app->albumViewIdx = idx;
    app->albumCursor = 0;
    app->albumScroll = 0;
    refresh_track_covers(app);
    app->screen = SCREEN_ALBUM;
}

static void start_cover_pick(App *app, bool forTrack) {
    Album *al = &app->lib->albums[app->albumViewIdx];
    if (forTrack && al->trackCount == 0) return;
    covers_refresh_list();
    app->coverForTrack = forTrack;
    app->coverAlbum = app->albumViewIdx;
    app->coverTrack = clampi(app->albumCursor, 0, al->trackCount - 1);
    app->coverCursor = 0;
    app->coverScroll = 0;
    app->screen = SCREEN_COVER_PICK;
}

static void pick_cover(App *app, int idx) {
    Album *al = &app->lib->albums[app->coverAlbum];
    const char *name = idx > 0 ? covers_image_name(idx - 1) : NULL;
    if (app->coverForTrack) {
        covers_track_set(al, &al->tracks[app->coverTrack], name);
    } else {
        covers_album_set(al, name);
        char path[MAX_PATH];
        if (covers_album_chosen(al, path, sizeof(path))) snprintf(al->coverPath, MAX_PATH, "%s", path);
        else library_default_cover(al->folder, al->coverPath, MAX_PATH);
    }
    app->albumViewIdx = app->coverAlbum;
    refresh_track_covers(app);
    snprintf(app->error, sizeof(app->error), "%s", tr(name ? "Caratula guardada." : "Caratula automatica restaurada."));
    app->screen = SCREEN_ALBUM;
}

static void reload_library(App *app) {
    player_stop(&app->player);
    app_close_video(app);
    image_clear_all();
    lyrics_free();
    app->lyricsFor = NULL;
    playCoverFor = NULL;
    covers_init();
    library_scan(app->lib);
    app->libCursor = app->libScroll = 0;
    app->albumViewIdx = app->albumCursor = app->albumScroll = 0;
    app->videoCursor = app->videoScroll = 0;
    snprintf(app->error, sizeof(app->error), tr("Biblioteca: %d albumes, %d videos."), app->lib->albumCount, app->lib->videoCount);
}

static void cycle_video_orientation(App *app) {
    if (!app->video) return;
    int mode = (video_get_orientation(app->video) + 1) & 3;
    video_set_orientation(app->video, mode);
    g_settings.videoOrient = mode;
    settings_save();
}

static void leave_video(App *app) {
    Screen back = app->videoTest ? SCREEN_SETTINGS : SCREEN_VIDEOS;
    app_close_video(app);
    app->screen = back;
}

static void run_setting(App *app, int idx, int dir) {
    SettingAction act = setting_action(idx);
    if (act == ACT_VIDEOTEST) app_open_video_test(app);
    else if (act == ACT_RELOAD) reload_library(app);
    else if (act == ACT_RESET) { settings_reset(); snprintf(app->error, sizeof(app->error), "%s", tr("Ajustes restaurados.")); }
    else setting_change(idx, dir);
}

void screens_touch(App *app, int x, int y) {
    switch (app->screen) {
        case SCREEN_LIBRARY: {
            if (y < 28 && x >= 180 && app->player.active) {
                app->screen = SCREEN_PLAYING;
                return;
            }
            if (y >= TAB_Y) { app->screen = tab_screen(x); return; }
            if (y >= GY && y < GRID_BOTTOM && x >= GX && x < GX + COLS * CW) {
                int c = (x - GX) / CW, r = (y - GY) / CH;
                int idx = (app->libScroll + r) * COLS + c;
                if (c < COLS && r < 2 && idx < app->lib->albumCount) {
                    app->libCursor = idx;
                    open_album(app, idx);
                }
            }
            break;
        }
        case SCREEN_ALBUM: {
            if (y >= 212) { start_cover_pick(app, x >= 160); return; }
            if (y < 28) { if (x < 28) app->screen = SCREEN_LIBRARY; return; }
            if (y >= TY && y < TY + ALBUM_ROWS * RH) {
                int idx = app->albumScroll + (y - TY) / RH;
                Album *al = &app->lib->albums[app->albumViewIdx];
                if (idx < al->trackCount) {
                    app->albumCursor = idx;
                    if (player_play_track(&app->player, app->albumViewIdx, idx))
                        app->screen = SCREEN_PLAYING;
                    else
                        snprintf(app->error, sizeof(app->error), "No se pudo abrir el audio.");
                }
            }
            break;
        }
        case SCREEN_PLAYING: {
            if (y >= 208 && x < 140) { app->screen = SCREEN_LIBRARY; return; }
            if (y >= 208 && x >= 220 && lyrics_count() > 0) { app->showLyrics = !app->showLyrics; return; }
            if (x >= PROG_X && x <= PROG_X + PROG_W && y >= PROG_Y - 8 && y <= PROG_Y + 22) {
                u64 dur = player_duration_ms(&app->player);
                player_seek_ms(&app->player, (u64)(x - PROG_X) * dur / PROG_W);
                return;
            }
            if (dist2(x, y, PLAY_CX, PLAY_CY) < (PLAY_R + 4) * (PLAY_R + 4)) { player_toggle_pause(&app->player); return; }
            if (dist2(x, y, PREV_CX, PLAY_CY) < 24 * 24) { player_prev(&app->player); return; }
            if (dist2(x, y, NEXT_CX, PLAY_CY) < 24 * 24) { player_next(&app->player); return; }
            if (y >= 168 && y <= 196) {
                if (x < 120) app->player.shuffle = !app->player.shuffle;
                else if (x > 200) app->player.repeat = (app->player.repeat + 1) % 3;
            }
            break;
        }
        case SCREEN_VIDEOS: {
            if (y >= TAB_Y) { app->screen = tab_screen(x); return; }
            if (y >= VY && y < VY + VIDEO_ROWS * VRH) {
                int idx = app->videoScroll + (y - VY) / VRH;
                if (idx < app->lib->videoCount) {
                    app->videoCursor = idx;
                    app_open_video(app, idx);
                }
            }
            break;
        }
        case SCREEN_VIDEO: {
            if (y >= 208 && x < 140) { leave_video(app); return; }
            if (y >= 208 && x >= 170) { cycle_video_orientation(app); return; }
            if (x >= PROG_X && x <= PROG_X + PROG_W && y >= VPROG_Y - 8 && y <= VPROG_Y + 22) {
                u64 dur = video_duration_ms(app->video);
                video_seek(app->video, (u64)(x - PROG_X) * dur / PROG_W);
                return;
            }
            if (dist2(x, y, PLAY_CX, VPLAY_CY) < (PLAY_R + 4) * (PLAY_R + 4))
                video_pause(app->video, !video_is_paused(app->video));
            break;
        }
        case SCREEN_GAMES: {
            if (y >= TAB_Y) { app->screen = tab_screen(x); return; }
            if (y >= VY && y < VY + VIDEO_ROWS * VRH) {
                int idx = app->gameScroll + (y - VY) / VRH;
                if (idx < GAME_COUNT) pick_game(app, idx);
            }
            break;
        }
        case SCREEN_GAME_SONGS: {
            if (y < 28) { if (x < 28) app->screen = SCREEN_GAMES; return; }
            if (y >= VY && y < VY + VIDEO_ROWS * VRH)
                pick_song(app, app->songScroll + (y - VY) / VRH);
            break;
        }
        case SCREEN_GAME: break;   /* touches go straight to game_touch() from main() */
        case SCREEN_SETTINGS: {
            if (y >= TAB_Y) { app->screen = tab_screen(x); return; }
            if (y >= VY && y < VY + VIDEO_ROWS * VRH) {
                int idx = app->settingScroll + (y - VY) / VRH;
                if (idx < setting_count()) { app->settingCursor = idx; run_setting(app, idx, +1); }
            }
            break;
        }
        case SCREEN_COVER_PICK: {
            if (y < 28) { if (x < 28) app->screen = SCREEN_ALBUM; return; }
            if (y >= VY && y < VY + VIDEO_ROWS * VRH) {
                int idx = app->coverScroll + (y - VY) / VRH;
                if (idx < covers_image_count() + 1) pick_cover(app, idx);
            }
            break;
        }
    }
}

void screens_scroll(App *app, int dir) {
    switch (app->screen) {
        case SCREEN_LIBRARY: {
            int rows = (app->lib->albumCount + COLS - 1) / COLS;
            int maxScroll = rows > 2 ? rows - 2 : 0;
            app->libScroll = clampi(app->libScroll + dir, 0, maxScroll);
            app->libCursor = clampi(app->libCursor, app->libScroll * COLS,
                                    app->libScroll * COLS + COLS * 2 - 1);
            app->libCursor = clampi(app->libCursor, 0, app->lib->albumCount - 1);
            break;
        }
        case SCREEN_ALBUM: {
            Album *al = &app->lib->albums[app->albumViewIdx];
            int maxScroll = al->trackCount > ALBUM_ROWS ? al->trackCount - ALBUM_ROWS : 0;
            app->albumScroll = clampi(app->albumScroll + dir, 0, maxScroll);
            app->albumCursor = clampi(app->albumCursor, app->albumScroll, app->albumScroll + ALBUM_ROWS - 1);
            break;
        }
        case SCREEN_VIDEOS: {
            int maxScroll = app->lib->videoCount > VIDEO_ROWS ? app->lib->videoCount - VIDEO_ROWS : 0;
            app->videoScroll = clampi(app->videoScroll + dir, 0, maxScroll);
            app->videoCursor = clampi(app->videoCursor, app->videoScroll, app->videoScroll + VIDEO_ROWS - 1);
            break;
        }
        case SCREEN_GAMES: {
            int maxScroll = GAME_COUNT > VIDEO_ROWS ? GAME_COUNT - VIDEO_ROWS : 0;
            app->gameScroll = clampi(app->gameScroll + dir, 0, maxScroll);
            app->gameCursor = clampi(app->gameCursor, app->gameScroll, app->gameScroll + VIDEO_ROWS - 1);
            break;
        }
        case SCREEN_GAME_SONGS: {
            int total = song_count(app);
            int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
            app->songScroll = clampi(app->songScroll + dir, 0, maxScroll);
            app->songCursor = clampi(app->songCursor, app->songScroll, app->songScroll + VIDEO_ROWS - 1);
            break;
        }
        case SCREEN_SETTINGS: {
            int total = setting_count();
            int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
            app->settingScroll = clampi(app->settingScroll + dir, 0, maxScroll);
            app->settingCursor = clampi(app->settingCursor, app->settingScroll, app->settingScroll + VIDEO_ROWS - 1);
            break;
        }
        case SCREEN_COVER_PICK: {
            int total = covers_image_count() + 1;
            int maxScroll = total > VIDEO_ROWS ? total - VIDEO_ROWS : 0;
            app->coverScroll = clampi(app->coverScroll + dir, 0, maxScroll);
            app->coverCursor = clampi(app->coverCursor, app->coverScroll, app->coverScroll + VIDEO_ROWS - 1);
            break;
        }
        default: break;
    }
}

static void cursor_visibility(App *app) {
    if (app->screen == SCREEN_LIBRARY) {
        int row = app->libCursor / COLS;
        if (row < app->libScroll) app->libScroll = row;
        if (row >= app->libScroll + 2) app->libScroll = row - 1;
    } else if (app->screen == SCREEN_ALBUM) {
        if (app->albumCursor < app->albumScroll) app->albumScroll = app->albumCursor;
        if (app->albumCursor >= app->albumScroll + ALBUM_ROWS) app->albumScroll = app->albumCursor - ALBUM_ROWS + 1;
    } else if (app->screen == SCREEN_VIDEOS) {
        if (app->videoCursor < app->videoScroll) app->videoScroll = app->videoCursor;
        if (app->videoCursor >= app->videoScroll + VIDEO_ROWS) app->videoScroll = app->videoCursor - VIDEO_ROWS + 1;
    } else if (app->screen == SCREEN_GAMES) {
        if (app->gameCursor < app->gameScroll) app->gameScroll = app->gameCursor;
        if (app->gameCursor >= app->gameScroll + VIDEO_ROWS) app->gameScroll = app->gameCursor - VIDEO_ROWS + 1;
    } else if (app->screen == SCREEN_GAME_SONGS) {
        if (app->songCursor < app->songScroll) app->songScroll = app->songCursor;
        if (app->songCursor >= app->songScroll + VIDEO_ROWS) app->songScroll = app->songCursor - VIDEO_ROWS + 1;
    } else if (app->screen == SCREEN_SETTINGS) {
        if (app->settingCursor < app->settingScroll) app->settingScroll = app->settingCursor;
        if (app->settingCursor >= app->settingScroll + VIDEO_ROWS) app->settingScroll = app->settingCursor - VIDEO_ROWS + 1;
    } else if (app->screen == SCREEN_COVER_PICK) {
        if (app->coverCursor < app->coverScroll) app->coverScroll = app->coverCursor;
        if (app->coverCursor >= app->coverScroll + VIDEO_ROWS) app->coverScroll = app->coverCursor - VIDEO_ROWS + 1;
    }
}

void screens_key(App *app, u32 down) {
    if (app->screen == SCREEN_GAME) {      /* in-game: B leaves, everything else belongs to the game */
        if (down & KEY_B) screens_back(app);
        return;
    }
    if (down & KEY_SELECT) { app->running = false; return; }
    if (down) app->error[0] = '\0';
    bool seekable = app->screen == SCREEN_PLAYING || app->screen == SCREEN_VIDEO;
    if (!seekable && (down & KEY_START) && app->player.active) {
        app->screen = SCREEN_PLAYING;
        return;
    }
    if ((down & KEY_Y) && (app->screen == SCREEN_LIBRARY || app->screen == SCREEN_VIDEOS ||
                           app->screen == SCREEN_GAMES || app->screen == SCREEN_SETTINGS)) {
        app->screen = app->screen == SCREEN_LIBRARY ? SCREEN_VIDEOS :
                      app->screen == SCREEN_VIDEOS  ? SCREEN_GAMES :
                      app->screen == SCREEN_GAMES   ? SCREEN_SETTINGS : SCREEN_LIBRARY;
        return;
    }
    if (down & KEY_B) { screens_back(app); return; }
    if ((down & KEY_START) && seekable) {
        if (app->screen == SCREEN_PLAYING) player_toggle_pause(&app->player);
        else video_pause(app->video, !video_is_paused(app->video));
        return;
    }
    if (seekable && (down & (KEY_L | KEY_R))) {
        int delta = (down & KEY_R) ? 5000 : -5000;
        if (app->screen == SCREEN_PLAYING) {
            u64 p = player_position_ms(&app->player);
            player_seek_ms(&app->player, (u64)clampi((int)p + delta, 0, (int)player_duration_ms(&app->player)));
        } else {
            u64 p = video_position_ms(app->video);
            video_seek(app->video, (u64)clampi((int)p + delta, 0, (int)video_duration_ms(app->video)));
        }
        return;
    }

    switch (app->screen) {
        case SCREEN_LIBRARY: {
            int n = app->lib->albumCount;
            if (!n) { app->libCursor = 0; app->libScroll = 0; break; }
            if (down & KEY_RIGHT) app->libCursor = clampi(app->libCursor + 1, 0, n - 1);
            if (down & KEY_LEFT)  app->libCursor = clampi(app->libCursor - 1, 0, n - 1);
            if (down & KEY_DOWN)  app->libCursor = clampi(app->libCursor + COLS, 0, n - 1);
            if (down & KEY_UP)    app->libCursor = clampi(app->libCursor - COLS, 0, n - 1);
            cursor_visibility(app);
            if ((down & KEY_A) && n > 0) open_album(app, app->libCursor);
            break;
        }
        case SCREEN_ALBUM: {
            Album *al = &app->lib->albums[app->albumViewIdx];
            if (down & KEY_DOWN) app->albumCursor = clampi(app->albumCursor + 1, 0, al->trackCount - 1);
            if (down & KEY_UP)   app->albumCursor = clampi(app->albumCursor - 1, 0, al->trackCount - 1);
            cursor_visibility(app);
            if (down & KEY_X) { start_cover_pick(app, false); break; }
            if (down & KEY_Y) { start_cover_pick(app, true); break; }
            if (down & KEY_A) {
                if (player_play_track(&app->player, app->albumViewIdx, app->albumCursor))
                    app->screen = SCREEN_PLAYING;
                else
                    snprintf(app->error, sizeof(app->error), "No se pudo abrir el audio.");
            }
            break;
        }
        case SCREEN_PLAYING:
            if (down & KEY_A) player_toggle_pause(&app->player);
            if (down & KEY_RIGHT) player_next(&app->player);
            if (down & KEY_LEFT)  player_prev(&app->player);
            if (down & KEY_X) {
                if (lyrics_count() > 0) app->showLyrics = !app->showLyrics;
                else app->player.shuffle = !app->player.shuffle;
            }
            if (down & KEY_Y) app->player.repeat = (app->player.repeat + 1) % 3;
            if (app->showLyrics && !lyrics_timed()) {
                if (down & KEY_UP)   app->lyricsOffset--;
                if (down & KEY_DOWN) app->lyricsOffset++;
            }
            break;
        case SCREEN_VIDEOS: {
            int n = app->lib->videoCount;
            if (!n) { app->videoCursor = 0; app->videoScroll = 0; break; }
            if (down & KEY_DOWN) app->videoCursor = clampi(app->videoCursor + 1, 0, n - 1);
            if (down & KEY_UP)   app->videoCursor = clampi(app->videoCursor - 1, 0, n - 1);
            cursor_visibility(app);
            if ((down & KEY_A) && n > 0) { app->videoCursor = clampi(app->videoCursor, 0, n - 1); app_open_video(app, app->videoCursor); }
            break;
        }
        case SCREEN_GAMES:
            if (down & KEY_DOWN) app->gameCursor = clampi(app->gameCursor + 1, 0, GAME_COUNT - 1);
            if (down & KEY_UP)   app->gameCursor = clampi(app->gameCursor - 1, 0, GAME_COUNT - 1);
            cursor_visibility(app);
            if (down & KEY_A) pick_game(app, app->gameCursor);
            break;
        case SCREEN_GAME_SONGS: {
            int n = song_count(app);
            if (!n) { app->screen = SCREEN_GAMES; break; }
            if (down & KEY_DOWN) app->songCursor = clampi(app->songCursor + 1, 0, n - 1);
            if (down & KEY_UP)   app->songCursor = clampi(app->songCursor - 1, 0, n - 1);
            if (down & KEY_R)    app->songCursor = clampi(app->songCursor + 5, 0, n - 1);
            if (down & KEY_L)    app->songCursor = clampi(app->songCursor - 5, 0, n - 1);
            cursor_visibility(app);
            if (down & KEY_A) pick_song(app, app->songCursor);
            break;
        }
        case SCREEN_SETTINGS: {
            int n = setting_count();
            if (down & KEY_DOWN) app->settingCursor = clampi(app->settingCursor + 1, 0, n - 1);
            if (down & KEY_UP)   app->settingCursor = clampi(app->settingCursor - 1, 0, n - 1);
            cursor_visibility(app);
            if (down & KEY_RIGHT) run_setting(app, app->settingCursor, +1);
            if (down & KEY_LEFT)  run_setting(app, app->settingCursor, -1);
            if (down & KEY_A)     run_setting(app, app->settingCursor, +1);
            break;
        }
        case SCREEN_COVER_PICK: {
            int n = covers_image_count() + 1;
            if (down & KEY_DOWN) app->coverCursor = clampi(app->coverCursor + 1, 0, n - 1);
            if (down & KEY_UP)   app->coverCursor = clampi(app->coverCursor - 1, 0, n - 1);
            if (down & KEY_R)    app->coverCursor = clampi(app->coverCursor + 5, 0, n - 1);
            if (down & KEY_L)    app->coverCursor = clampi(app->coverCursor - 5, 0, n - 1);
            cursor_visibility(app);
            if (down & KEY_A) pick_cover(app, app->coverCursor);
            break;
        }
        case SCREEN_GAME: break;
        case SCREEN_VIDEO:
            if (down & KEY_X) cycle_video_orientation(app);
            if (down & KEY_A) video_pause(app->video, !video_is_paused(app->video));
            if (down & KEY_RIGHT) video_seek(app->video, video_position_ms(app->video) + 5000);
            if (down & KEY_LEFT) {
                u64 p = video_position_ms(app->video);
                video_seek(app->video, p > 5000 ? p - 5000 : 0);
            }
            break;
    }
}

void screens_back(App *app) {
    switch (app->screen) {
        case SCREEN_ALBUM:   app->screen = SCREEN_LIBRARY; break;
        case SCREEN_PLAYING: app->screen = SCREEN_LIBRARY; break;
        case SCREEN_VIDEOS:  app->screen = SCREEN_LIBRARY; break;
        case SCREEN_VIDEO:   leave_video(app); break;
        case SCREEN_GAMES:   app->screen = SCREEN_LIBRARY; break;
        case SCREEN_SETTINGS: app->screen = SCREEN_LIBRARY; break;
        case SCREEN_COVER_PICK: app->screen = SCREEN_ALBUM; break;
        case SCREEN_GAME_SONGS: app->screen = SCREEN_GAMES; break;
        case SCREEN_GAME:
            game_stop();
            app->screen = game_needs_song(app->gameKind) ? SCREEN_GAME_SONGS : SCREEN_GAMES;
            break;
        default: break;
    }
}