#include "avi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FCC(a,b,c,d) ((uint32_t)(a) | ((uint32_t)(b)<<8) | ((uint32_t)(c)<<16) | ((uint32_t)(d)<<24))
#define AVI_MAX_FRAMES 100000u
#define AVI_MAX_AUDIO_CHUNKS 100000u
#define AVI_MAX_CHUNK (1024u * 1024u)
#define AVI_MAX_CHUNKS 1000000u
#define AVI_MAX_DEPTH 8u

/* At most 2 MB of indexes (8 bytes/video + 12 bytes/audio), plus temporary
 * realloc storage. Chunk bodies are never allocated by the demuxer. */
typedef struct { uint32_t offset, bytes; } Frame;
typedef struct { uint32_t offset, bytes, first; } AudioChunk;
typedef struct { uint32_t id, data, bytes, end, next; } Chunk;

struct AviFile {
    FILE *video, *audio;
    AviInfo info;
    Frame *frames;
    AudioChunk *pcm;
    uint32_t frameCapacity, pcmCapacity, pcmCount, audioPos, audioChunk;
    uint32_t fileSize, chunkCount, declaredFrames, declaredAudio;
    uint32_t mainWidth, mainHeight, mainFrames, streamCount, streamsSeen;
    int videoStream, audioStream;
};

static uint16_t le16(const unsigned char *p) {
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
}
static uint32_t le32(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static bool read_at(FILE *f, uint32_t offset, void *dst, size_t bytes) {
    return fseek(f, (long)offset, SEEK_SET) == 0 && fread(dst, 1, bytes, f) == bytes;
}
static bool chunk_at(AviFile *a, uint32_t pos, uint32_t end, Chunk *c) {
    unsigned char h[8];
    if (++a->chunkCount > AVI_MAX_CHUNKS || pos > end || end - pos < 8 ||
        end > a->fileSize || !read_at(a->video, pos, h, sizeof(h))) return false;
    c->id = le32(h); c->bytes = le32(h + 4); c->data = pos + 8;
    if (c->bytes > end - c->data) return false;
    c->end = c->data + c->bytes;
    if ((c->bytes & 1) && c->end == end) return false;
    c->next = c->end + (c->bytes & 1);
    return true;
}
static bool list_type(AviFile *a, const Chunk *c, uint32_t *type) {
    unsigned char b[4];
    if (c->bytes < 4 || !read_at(a->video, c->data, b, sizeof(b))) return false;
    *type = le32(b);
    return true;
}
static bool mjpeg(uint32_t tag) {
    return tag == FCC('M','J','P','G') || tag == FCC('J','P','E','G') ||
           tag == FCC('m','j','p','g') || tag == FCC('j','p','e','g');
}
static uint32_t gcd(uint32_t x, uint32_t y) {
    while (y) { uint32_t n = x % y; x = y; y = n; }
    return x;
}

static bool parse_stream(AviFile *a, uint32_t pos, uint32_t end) {
    unsigned char sh[56], sf[40];
    bool haveHeader = false, haveFormat = false;
    uint32_t formatSize = 0;
    if (a->streamsSeen >= 2) return false;
    while (pos < end) {
        Chunk c;
        if (!chunk_at(a, pos, end, &c)) return false;
        if (c.id == FCC('s','t','r','h')) {
            if (haveHeader || c.bytes < sizeof(sh) || c.bytes > 4096 ||
                !read_at(a->video, c.data, sh, sizeof(sh))) return false;
            haveHeader = true;
        } else if (c.id == FCC('s','t','r','f')) {
            if (haveFormat || c.bytes < 16 || c.bytes > 4096) return false;
            memset(sf, 0, sizeof(sf));
            if (!read_at(a->video, c.data, sf, c.bytes < sizeof(sf) ? c.bytes : sizeof(sf))) return false;
            formatSize = c.bytes;
            haveFormat = true;
        }
        pos = c.next;
    }
    if (!haveHeader || !haveFormat || le32(sh + 8) != 0 ||
        le32(sh + 16) != 0 || le32(sh + 28) != 0) return false;
    uint32_t scale = le32(sh + 20), rate = le32(sh + 24);
    if (!scale || !rate) return false;
    if (le32(sh) == FCC('v','i','d','s')) {
        if (a->videoStream >= 0 || formatSize < 40 ||
            le32(sf) < 40 || le32(sf) > formatSize ||
            !mjpeg(le32(sf + 16)) || (le32(sh + 4) && !mjpeg(le32(sh + 4))) ||
            le16(sf + 12) != 1 || le16(sf + 14) != 24 ||
            !le32(sf + 4) || le32(sf + 4) > 512 ||
            !le32(sf + 8) || le32(sf + 8) > 256 ||
            (uint64_t)rate > (uint64_t)scale * 30 || le32(sh + 44) != 0 ||
            !le32(sh + 32) || le32(sh + 32) > AVI_MAX_FRAMES) return false;
        a->videoStream = (int)a->streamsSeen;
        a->info.width = le32(sf + 4); a->info.height = le32(sf + 8);
        uint32_t divisor = gcd(rate, scale);
        a->info.rate = rate / divisor; a->info.scale = scale / divisor;
        a->declaredFrames = le32(sh + 32);
    } else if (le32(sh) == FCC('a','u','d','s')) {
        uint32_t channels = le16(sf + 2), hz = le32(sf + 4), align = channels * 2;
        if (a->audioStream >= 0 || le16(sf) != 1 ||
            (channels != 1 && channels != 2) || hz < 8000 || hz > 48000 ||
            le16(sf + 14) != 16 || le16(sf + 12) != align ||
            le32(sf + 8) != hz * align || le32(sh + 44) != align ||
            (uint64_t)scale * hz != rate ||
            (formatSize != 16 && (formatSize < 18 || le16(sf + 16) > formatSize - 18))) return false;
        a->audioStream = (int)a->streamsSeen;
        a->info.audioRate = hz; a->info.audioChannels = channels;
        a->declaredAudio = le32(sh + 32);
    } else {
        return false; /* Multiple tracks, subtitles, DV and compressed audio are unsupported. */
    }
    a->streamsSeen++;
    return true;
}

static bool parse_hdrl(AviFile *a, uint32_t pos, uint32_t end) {
    bool haveMain = false;
    while (pos < end) {
        Chunk c;
        if (!chunk_at(a, pos, end, &c)) return false;
        if (c.id == FCC('a','v','i','h')) {
            unsigned char h[56];
            if (haveMain || c.bytes < sizeof(h) || c.bytes > 4096 ||
                !read_at(a->video, c.data, h, sizeof(h))) return false;
            /* MUSTUSEINDEX files can reorder/repeat samples; sequential movi is not enough. */
            if (!le32(h) || (le32(h + 12) & 0x20) || le32(h + 20)) return false;
            a->mainFrames = le32(h + 16); a->streamCount = le32(h + 24);
            a->mainWidth = le32(h + 32); a->mainHeight = le32(h + 36);
            haveMain = true;
        } else if (c.id == FCC('L','I','S','T')) {
            uint32_t type;
            if (!list_type(a, &c, &type)) return false;
            if (type == FCC('s','t','r','l') && !parse_stream(a, c.data + 4, c.end)) return false;
            if (type == FCC('o','d','m','l')) return false;
        }
        pos = c.next;
    }
    return haveMain && a->videoStream >= 0 && a->streamsSeen == a->streamCount &&
           a->mainFrames == a->declaredFrames && a->mainWidth == a->info.width &&
           a->mainHeight == a->info.height;
}

static bool add_frame(AviFile *a, const Chunk *c) {
    if (!c->bytes || c->bytes > AVI_MAX_CHUNK || a->info.frameCount >= a->declaredFrames) return false;
    if (a->info.frameCount == a->frameCapacity) {
        uint32_t capacity = a->frameCapacity ? a->frameCapacity * 2 : 256;
        if (capacity > a->declaredFrames) capacity = a->declaredFrames;
        Frame *p = realloc(a->frames, (size_t)capacity * sizeof(*p));
        if (!p) return false;
        a->frames = p; a->frameCapacity = capacity;
    }
    a->frames[a->info.frameCount++] = (Frame){c->data, c->bytes};
    if (c->bytes > a->info.maxFrameBytes) a->info.maxFrameBytes = c->bytes;
    return true;
}
static bool add_audio(AviFile *a, const Chunk *c) {
    uint32_t align = a->info.audioChannels * 2;
    if (!align || c->bytes > AVI_MAX_CHUNK || c->bytes % align) return false;
    if (!c->bytes) return true;
    uint32_t count = c->bytes / align;
    if (a->pcmCount >= AVI_MAX_AUDIO_CHUNKS || a->info.audioFrames > a->declaredAudio ||
        count > a->declaredAudio - a->info.audioFrames) return false;
    if (a->pcmCount == a->pcmCapacity) {
        uint32_t capacity = a->pcmCapacity ? a->pcmCapacity * 2 : 256;
        if (capacity > AVI_MAX_AUDIO_CHUNKS) capacity = AVI_MAX_AUDIO_CHUNKS;
        AudioChunk *p = realloc(a->pcm, (size_t)capacity * sizeof(*p));
        if (!p) return false;
        a->pcm = p; a->pcmCapacity = capacity;
    }
    a->pcm[a->pcmCount++] = (AudioChunk){c->data, c->bytes, a->info.audioFrames};
    a->info.audioFrames += count;
    return true;
}
static bool parse_movi(AviFile *a, uint32_t pos, uint32_t end, unsigned depth) {
    if (depth > AVI_MAX_DEPTH) return false;
    while (pos < end) {
        Chunk c;
        if (!chunk_at(a, pos, end, &c)) return false;
        if (c.id == FCC('L','I','S','T')) {
            uint32_t type;
            if (!list_type(a, &c, &type) || type != FCC('r','e','c',' ') ||
                !parse_movi(a, c.data + 4, c.end, depth + 1)) return false;
        } else if (c.id != FCC('J','U','N','K')) {
            unsigned d0 = c.id & 255, d1 = (c.id >> 8) & 255;
            if (d0 < '0' || d0 > '9' || d1 < '0' || d1 > '9') return false;
            int stream = (int)((d0 - '0') * 10 + d1 - '0');
            uint32_t kind = c.id >> 16;
            if (stream == a->videoStream && (kind == ('d' | ('c' << 8)) || kind == ('d' | ('b' << 8)))) {
                if (!add_frame(a, &c)) return false;
            } else if (stream == a->audioStream && kind == ('w' | ('b' << 8))) {
                if (!add_audio(a, &c)) return false;
            } else return false;
        }
        pos = c.next;
    }
    return true;
}

AviFile *avi_open(const char *path) {
    if (!path) return NULL;
    AviFile *a = calloc(1, sizeof(*a));
    if (!a) return NULL;
    a->videoStream = a->audioStream = -1;
    a->video = fopen(path, "rb");
    if (!a->video || fseek(a->video, 0, SEEK_END)) goto fail;
    long length = ftell(a->video);
    unsigned char h[12];
    if (length < 12 || (uint64_t)length > 0x7FFFFFFF ||
        !read_at(a->video, 0, h, sizeof(h)) || le32(h) != FCC('R','I','F','F') ||
        le32(h + 8) != FCC('A','V','I',' ') || (uint64_t)le32(h + 4) + 8 != (uint64_t)length) goto fail;
    a->fileSize = (uint32_t)length;
    bool haveHeader = false, haveMovie = false;
    for (uint32_t pos = 12; pos < a->fileSize;) {
        Chunk c;
        if (!chunk_at(a, pos, a->fileSize, &c)) goto fail;
        if (c.id == FCC('L','I','S','T')) {
            uint32_t type;
            if (!list_type(a, &c, &type)) goto fail;
            if (type == FCC('h','d','r','l')) {
                if (haveHeader || haveMovie || !parse_hdrl(a, c.data + 4, c.end)) goto fail;
                haveHeader = true;
            } else if (type == FCC('m','o','v','i')) {
                if (!haveHeader || haveMovie || !parse_movi(a, c.data + 4, c.end, 0)) goto fail;
                haveMovie = true;
            }
        }
        pos = c.next;
    }
    if (!haveHeader || !haveMovie || a->info.frameCount != a->declaredFrames ||
        a->info.audioFrames != a->declaredAudio) goto fail;
    if (a->info.audioFrames) {
        a->audio = fopen(path, "rb");
        if (!a->audio || fseek(a->audio, 0, SEEK_END) || ftell(a->audio) != length) goto fail;
    }
    return a;
fail:
    avi_close(a);
    return NULL;
}
void avi_close(AviFile *a) {
    if (!a) return;
    if (a->video) fclose(a->video);
    if (a->audio) fclose(a->audio);
    free(a->frames); free(a->pcm); free(a);
}
const AviInfo *avi_info(const AviFile *a) { return a ? &a->info : NULL; }
bool avi_read_frame(AviFile *a, uint32_t frame, void *dst, size_t capacity, size_t *bytes) {
    if (!bytes) return false;
    *bytes = 0;
    if (!a || !dst || frame >= a->info.frameCount || capacity < a->frames[frame].bytes) return false;
    Frame *f = &a->frames[frame];
    if (!read_at(a->video, f->offset, dst, f->bytes)) return false;
    *bytes = f->bytes;
    return true;
}
bool avi_seek_audio(AviFile *a, uint32_t frame) {
    if (!a || frame > a->info.audioFrames) return false;
    uint32_t lo = 0, hi = a->pcmCount;
    while (lo < hi) {
        uint32_t mid = lo + (hi - lo) / 2;
        AudioChunk *c = &a->pcm[mid];
        if (frame >= c->first + c->bytes / (a->info.audioChannels * 2)) lo = mid + 1;
        else hi = mid;
    }
    a->audioPos = frame; a->audioChunk = lo;
    return true;
}
bool avi_read_audio(AviFile *a, int16_t *dst, uint32_t capacity, uint32_t *frames) {
    if (!frames) return false;
    *frames = 0;
    if (!a || !dst || capacity > 4096) return false;
    uint32_t align = a->info.audioChannels * 2;
    while (*frames < capacity && a->audioPos < a->info.audioFrames) {
        if (!a->audio || a->audioChunk >= a->pcmCount || !align) return false;
        AudioChunk *c = &a->pcm[a->audioChunk];
        uint32_t offset = (a->audioPos - c->first) * align;
        uint32_t n = (c->bytes - offset) / align;
        if (n > capacity - *frames) n = capacity - *frames;
        int16_t *out = dst + *frames * 2;
        if (!read_at(a->audio, c->offset + offset, out, (size_t)n * align)) return false;
        /* Backwards expansion permits mono input and stereo output to overlap. */
        const unsigned char *in = (const unsigned char *)out;
        for (uint32_t i = n; i > 0; --i) {
            int16_t l = (int16_t)le16(in + (i - 1) * align);
            int16_t r = align == 4 ? (int16_t)le16(in + (i - 1) * align + 2) : l;
            out[(i - 1) * 2] = l; out[(i - 1) * 2 + 1] = r;
        }
        *frames += n; a->audioPos += n;
        if (offset + n * align == c->bytes) a->audioChunk++;
    }
    return true;
}
